-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2021 at 05:16 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ullapopken`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_actions`
--

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_actions`
--

INSERT INTO `wp_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2021-08-11 14:23:55', '2021-08-11 14:23:55', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1628691835;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1628691835;}', 1, 1, '2021-08-11 14:24:03', '2021-08-11 14:24:03', 0, NULL),
(7, 'woocommerce_update_marketplace_suggestions', 'complete', '2021-08-11 14:23:47', '2021-08-11 14:23:47', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1628691827;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1628691827;}', 0, 1, '2021-08-11 14:24:03', '2021-08-11 14:24:03', 0, NULL),
(8, 'wc-admin_import_customers', 'complete', '2021-08-12 15:52:08', '2021-08-12 15:52:08', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1628783528;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1628783528;}', 2, 1, '2021-08-12 15:52:35', '2021-08-12 15:52:35', 0, NULL),
(9, 'wc-admin_import_customers', 'complete', '2021-08-13 14:50:00', '2021-08-13 14:50:00', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1628866200;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1628866200;}', 2, 1, '2021-08-13 14:51:19', '2021-08-13 14:51:19', 0, NULL),
(10, 'wc-admin_import_customers', 'complete', '2021-08-15 13:05:02', '2021-08-15 13:05:02', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629032702;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629032702;}', 2, 1, '2021-08-15 13:05:10', '2021-08-15 13:05:10', 0, NULL),
(11, 'wc-admin_import_customers', 'complete', '2021-08-16 02:38:56', '2021-08-16 02:38:56', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629081536;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629081536;}', 2, 1, '2021-08-16 02:38:56', '2021-08-16 02:38:56', 0, NULL),
(12, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 0, 1, '2021-08-16 15:44:31', '2021-08-16 15:44:31', 0, NULL),
(13, 'adjust_download_permissions', 'complete', '2021-08-16 15:45:23', '2021-08-16 15:45:23', '[105]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128723;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128723;}', 0, 1, '2021-08-16 15:45:50', '2021-08-16 15:45:50', 0, NULL),
(14, 'adjust_download_permissions', 'complete', '2021-08-16 15:45:52', '2021-08-16 15:45:52', '[105]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128752;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128752;}', 0, 1, '2021-08-16 15:45:52', '2021-08-16 15:45:52', 0, NULL),
(15, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 0, 1, '2021-08-16 15:45:57', '2021-08-16 15:45:57', 0, NULL),
(16, 'adjust_download_permissions', 'complete', '2021-08-16 15:45:54', '2021-08-16 15:45:54', '[105]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128754;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128754;}', 0, 1, '2021-08-16 15:45:57', '2021-08-16 15:45:57', 0, NULL),
(17, 'adjust_download_permissions', 'complete', '2021-08-16 15:47:39', '2021-08-16 15:47:39', '[110]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128859;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128859;}', 0, 1, '2021-08-16 15:48:01', '2021-08-16 15:48:01', 0, NULL),
(18, 'adjust_download_permissions', 'complete', '2021-08-16 15:49:53', '2021-08-16 15:49:53', '[110]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128993;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128993;}', 0, 1, '2021-08-16 15:49:53', '2021-08-16 15:49:53', 0, NULL),
(19, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 0, 1, '2021-08-16 15:50:04', '2021-08-16 15:50:04', 0, NULL),
(20, 'adjust_download_permissions', 'complete', '2021-08-16 15:49:54', '2021-08-16 15:49:54', '[110]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629128994;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629128994;}', 0, 1, '2021-08-16 15:50:04', '2021-08-16 15:50:04', 0, NULL),
(21, 'adjust_download_permissions', 'complete', '2021-08-16 15:54:40', '2021-08-16 15:54:40', '[117]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629129280;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629129280;}', 0, 1, '2021-08-16 15:54:53', '2021-08-16 15:54:53', 0, NULL),
(22, 'adjust_download_permissions', 'complete', '2021-08-16 15:55:00', '2021-08-16 15:55:00', '[117]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629129300;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629129300;}', 0, 1, '2021-08-16 15:55:53', '2021-08-16 15:55:53', 0, NULL),
(23, 'adjust_download_permissions', 'complete', '2021-08-16 15:55:59', '2021-08-16 15:55:59', '[117]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629129359;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629129359;}', 0, 1, '2021-08-16 15:56:13', '2021-08-16 15:56:13', 0, NULL),
(24, 'adjust_download_permissions', 'complete', '2021-08-16 15:58:45', '2021-08-16 15:58:45', '[117]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629129525;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629129525;}', 0, 1, '2021-08-16 15:58:53', '2021-08-16 15:58:53', 0, NULL),
(25, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 0, 1, '2021-08-16 15:58:53', '2021-08-16 15:58:53', 0, NULL),
(26, 'adjust_download_permissions', 'complete', '2021-08-16 16:00:37', '2021-08-16 16:00:37', '[117]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629129637;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629129637;}', 0, 1, '2021-08-16 16:00:56', '2021-08-16 16:00:56', 0, NULL),
(27, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 0, 1, '2021-08-16 16:00:56', '2021-08-16 16:00:56', 0, NULL),
(28, 'wc-admin_import_customers', 'complete', '2021-08-17 03:13:44', '2021-08-17 03:13:44', '[1]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1629170024;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1629170024;}', 2, 1, '2021-08-17 14:32:55', '2021-08-17 14:32:55', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_claims`
--

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) UNSIGNED NOT NULL,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_groups`
--

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_groups`
--

INSERT INTO `wp_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wc-admin-data');

-- --------------------------------------------------------

--
-- Table structure for table `wp_actionscheduler_logs`
--

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

INSERT INTO `wp_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'action created', '2021-08-11 14:22:55', '2021-08-11 14:22:55'),
(2, 7, 'action created', '2021-08-11 14:23:47', '2021-08-11 14:23:47'),
(3, 7, 'action started via Async Request', '2021-08-11 14:24:03', '2021-08-11 14:24:03'),
(4, 7, 'action complete via Async Request', '2021-08-11 14:24:03', '2021-08-11 14:24:03'),
(5, 6, 'action started via Async Request', '2021-08-11 14:24:03', '2021-08-11 14:24:03'),
(6, 6, 'action complete via Async Request', '2021-08-11 14:24:03', '2021-08-11 14:24:03'),
(7, 8, 'action created', '2021-08-12 15:52:03', '2021-08-12 15:52:03'),
(8, 8, 'action started via Async Request', '2021-08-12 15:52:35', '2021-08-12 15:52:35'),
(9, 8, 'action complete via Async Request', '2021-08-12 15:52:35', '2021-08-12 15:52:35'),
(10, 9, 'action created', '2021-08-13 14:49:55', '2021-08-13 14:49:55'),
(11, 9, 'action started via WP Cron', '2021-08-13 14:51:19', '2021-08-13 14:51:19'),
(12, 9, 'action complete via WP Cron', '2021-08-13 14:51:19', '2021-08-13 14:51:19'),
(13, 10, 'action created', '2021-08-15 13:04:57', '2021-08-15 13:04:57'),
(14, 10, 'action started via Async Request', '2021-08-15 13:05:10', '2021-08-15 13:05:10'),
(15, 10, 'action complete via Async Request', '2021-08-15 13:05:10', '2021-08-15 13:05:10'),
(16, 11, 'action created', '2021-08-16 02:38:51', '2021-08-16 02:38:51'),
(17, 11, 'action started via WP Cron', '2021-08-16 02:38:56', '2021-08-16 02:38:56'),
(18, 11, 'action complete via WP Cron', '2021-08-16 02:38:56', '2021-08-16 02:38:56'),
(19, 12, 'action created', '2021-08-16 15:44:13', '2021-08-16 15:44:13'),
(20, 12, 'action started via Async Request', '2021-08-16 15:44:31', '2021-08-16 15:44:31'),
(21, 12, 'action complete via Async Request', '2021-08-16 15:44:31', '2021-08-16 15:44:31'),
(22, 13, 'action created', '2021-08-16 15:45:22', '2021-08-16 15:45:22'),
(23, 13, 'action started via Async Request', '2021-08-16 15:45:50', '2021-08-16 15:45:50'),
(24, 13, 'action complete via Async Request', '2021-08-16 15:45:50', '2021-08-16 15:45:50'),
(25, 14, 'action created', '2021-08-16 15:45:51', '2021-08-16 15:45:51'),
(26, 14, 'action started via WP Cron', '2021-08-16 15:45:52', '2021-08-16 15:45:52'),
(27, 14, 'action complete via WP Cron', '2021-08-16 15:45:52', '2021-08-16 15:45:52'),
(28, 15, 'action created', '2021-08-16 15:45:52', '2021-08-16 15:45:52'),
(29, 16, 'action created', '2021-08-16 15:45:53', '2021-08-16 15:45:53'),
(30, 15, 'action started via Async Request', '2021-08-16 15:45:57', '2021-08-16 15:45:57'),
(31, 15, 'action complete via Async Request', '2021-08-16 15:45:57', '2021-08-16 15:45:57'),
(32, 16, 'action started via Async Request', '2021-08-16 15:45:57', '2021-08-16 15:45:57'),
(33, 16, 'action complete via Async Request', '2021-08-16 15:45:57', '2021-08-16 15:45:57'),
(34, 17, 'action created', '2021-08-16 15:47:38', '2021-08-16 15:47:38'),
(35, 17, 'action started via WP Cron', '2021-08-16 15:48:01', '2021-08-16 15:48:01'),
(36, 17, 'action complete via WP Cron', '2021-08-16 15:48:01', '2021-08-16 15:48:01'),
(37, 18, 'action created', '2021-08-16 15:49:52', '2021-08-16 15:49:52'),
(38, 18, 'action started via WP Cron', '2021-08-16 15:49:53', '2021-08-16 15:49:53'),
(39, 18, 'action complete via WP Cron', '2021-08-16 15:49:53', '2021-08-16 15:49:53'),
(40, 19, 'action created', '2021-08-16 15:49:53', '2021-08-16 15:49:53'),
(41, 20, 'action created', '2021-08-16 15:49:53', '2021-08-16 15:49:53'),
(42, 19, 'action started via Async Request', '2021-08-16 15:50:04', '2021-08-16 15:50:04'),
(43, 19, 'action complete via Async Request', '2021-08-16 15:50:04', '2021-08-16 15:50:04'),
(44, 20, 'action started via Async Request', '2021-08-16 15:50:04', '2021-08-16 15:50:04'),
(45, 20, 'action complete via Async Request', '2021-08-16 15:50:04', '2021-08-16 15:50:04'),
(46, 21, 'action created', '2021-08-16 15:54:39', '2021-08-16 15:54:39'),
(47, 21, 'action started via WP Cron', '2021-08-16 15:54:53', '2021-08-16 15:54:53'),
(48, 21, 'action complete via WP Cron', '2021-08-16 15:54:53', '2021-08-16 15:54:53'),
(49, 22, 'action created', '2021-08-16 15:54:59', '2021-08-16 15:54:59'),
(50, 22, 'action started via WP Cron', '2021-08-16 15:55:53', '2021-08-16 15:55:53'),
(51, 22, 'action complete via WP Cron', '2021-08-16 15:55:53', '2021-08-16 15:55:53'),
(52, 23, 'action created', '2021-08-16 15:55:58', '2021-08-16 15:55:58'),
(53, 23, 'action started via Async Request', '2021-08-16 15:56:12', '2021-08-16 15:56:12'),
(54, 23, 'action complete via Async Request', '2021-08-16 15:56:13', '2021-08-16 15:56:13'),
(55, 24, 'action created', '2021-08-16 15:58:44', '2021-08-16 15:58:44'),
(56, 25, 'action created', '2021-08-16 15:58:45', '2021-08-16 15:58:45'),
(57, 25, 'action started via WP Cron', '2021-08-16 15:58:53', '2021-08-16 15:58:53'),
(58, 25, 'action complete via WP Cron', '2021-08-16 15:58:53', '2021-08-16 15:58:53'),
(59, 24, 'action started via WP Cron', '2021-08-16 15:58:53', '2021-08-16 15:58:53'),
(60, 24, 'action complete via WP Cron', '2021-08-16 15:58:53', '2021-08-16 15:58:53'),
(61, 26, 'action created', '2021-08-16 16:00:36', '2021-08-16 16:00:36'),
(62, 27, 'action created', '2021-08-16 16:00:37', '2021-08-16 16:00:37'),
(63, 27, 'action started via WP Cron', '2021-08-16 16:00:56', '2021-08-16 16:00:56'),
(64, 27, 'action complete via WP Cron', '2021-08-16 16:00:56', '2021-08-16 16:00:56'),
(65, 26, 'action started via WP Cron', '2021-08-16 16:00:56', '2021-08-16 16:00:56'),
(66, 26, 'action complete via WP Cron', '2021-08-16 16:00:56', '2021-08-16 16:00:56'),
(67, 28, 'action created', '2021-08-17 03:13:39', '2021-08-17 03:13:39'),
(68, 28, 'action started via WP Cron', '2021-08-17 14:32:55', '2021-08-17 14:32:55'),
(69, 28, 'action complete via WP Cron', '2021-08-17 14:32:55', '2021-08-17 14:32:55');

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-08-11 14:21:40', '2021-08-11 14:21:40', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/ullapopken', 'yes'),
(2, 'home', 'http://localhost/ullapopken', 'yes'),
(3, 'blogname', 'Ullapopken', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'hettipower@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:195:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:47:\"(([^/]+/)*wishlist)(/(.*))?/page/([0-9]{1,})/?$\";s:76:\"index.php?pagename=$matches[1]&wishlist-action=$matches[4]&paged=$matches[5]\";s:30:\"(([^/]+/)*wishlist)(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&wishlist-action=$matches[4]\";s:7:\"menu/?$\";s:24:\"index.php?post_type=menu\";s:37:\"menu/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=menu&feed=$matches[1]\";s:32:\"menu/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=menu&feed=$matches[1]\";s:24:\"menu/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=menu&paged=$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:32:\"menu/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"menu/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"menu/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"menu/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"menu/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"menu/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"menu/([^/]+)/embed/?$\";s:37:\"index.php?menu=$matches[1]&embed=true\";s:25:\"menu/([^/]+)/trackback/?$\";s:31:\"index.php?menu=$matches[1]&tb=1\";s:45:\"menu/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?menu=$matches[1]&feed=$matches[2]\";s:40:\"menu/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?menu=$matches[1]&feed=$matches[2]\";s:33:\"menu/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?menu=$matches[1]&paged=$matches[2]\";s:40:\"menu/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?menu=$matches[1]&cpage=$matches[2]\";s:30:\"menu/([^/]+)/wc-api(/(.*))?/?$\";s:45:\"index.php?menu=$matches[1]&wc-api=$matches[3]\";s:36:\"menu/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:47:\"menu/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:29:\"menu/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?menu=$matches[1]&page=$matches[2]\";s:21:\"menu/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"menu/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"menu/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"menu/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"menu/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"menu/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:44:\"brand/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?product_brand=$matches[1]&feed=$matches[2]\";s:39:\"brand/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?product_brand=$matches[1]&feed=$matches[2]\";s:20:\"brand/(.+?)/embed/?$\";s:46:\"index.php?product_brand=$matches[1]&embed=true\";s:32:\"brand/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?product_brand=$matches[1]&paged=$matches[2]\";s:14:\"brand/(.+?)/?$\";s:35:\"index.php?product_brand=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:38:\"index.php?&page_id=2&cpage=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:11:{i:0;s:41:\"acf-theme-code-pro/acf_theme_code_pro.php\";i:1;s:34:\"advanced-custom-fields-pro/acf.php\";i:2;s:91:\"all-in-one-wp-migration-unlimited-extension/all-in-one-wp-migration-unlimited-extension.php\";i:3;s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";i:4;s:39:\"disable-gutenberg/disable-gutenberg.php\";i:5;s:29:\"pwfwoofilter/pwfwoofilter.php\";i:6;s:27:\"svg-support/svg-support.php\";i:7;s:41:\"woocommerce-brands/woocommerce-brands.php\";i:8;s:27:\"woocommerce/woocommerce.php\";i:9;s:23:\"wp-smushit/wp-smush.php\";i:10;s:34:\"yith-woocommerce-wishlist/init.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'ullapopken-theme', 'yes'),
(41, 'stylesheet', 'ullapopken-theme', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '2', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1644243700', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '49752', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}', 'yes'),
(101, 'fresh_site', '0', 'yes'),
(102, 'widget_block', 'a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:5:{s:9:\"main-menu\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:19:\"wp_inactive_widgets\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:15:\"footer-widget-1\";a:2:{i:0;s:10:\"nav_menu-2\";i:1;s:13:\"media_image-2\";}s:15:\"footer-widget-2\";a:1:{i:0;s:10:\"nav_menu-3\";}s:13:\"array_version\";i:3;}', 'yes'),
(104, 'cron', 'a:19:{i:1629213292;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1629213700;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1629213774;a:1:{s:33:\"wc_admin_process_orders_milestone\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1629213780;a:1:{s:29:\"wc_admin_unsnooze_admin_notes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1629214375;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1629216023;a:1:{s:34:\"yith_wcwl_delete_expired_wishlists\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629216416;a:1:{s:21:\"ai1wm_storage_cleanup\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629220973;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629231773;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1629244800;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629253300;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1629296500;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629296507;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629296509;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629296574;a:1:{s:14:\"wc_admin_daily\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629296583;a:2:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1629382900;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1629987833;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:11:\"fifteendays\";s:4:\"args\";a:0:{}s:8:\"interval\";i:1296000;}}}s:7:\"version\";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_image', 'a:2:{i:2;a:15:{s:4:\"size\";s:4:\"full\";s:5:\"width\";i:200;s:6:\"height\";i:36;s:7:\"caption\";s:0:\"\";s:3:\"alt\";s:0:\"\";s:9:\"link_type\";s:6:\"custom\";s:8:\"link_url\";s:0:\"\";s:13:\"image_classes\";s:0:\"\";s:12:\"link_classes\";s:0:\"\";s:8:\"link_rel\";s:0:\"\";s:17:\"link_target_blank\";b:0;s:11:\"image_title\";s:0:\"\";s:13:\"attachment_id\";i:78;s:3:\"url\";s:72:\"http://localhost/ullapopken/wp-content/uploads/2021/08/8813329317918.png\";s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:3:{i:2;a:2:{s:5:\"title\";s:11:\"Our Service\";s:8:\"nav_menu\";i:19;}i:3;a:2:{s:5:\"title\";s:8:\"About us\";s:8:\"nav_menu\";i:20;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:0:{}', 'yes'),
(119, 'theme_mods_twentytwentyone', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1628691958;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.8.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.8.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-5.8-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.8-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"5.8\";s:7:\"version\";s:3:\"5.8\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1629210777;s:15:\"version_checked\";s:3:\"5.8\";s:12:\"translations\";a:0:{}}', 'no'),
(128, '_site_transient_timeout_browser_5dd84b6147bbb17b430079be84dacdc3', '1629296508', 'no'),
(129, '_site_transient_browser_5dd84b6147bbb17b430079be84dacdc3', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"90.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:32:\"https://www.mozilla.org/firefox/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(130, '_site_transient_timeout_php_check_5e827212769c648f6a0478f622eede02', '1629296508', 'no'),
(131, '_site_transient_php_check_5e827212769c648f6a0478f622eede02', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(133, 'can_compress_scripts', '1', 'no'),
(140, 'recently_activated', 'a:0:{}', 'yes'),
(147, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1629210781;s:7:\"checked\";a:2:{s:15:\"twentytwentyone\";s:3:\"1.4\";s:16:\"ullapopken-theme\";s:3:\"1.0\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:1:{s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.4\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.4.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(153, 'finished_updating_comment_type', '1', 'yes'),
(155, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(156, 'schema-ActionScheduler_StoreSchema', '4.0.1628691772', 'yes'),
(157, 'schema-ActionScheduler_LoggerSchema', '2.0.1628691772', 'yes'),
(160, 'woocommerce_schema_version', '430', 'yes'),
(161, 'woocommerce_store_address', '', 'yes'),
(162, 'woocommerce_store_address_2', '', 'yes'),
(163, 'woocommerce_store_city', '', 'yes'),
(164, 'woocommerce_default_country', 'GB', 'yes'),
(165, 'woocommerce_store_postcode', '', 'yes'),
(166, 'woocommerce_allowed_countries', 'all', 'yes'),
(167, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(168, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(169, 'woocommerce_ship_to_countries', '', 'yes'),
(170, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(171, 'woocommerce_default_customer_address', 'base', 'yes'),
(172, 'woocommerce_calc_taxes', 'no', 'yes'),
(173, 'woocommerce_enable_coupons', 'yes', 'yes'),
(174, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(175, 'woocommerce_currency', 'EUR', 'yes'),
(176, 'woocommerce_currency_pos', 'left', 'yes'),
(177, 'woocommerce_price_thousand_sep', ',', 'yes'),
(178, 'woocommerce_price_decimal_sep', '.', 'yes'),
(179, 'woocommerce_price_num_decimals', '2', 'yes'),
(180, 'woocommerce_shop_page_id', '6', 'yes'),
(181, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(182, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(183, 'woocommerce_placeholder_image', '5', 'yes'),
(184, 'woocommerce_weight_unit', 'kg', 'yes'),
(185, 'woocommerce_dimension_unit', 'cm', 'yes'),
(186, 'woocommerce_enable_reviews', 'yes', 'yes'),
(187, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(188, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(189, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(190, 'woocommerce_review_rating_required', 'yes', 'no'),
(191, 'woocommerce_manage_stock', 'yes', 'yes'),
(192, 'woocommerce_hold_stock_minutes', '60', 'no'),
(193, 'woocommerce_notify_low_stock', 'yes', 'no'),
(194, 'woocommerce_notify_no_stock', 'yes', 'no'),
(195, 'woocommerce_stock_email_recipient', 'hettipower@gmail.com', 'no'),
(196, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(197, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(198, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(199, 'woocommerce_stock_format', '', 'yes'),
(200, 'woocommerce_file_download_method', 'force', 'no'),
(201, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(202, 'woocommerce_downloads_require_login', 'no', 'no'),
(203, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(204, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(205, 'woocommerce_prices_include_tax', 'no', 'yes'),
(206, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(207, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(208, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(209, 'woocommerce_tax_classes', '', 'yes'),
(210, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(211, 'woocommerce_tax_display_cart', 'excl', 'yes'),
(212, 'woocommerce_price_display_suffix', '', 'yes'),
(213, 'woocommerce_tax_total_display', 'itemized', 'no'),
(214, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(215, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(216, 'woocommerce_ship_to_destination', 'billing', 'no'),
(217, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(218, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(219, 'woocommerce_enable_checkout_login_reminder', 'no', 'no'),
(220, 'woocommerce_enable_signup_and_login_from_checkout', 'no', 'no'),
(221, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(222, 'woocommerce_registration_generate_username', 'yes', 'no'),
(223, 'woocommerce_registration_generate_password', 'yes', 'no'),
(224, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(225, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(226, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(227, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes'),
(228, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(229, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(230, 'woocommerce_trash_pending_orders', '', 'no'),
(231, 'woocommerce_trash_failed_orders', '', 'no'),
(232, 'woocommerce_trash_cancelled_orders', '', 'no'),
(233, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}', 'no'),
(234, 'woocommerce_email_from_name', 'Ullapopken', 'no'),
(235, 'woocommerce_email_from_address', 'hettipower@gmail.com', 'no'),
(236, 'woocommerce_email_header_image', '', 'no'),
(237, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(238, 'woocommerce_email_base_color', '#96588a', 'no'),
(239, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(240, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(241, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(242, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(243, 'woocommerce_cart_page_id', '7', 'no'),
(244, 'woocommerce_checkout_page_id', '8', 'no'),
(245, 'woocommerce_myaccount_page_id', '9', 'no'),
(246, 'woocommerce_terms_page_id', '', 'no'),
(247, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(248, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(249, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(250, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(251, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(252, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(253, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(254, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(255, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(256, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(257, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(258, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(259, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(260, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(261, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(262, 'woocommerce_api_enabled', 'no', 'yes'),
(263, 'woocommerce_allow_tracking', 'yes', 'no'),
(264, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(265, 'woocommerce_single_image_width', '600', 'yes'),
(266, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(267, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(268, 'woocommerce_demo_store', 'no', 'no'),
(269, 'woocommerce_permalinks', 'a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}', 'yes'),
(270, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(271, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(274, 'default_product_cat', '15', 'yes'),
(277, 'woocommerce_paypal_settings', 'a:23:{s:7:\"enabled\";s:2:\"no\";s:5:\"title\";s:6:\"PayPal\";s:11:\"description\";s:85:\"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.\";s:5:\"email\";s:20:\"hettipower@gmail.com\";s:8:\"advanced\";s:0:\"\";s:8:\"testmode\";s:2:\"no\";s:5:\"debug\";s:2:\"no\";s:16:\"ipn_notification\";s:3:\"yes\";s:14:\"receiver_email\";s:20:\"hettipower@gmail.com\";s:14:\"identity_token\";s:0:\"\";s:14:\"invoice_prefix\";s:3:\"WC-\";s:13:\"send_shipping\";s:3:\"yes\";s:16:\"address_override\";s:2:\"no\";s:13:\"paymentaction\";s:4:\"sale\";s:9:\"image_url\";s:0:\"\";s:11:\"api_details\";s:0:\"\";s:12:\"api_username\";s:0:\"\";s:12:\"api_password\";s:0:\"\";s:13:\"api_signature\";s:0:\"\";s:20:\"sandbox_api_username\";s:0:\"\";s:20:\"sandbox_api_password\";s:0:\"\";s:21:\"sandbox_api_signature\";s:0:\"\";s:12:\"_should_load\";s:2:\"no\";}', 'yes'),
(278, 'woocommerce_version', '5.5.2', 'yes'),
(279, 'woocommerce_db_version', '5.5.2', 'yes'),
(280, 'woocommerce_inbox_variant_assignment', '8', 'yes'),
(284, '_transient_jetpack_autoloader_plugin_paths', 'a:1:{i:0;s:29:\"{{WP_PLUGIN_DIR}}/woocommerce\";}', 'yes'),
(285, 'action_scheduler_lock_async-request-runner', '1629213286', 'yes'),
(286, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(287, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:\"database_prefix\";s:32:\"cHGrG8aw68ag5YPraWPY2kxuNsFKVLfP\";}', 'yes'),
(288, '_transient_woocommerce_webhook_ids_status_active', 'a:0:{}', 'yes'),
(289, 'widget_woocommerce_widget_cart', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(290, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(291, 'widget_woocommerce_layered_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(292, 'widget_woocommerce_price_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(293, 'widget_woocommerce_product_categories', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(294, 'widget_woocommerce_product_search', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(295, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(296, 'widget_woocommerce_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(297, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(298, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(299, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(300, 'widget_woocommerce_rating_filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(303, 'woocommerce_admin_version', '2.4.4', 'yes'),
(304, 'woocommerce_admin_install_timestamp', '1628691774', 'yes'),
(305, 'wc_remote_inbox_notifications_wca_updated', '', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(306, 'wc_remote_inbox_notifications_specs', 'a:33:{s:16:\"wayflyer_q3_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:16:\"wayflyer_q3_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"Grow your revenue with Wayflyer financing and analytics\";s:7:\"content\";s:322:\"Flexible financing tailored to your needs by <a href=\"https://woocommerce.com/products/wayflyer/\">Wayflyer</a> – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store\'s performance, Wayflyer can provide the financing you need to grow and the analytical insights to help you spend it.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"wayflyer_q3_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Get funded\";}}s:3:\"url\";s:42:\"https://woocommerce.com/products/wayflyer/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:5:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-07-19 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-07-31 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:2:\"<=\";s:5:\"value\";s:3:\"200\";}i:3;O:8:\"stdClass\":3:{s:4:\"type\";s:11:\"order_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";s:3:\"100\";}i:4;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:7:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"AU\";}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"BE\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"CA\";}i:3;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"IE\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"NL\";}i:5;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"UK\";}i:6;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:2:\"US\";}}}}}s:19:\"eu_vat_changes_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:19:\"eu_vat_changes_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:54:\"Get your business ready for the new EU tax regulations\";s:7:\"content\";s:617:\"On July 1, 2021, new taxation rules will come into play when the <a href=\"https://ec.europa.eu/taxation_customs/business/vat/modernising-vat-cross-border-ecommerce_en\">European Union (EU) Value-Added Tax (VAT) eCommerce package</a> takes effect.<br/><br/>The new regulations will impact virtually every B2C business involved in cross-border eCommerce trade with the EU.<br/><br/>We therefore recommend <a href=\"https://woocommerce.com/posts/new-eu-vat-regulations\">familiarizing yourself with the new updates</a>, and consult with a tax professional to ensure your business is following regulations and best practice.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:19:\"eu_vat_changes_2021\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:39:\"Learn more about the EU tax regulations\";}}s:3:\"url\";s:52:\"https://woocommerce.com/posts/new-eu-vat-regulations\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-06-24 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-07-11 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:3:\"all\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;a:2:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:10:\"all_except\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:27:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"BE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"BG\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"CZ\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"DK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"DE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"EE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:6;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"IE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"EL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:8;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"ES\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:9;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"FR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:10;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"HR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:11;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"IT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:12;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"CY\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:13;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LV\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:14;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:15;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"LU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:16;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"HU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:17;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"MT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:18;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"NL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:19;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"AT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:20;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"PL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:21;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"PT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:22;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"RO\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:23;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:24;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:25;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"FI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}i:26;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:32:\"woocommerce_all_except_countries\";s:5:\"value\";s:2:\"SE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:9:\"!contains\";}}}}i:2;a:3:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:3:\"all\";s:7:\"default\";b:0;s:9:\"operation\";s:2:\"!=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:29:\"woocommerce_allowed_countries\";s:5:\"value\";s:10:\"all_except\";s:7:\"default\";b:0;s:9:\"operation\";s:2:\"!=\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:27:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"BE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"BG\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"CZ\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"DK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"DE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"EE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:6;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"IE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"EL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:8;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"ES\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:9;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"FR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:10;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"HR\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:11;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"IT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:12;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"CY\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:13;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LV\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:14;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:15;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"LU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:16;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"HU\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:17;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"MT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:18;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"NL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:19;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"AT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:20;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"PL\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:21;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"PT\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:22;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"RO\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:23;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:24;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SK\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:25;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"FI\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}i:26;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:38:\"woocommerce_specific_allowed_countries\";s:5:\"value\";s:2:\"SE\";s:7:\"default\";a:0:{}s:9:\"operation\";s:8:\"contains\";}}}}}}}}s:20:\"paypal_ppcp_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"paypal_ppcp_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Offer more options with the new PayPal\";s:7:\"content\";s:113:\"Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:36:\"open_wc_paypal_payments_product_page\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:61:\"https://woocommerce.com/products/woocommerce-paypal-payments/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-04-05 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-04-21 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:7:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:30:\"woocommerce-gateway-paypal-pro\";}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:37:\"woocommerce-gateway-paypal-pro-hosted\";}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:35:\"woocommerce-gateway-paypal-advanced\";}}i:4;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:40:\"woocommerce-gateway-paypal-digital-goods\";}}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:31:\"woocommerce-paypal-here-gateway\";}}i:6;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:44:\"woocommerce-gateway-paypal-adaptive-payments\";}}}}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:27:\"woocommerce-paypal-payments\";s:7:\"version\";s:5:\"1.2.1\";s:8:\"operator\";s:1:\"<\";}}}}}s:23:\"facebook_pixel_api_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:23:\"facebook_pixel_api_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:44:\"Improve the performance of your Facebook ads\";s:7:\"content\";s:152:\"Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"upgrade_now_facebook_pixel_api\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Upgrade now\";}}s:3:\"url\";s:67:\"plugin-install.php?tab=plugin-information&plugin=&section=changelog\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-17 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-14 00:00:00\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:24:\"facebook-for-woocommerce\";s:7:\"version\";s:5:\"2.4.0\";s:8:\"operator\";s:2:\"<=\";}}}s:16:\"facebook_ec_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:16:\"facebook_ec_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:59:\"Sync your product catalog with Facebook to help boost sales\";s:7:\"content\";s:170:\"A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:22:\"learn_more_facebook_ec\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:42:\"https://woocommerce.com/products/facebook/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-03-01 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-03-15 00:00:00\";}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:24:\"facebook-for-woocommerce\";}}}}s:37:\"ecomm-need-help-setting-up-your-store\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"ecomm-need-help-setting-up-your-store\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:32:\"Need help setting up your Store?\";s:7:\"content\";s:350:\"Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:16:\"set-up-concierge\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:21:\"Schedule free session\";}}s:3:\"url\";s:34:\"https://wordpress.com/me/concierge\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}}}s:20:\"woocommerce-services\";O:8:\"stdClass\":8:{s:4:\"slug\";s:20:\"woocommerce-services\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"WooCommerce Shipping & Tax\";s:7:\"content\";s:255:\"WooCommerce Shipping & Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:84:\"https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-services\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:32:\"ecomm-unique-shopping-experience\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"ecomm-unique-shopping-experience\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"For a shopping experience as unique as your customers\";s:7:\"content\";s:274:\"Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:43:\"learn-more-ecomm-unique-shopping-experience\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:71:\"https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:3:{i:0;s:35:\"woocommerce-shipping-australia-post\";i:1;s:32:\"woocommerce-shipping-canada-post\";i:2;s:30:\"woocommerce-shipping-royalmail\";}}i:1;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\"<\";s:4:\"days\";i:2;}}}s:37:\"wc-admin-getting-started-in-ecommerce\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-getting-started-in-ecommerce\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:38:\"Getting Started in eCommerce - webinar\";s:7:\"content\";s:174:\"We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:17:\"watch-the-webinar\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:17:\"Watch the webinar\";}}s:3:\"url\";s:28:\"https://youtu.be/V_2XtCOyZ7o\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:12:\"setup_client\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_count\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:1:\"0\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:4:\"none\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:7:\"revenue\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";s:10:\"up-to-2500\";}}}}}s:18:\"your-first-product\";O:8:\"stdClass\":8:{s:4:\"slug\";s:18:\"your-first-product\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:18:\"Your first product\";s:7:\"content\";s:461:\"That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br/><br/>Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_were_no_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:12:\"stored_state\";s:5:\"index\";s:22:\"there_are_now_products\";s:9:\"operation\";s:1:\"=\";s:5:\"value\";b:1;}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:13:\"product_count\";s:9:\"operation\";s:2:\">=\";s:5:\"value\";i:1;}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:18:\"onboarding_profile\";s:5:\"index\";s:13:\"product_types\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"physical\";s:7:\"default\";a:0:{}}}}s:31:\"wc-square-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wc-square-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:191:\"Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:97:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:38:\"wc-square-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:38:\"wc-square-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:38:\"wc-square-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"Grow your business with Square and Apple Pay \";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:104:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:9:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:18:\"woocommerce-square\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"2.3\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"wc_square_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:31:\"wc-square-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wcpay-apple-pay-is-now-available\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wcpay-apple-pay-is-now-available\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:53:\"Apple Pay is now available with WooCommerce Payments!\";s:7:\"content\";s:397:\"Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:13:\"add-apple-pay\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:13:\"Add Apple Pay\";}}s:3:\"url\";s:69:\"/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:121:\"https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:20:\"woocommerce-payments\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"2.3.0\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";b:0;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}s:27:\"wcpay-apple-pay-boost-sales\";O:8:\"stdClass\":8:{s:4:\"slug\";s:27:\"wcpay-apple-pay-boost-sales\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:26:\"Boost sales with Apple Pay\";s:7:\"content\";s:205:\"Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:27:\"boost-sales-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:96:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:1;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:34:\"wcpay-apple-pay-grow-your-business\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:34:\"wcpay-apple-pay-grow-your-business\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"wcpay-apple-pay-grow-your-business\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:58:\"Grow your business with WooCommerce Payments and Apple Pay\";s:7:\"content\";s:178:\"Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"grow-your-business-marketing-guide\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"See marketing guide\";}}s:3:\"url\";s:103:\"https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.8\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"wcpay_is_apple_pay_enabled\";s:5:\"value\";i:2;s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:27:\"wcpay-apple-pay-boost-sales\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:37:\"wc-admin-optimizing-the-checkout-flow\";O:8:\"stdClass\":8:{s:4:\"slug\";s:37:\"wc-admin-optimizing-the-checkout-flow\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:28:\"Optimizing the checkout flow\";s:7:\"content\";s:171:\"It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:28:\"optimizing-the-checkout-flow\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:78:\"https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:3;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:8:\"payments\";s:7:\"default\";a:0:{}}}}s:39:\"wc-admin-first-five-things-to-customize\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-admin-first-five-things-to-customize\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:45:\"The first 5 things to customize in your store\";s:7:\"content\";s:173:\"Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:82:\"https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:1:\">\";s:4:\"days\";i:2;}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:5:\"value\";s:9:\"NOT EMPTY\";s:7:\"default\";s:9:\"NOT EMPTY\";s:9:\"operation\";s:2:\"!=\";}}}s:32:\"wc-payments-qualitative-feedback\";O:8:\"stdClass\":8:{s:4:\"slug\";s:32:\"wc-payments-qualitative-feedback\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"WooCommerce Payments setup - let us know what you think\";s:7:\"content\";s:146:\"Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:35:\"qualitative-feedback-from-new-users\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:39:\"https://automattic.survey.fm/wc-pay-new\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:45:\"woocommerce_task_list_tracked_completed_tasks\";s:9:\"operation\";s:8:\"contains\";s:5:\"value\";s:20:\"woocommerce-payments\";s:7:\"default\";a:0:{}}}}s:29:\"share-your-feedback-on-paypal\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"share-your-feedback-on-paypal\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:29:\"Share your feedback on PayPal\";s:7:\"content\";s:127:\"Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:14:\"share-feedback\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:14:\"Share feedback\";}}s:3:\"url\";s:43:\"http://automattic.survey.fm/paypal-feedback\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}}s:5:\"rules\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:26:\"woocommerce-gateway-stripe\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}}}s:31:\"wcpay_instant_deposits_gtm_2021\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"wcpay_instant_deposits_gtm_2021\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:69:\"Get paid within minutes – Instant Deposits for WooCommerce Payments\";s:7:\"content\";s:384:\"Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:40:\"Learn about Instant Deposits eligibility\";}}s:3:\"url\";s:136:\"https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:4:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-05-18 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:19:\"publish_before_time\";s:14:\"publish_before\";s:19:\"2021-06-01 00:00:00\";}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}s:31:\"google_listings_and_ads_install\";O:8:\"stdClass\":8:{s:4:\"slug\";s:31:\"google_listings_and_ads_install\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:35:\"Drive traffic and sales with Google\";s:7:\"content\";s:123:\"Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:11:\"get-started\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:11:\"Get started\";}}s:3:\"url\";s:56:\"https://woocommerce.com/products/google-listings-and-ads\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:18:\"publish_after_time\";s:13:\"publish_after\";s:19:\"2021-06-09 00:00:00\";}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:23:\"google_listings_and_ads\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:11:\"order_count\";s:9:\"operation\";s:1:\">\";s:5:\"value\";i:10;}}}s:39:\"wc-subscriptions-security-update-3-0-15\";O:8:\"stdClass\":8:{s:4:\"slug\";s:39:\"wc-subscriptions-security-update-3-0-15\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:42:\"WooCommerce Subscriptions security update!\";s:7:\"content\";s:736:\"We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br/><br/>Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br/><br/>We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br/><br/>If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:30:\"update-wc-subscriptions-3-0-15\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:19:\"View latest version\";}}s:3:\"url\";s:30:\"&page=wc-addons&section=helper\";s:18:\"url_is_admin_query\";b:1;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:25:\"woocommerce-subscriptions\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:6:\"3.0.15\";}}}s:29:\"woocommerce-core-update-5-4-0\";O:8:\"stdClass\":8:{s:4:\"slug\";s:29:\"woocommerce-core-update-5-4-0\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Update to WooCommerce 5.4.1 now\";s:7:\"content\";s:140:\"WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:20:\"update-wc-core-5-4-0\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:25:\"How to update WooCommerce\";}}s:3:\"url\";s:64:\"https://docs.woocommerce.com/document/how-to-update-woocommerce/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.0\";}}}s:19:\"wcpay-promo-2020-11\";O:8:\"stdClass\":7:{s:4:\"slug\";s:19:\"wcpay-promo-2020-11\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-11\";s:7:\"content\";s:19:\"wcpay-promo-2020-11\";}}s:5:\"rules\";a:0:{}}s:19:\"wcpay-promo-2020-12\";O:8:\"stdClass\":7:{s:4:\"slug\";s:19:\"wcpay-promo-2020-12\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:19:\"wcpay-promo-2020-12\";s:7:\"content\";s:19:\"wcpay-promo-2020-12\";}}s:5:\"rules\";a:0:{}}s:30:\"wcpay-promo-2021-6-incentive-1\";O:8:\"stdClass\":8:{s:4:\"slug\";s:30:\"wcpay-promo-2021-6-incentive-1\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:82:\"Simplify the payments process for you and your customers with WooCommerce Payments\";s:7:\"content\";s:704:\"With <a href=\"https://woocommerce.com/payments/?utm_medium=notification&utm_source=product&utm_campaign=wcpay601\">WooCommerce Payments</a>, you can securely accept all major cards, Apple Pay®, and recurring revenue in over 100 currencies. \n				Built into your store’s WooCommerce dashboard, track cash flow and manage all of your transactions in one place – with no setup costs or monthly fees.\n				<br/><br/>\n				By clicking \"Get WooCommerce Payments,\" you agree to the <a href=\"https://wordpress.com/tos/?utm_medium=notification&utm_source=product&utm_campaign=wcpay601\">Terms of Service</a> \n				and acknowledge you have read the <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>.\n				\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:25:\"get-woo-commerce-payments\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Get WooCommerce Payments\";}}s:3:\"url\";s:57:\"admin.php?page=wc-admin&action=setup-woocommerce-payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:12:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:6:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"1\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"3\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"5\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"7\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"9\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"11\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:4:{i:0;s:17:\"crowdsignal-forms\";i:1;s:11:\"layout-grid\";i:2;s:17:\"full-site-editing\";i:3;s:13:\"page-optimize\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"woocommerce_allow_tracking\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:2:\">=\";s:4:\"days\";i:31;}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.0\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:10:\"db_version\";s:5:\"value\";s:5:\"45805\";s:7:\"default\";i:0;s:9:\"operation\";s:2:\">=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:30:\"wcpay-promo-2021-6-incentive-2\";O:8:\"stdClass\":8:{s:4:\"slug\";s:30:\"wcpay-promo-2021-6-incentive-2\";s:4:\"type\";s:9:\"marketing\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:82:\"Simplify the payments process for you and your customers with WooCommerce Payments\";s:7:\"content\";s:704:\"With <a href=\"https://woocommerce.com/payments/?utm_medium=notification&utm_source=product&utm_campaign=wcpay601\">WooCommerce Payments</a>, you can securely accept all major cards, Apple Pay®, and recurring revenue in over 100 currencies. \n				Built into your store’s WooCommerce dashboard, track cash flow and manage all of your transactions in one place – with no setup costs or monthly fees.\n				<br/><br/>\n				By clicking \"Get WooCommerce Payments,\" you agree to the <a href=\"https://wordpress.com/tos/?utm_medium=notification&utm_source=product&utm_campaign=wcpay601\">Terms of Service</a> \n				and acknowledge you have read the <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>.\n				\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:24:\"get-woocommerce-payments\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:24:\"Get WooCommerce Payments\";}}s:3:\"url\";s:57:\"admin.php?page=wc-admin&action=setup-woocommerce-payments\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:12:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:6:{i:0;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"2\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"4\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"6\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:1:\"8\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"10\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:5;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";s:2:\"12\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:4:{i:0;s:17:\"crowdsignal-forms\";i:1;s:11:\"layout-grid\";i:2;s:17:\"full-site-editing\";i:3;s:13:\"page-optimize\";}}}}i:2;O:8:\"stdClass\":3:{s:4:\"type\";s:21:\"base_location_country\";s:5:\"value\";s:2:\"US\";s:9:\"operation\";s:1:\"=\";}i:3;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:26:\"woocommerce_allow_tracking\";s:5:\"value\";s:3:\"yes\";s:7:\"default\";b:0;s:9:\"operation\";s:1:\"=\";}i:4;O:8:\"stdClass\":3:{s:4:\"type\";s:18:\"wcadmin_active_for\";s:9:\"operation\";s:2:\">=\";s:4:\"days\";i:31;}i:5;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:20:\"woocommerce-payments\";}}}}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:3:\"4.0\";}i:7;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:10:\"db_version\";s:5:\"value\";s:5:\"45805\";s:7:\"default\";i:0;s:9:\"operation\";s:2:\">=\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-11\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:8:\"actioned\";s:9:\"operation\";s:2:\"!=\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:19:\"wcpay-promo-2020-12\";s:6:\"status\";s:10:\"unactioned\";s:9:\"operation\";s:2:\"!=\";}}}s:34:\"ppxo-pps-upgrade-paypal-payments-1\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-1\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:47:\"Get the latest PayPal extension for WooCommerce\";s:7:\"content\";s:440:\"Heads up! There\'s a new PayPal on the block!<br/><br/>Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br/><br/>Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-1\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:0;s:7:\"default\";b:0;}}}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:7;s:7:\"default\";i:1;s:9:\"operation\";s:1:\"<\";}}}s:34:\"ppxo-pps-upgrade-paypal-payments-2\";O:8:\"stdClass\":8:{s:4:\"slug\";s:34:\"ppxo-pps-upgrade-paypal-payments-2\";s:4:\"type\";s:4:\"info\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:31:\"Upgrade your PayPal experience!\";s:7:\"content\";s:513:\"We\'ve developed a whole new <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension for WooCommerce</a> that combines the best features of our many PayPal extensions into just one extension.<br/><br/>Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br/><br/>Start using our latest PayPal today to continue to receive support and updates.\";}}s:7:\"actions\";a:1:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:34:\"ppxo-pps-install-paypal-payments-2\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:18:\"View upgrade guide\";}}s:3:\"url\";s:96:\"https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:27:\"woocommerce-paypal-payments\";}}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:17:\"plugins_activated\";s:7:\"plugins\";a:1:{i:0;s:43:\"woocommerce-gateway-paypal-express-checkout\";}}i:1;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:27:\"woocommerce_paypal_settings\";s:9:\"operation\";s:2:\"!=\";s:5:\"value\";b:0;s:7:\"default\";b:0;}}}i:2;O:8:\"stdClass\":5:{s:4:\"type\";s:6:\"option\";s:11:\"option_name\";s:36:\"woocommerce_inbox_variant_assignment\";s:5:\"value\";i:6;s:7:\"default\";i:1;s:9:\"operation\";s:1:\">\";}}}s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";O:8:\"stdClass\":8:{s:4:\"slug\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:56:\"Action required: Critical vulnerabilities in WooCommerce\";s:7:\"content\";s:570:\"In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/>Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br/><br/>For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:146:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:23:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.3.6\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.4.8\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.5.9\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.6.6\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.7.2\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.8.2\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.9.4\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.2\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.2\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.3\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.4\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.2\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.3\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.3\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.2\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.3\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.1\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.2\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:5:\"5.5.1\";}}}s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";O:8:\"stdClass\":8:{s:4:\"slug\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:63:\"Action required: Critical vulnerabilities in WooCommerce Blocks\";s:7:\"content\";s:570:\"In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/>Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br/><br/>For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:146:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:31:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:6:\"2.5.16\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.6.2\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.7.2\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.8.1\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"2.9.1\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.0.1\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.1.1\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.2.1\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.3.1\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.4.1\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.5.1\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.6.1\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.7.2\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.8.1\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"3.9.1\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.0.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.1.1\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.2.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.3.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.4.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.5.3\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.6.1\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.7.1\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.8.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"4.9.2\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.0.1\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.1.1\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.2.1\";}i:28;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.3.2\";}i:29;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\"!=\";s:7:\"version\";s:5:\"5.4.1\";}i:30;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"<\";s:7:\"version\";s:5:\"5.5.1\";}}}s:45:\"woocommerce-core-sqli-july-2021-store-patched\";O:8:\"stdClass\":8:{s:4:\"slug\";s:45:\"woocommerce-core-sqli-july-2021-store-patched\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:55:\"Solved: Critical vulnerabilities patched in WooCommerce\";s:7:\"content\";s:433:\"In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:146:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:23:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.3.6\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.4.8\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.5.9\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.6\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.2\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.2\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.4\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.2\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.2\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.3\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.4\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.2\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.3\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.3\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.2\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.3\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.1\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.2\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:11:\"woocommerce\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"5.5.1\";}}}}}s:47:\"woocommerce-blocks-sqli-july-2021-store-patched\";O:8:\"stdClass\":8:{s:4:\"slug\";s:47:\"woocommerce-blocks-sqli-july-2021-store-patched\";s:4:\"type\";s:6:\"update\";s:6:\"status\";s:10:\"unactioned\";s:12:\"is_snoozable\";i:0;s:6:\"source\";s:15:\"woocommerce.com\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":3:{s:6:\"locale\";s:5:\"en_US\";s:5:\"title\";s:62:\"Solved: Critical vulnerabilities patched in WooCommerce Blocks\";s:7:\"content\";s:433:\"In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br/><br/><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.\";}}s:7:\"actions\";a:2:{i:0;O:8:\"stdClass\":6:{s:4:\"name\";s:10:\"learn-more\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:10:\"Learn more\";}}s:3:\"url\";s:146:\"https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms\";s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:1;s:6:\"status\";s:10:\"unactioned\";}i:1;O:8:\"stdClass\":6:{s:4:\"name\";s:7:\"dismiss\";s:7:\"locales\";a:1:{i:0;O:8:\"stdClass\":2:{s:6:\"locale\";s:5:\"en_US\";s:5:\"label\";s:7:\"Dismiss\";}}s:3:\"url\";b:0;s:18:\"url_is_admin_query\";b:0;s:10:\"is_primary\";b:0;s:6:\"status\";s:8:\"actioned\";}}s:5:\"rules\";a:3:{i:0;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:46:\"woocommerce-core-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:1;O:8:\"stdClass\":2:{s:4:\"type\";s:3:\"not\";s:7:\"operand\";a:1:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:11:\"note_status\";s:9:\"note_name\";s:48:\"woocommerce-blocks-sqli-july-2021-need-to-update\";s:6:\"status\";s:7:\"pending\";s:9:\"operation\";s:1:\"=\";}}}i:2;O:8:\"stdClass\":2:{s:4:\"type\";s:2:\"or\";s:8:\"operands\";a:31:{i:0;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:6:\"2.5.16\";}i:1;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.6.2\";}i:2;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.7.2\";}i:3;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.8.1\";}i:4;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"2.9.1\";}i:5;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.0.1\";}i:6;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.1.1\";}i:7;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.2.1\";}i:8;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.3.1\";}i:9;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.4.1\";}i:10;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.5.1\";}i:11;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.6.1\";}i:12;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.7.2\";}i:13;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.8.1\";}i:14;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"3.9.1\";}i:15;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.0.1\";}i:16;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.1.1\";}i:17;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.2.1\";}i:18;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.3.1\";}i:19;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.4.3\";}i:20;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.5.3\";}i:21;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.6.1\";}i:22;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.7.1\";}i:23;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.8.1\";}i:24;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"4.9.2\";}i:25;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.0.1\";}i:26;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.1.1\";}i:27;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.2.1\";}i:28;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.3.2\";}i:29;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:1:\"=\";s:7:\"version\";s:5:\"5.4.1\";}i:30;O:8:\"stdClass\":4:{s:4:\"type\";s:14:\"plugin_version\";s:6:\"plugin\";s:28:\"woo-gutenberg-products-block\";s:8:\"operator\";s:2:\">=\";s:7:\"version\";s:5:\"5.5.1\";}}}}}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(307, 'wc_remote_inbox_notifications_stored_state', 'O:8:\"stdClass\":2:{s:22:\"there_were_no_products\";b:1;s:22:\"there_are_now_products\";b:1;}', 'no'),
(312, '_transient_wc_count_comments', 'O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}', 'yes'),
(313, 'wc_blocks_db_schema_version', '260', 'yes'),
(314, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(319, '_transient_woocommerce_reports-transient-version', '1628691777', 'yes'),
(320, '_transient_timeout_orders-all-statuses', '1629296577', 'no'),
(321, '_transient_orders-all-statuses', 'a:2:{s:7:\"version\";s:10:\"1628691777\";s:5:\"value\";a:0:{}}', 'no'),
(325, 'woocommerce_onboarding_profile', 'a:1:{s:7:\"skipped\";b:1;}', 'yes'),
(327, '_transient_timeout_wc_report_orders_stats_261c0cca77912ee1541f990470d5012f', '1629296620', 'no'),
(328, '_transient_wc_report_orders_stats_261c0cca77912ee1541f990470d5012f', 'a:2:{s:7:\"version\";s:10:\"1628691777\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-32\";s:10:\"date_start\";s:19:\"2021-08-11 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-08-11 00:00:00\";s:8:\"date_end\";s:19:\"2021-08-11 14:23:40\";s:12:\"date_end_gmt\";s:19:\"2021-08-11 14:23:40\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}', 'no'),
(329, '_transient_timeout_wc_report_orders_stats_637fcb1276068a6ec584a54b9d7d5305', '1629296620', 'no'),
(330, '_transient_wc_report_orders_stats_637fcb1276068a6ec584a54b9d7d5305', 'a:2:{s:7:\"version\";s:10:\"1628691777\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-32\";s:10:\"date_start\";s:19:\"2021-08-11 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-08-11 00:00:00\";s:8:\"date_end\";s:19:\"2021-08-11 14:23:40\";s:12:\"date_end_gmt\";s:19:\"2021-08-11 14:23:40\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}', 'no'),
(331, '_transient_timeout_wc_report_orders_stats_7ff77b7a77030817e931c26709b6377e', '1629296620', 'no'),
(332, '_transient_wc_report_orders_stats_7ff77b7a77030817e931c26709b6377e', 'a:2:{s:7:\"version\";s:10:\"1628691777\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-32\";s:10:\"date_start\";s:19:\"2021-08-10 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-08-10 00:00:00\";s:8:\"date_end\";s:19:\"2021-08-10 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-08-10 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}', 'no'),
(333, '_transient_timeout_wc_report_orders_stats_a9e6aef7bc0cbbb38a40797e0a1fe3dd', '1629296620', 'no'),
(334, '_transient_wc_report_orders_stats_a9e6aef7bc0cbbb38a40797e0a1fe3dd', 'a:2:{s:7:\"version\";s:10:\"1628691777\";s:5:\"value\";O:8:\"stdClass\":5:{s:6:\"totals\";O:8:\"stdClass\":15:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"products\";i:0;s:8:\"segments\";a:0:{}}s:9:\"intervals\";a:1:{i:0;a:6:{s:8:\"interval\";s:7:\"2021-32\";s:10:\"date_start\";s:19:\"2021-08-10 00:00:00\";s:14:\"date_start_gmt\";s:19:\"2021-08-10 00:00:00\";s:8:\"date_end\";s:19:\"2021-08-10 23:59:59\";s:12:\"date_end_gmt\";s:19:\"2021-08-10 23:59:59\";s:9:\"subtotals\";O:8:\"stdClass\":14:{s:12:\"orders_count\";i:0;s:14:\"num_items_sold\";i:0;s:11:\"gross_sales\";d:0;s:11:\"total_sales\";d:0;s:7:\"coupons\";d:0;s:13:\"coupons_count\";i:0;s:7:\"refunds\";d:0;s:5:\"taxes\";d:0;s:8:\"shipping\";d:0;s:11:\"net_revenue\";d:0;s:19:\"avg_items_per_order\";d:0;s:15:\"avg_order_value\";d:0;s:15:\"total_customers\";i:0;s:8:\"segments\";a:0:{}}}}s:5:\"total\";i:1;s:5:\"pages\";i:1;s:7:\"page_no\";i:1;}}', 'no'),
(338, 'woocommerce_task_list_welcome_modal_dismissed', 'yes', 'yes'),
(341, 'woocommerce_marketplace_suggestions', 'a:2:{s:11:\"suggestions\";a:27:{i:0;a:4:{s:4:\"slug\";s:28:\"product-edit-meta-tab-header\";s:7:\"context\";s:28:\"product-edit-meta-tab-header\";s:5:\"title\";s:22:\"Recommended extensions\";s:13:\"allow-dismiss\";b:0;}i:1;a:6:{s:4:\"slug\";s:39:\"product-edit-meta-tab-footer-browse-all\";s:7:\"context\";s:28:\"product-edit-meta-tab-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:2;a:9:{s:4:\"slug\";s:46:\"product-edit-mailchimp-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-mailchimp\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/mailchimp-for-memberships.svg\";s:5:\"title\";s:25:\"Mailchimp for Memberships\";s:4:\"copy\";s:79:\"Completely automate your email lists by syncing membership changes to Mailchimp\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/mailchimp-woocommerce-memberships/\";}i:3;a:9:{s:4:\"slug\";s:19:\"product-edit-addons\";s:7:\"product\";s:26:\"woocommerce-product-addons\";s:14:\"show-if-active\";a:2:{i:0;s:25:\"woocommerce-subscriptions\";i:1;s:20:\"woocommerce-bookings\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-add-ons.svg\";s:5:\"title\";s:15:\"Product Add-Ons\";s:4:\"copy\";s:93:\"Offer add-ons like gift wrapping, special messages or other special options for your products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-add-ons/\";}i:4;a:9:{s:4:\"slug\";s:46:\"product-edit-woocommerce-subscriptions-gifting\";s:7:\"product\";s:33:\"woocommerce-subscriptions-gifting\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:116:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/gifting-for-subscriptions.svg\";s:5:\"title\";s:25:\"Gifting for Subscriptions\";s:4:\"copy\";s:70:\"Let customers buy subscriptions for others - they\'re the ultimate gift\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:67:\"https://woocommerce.com/products/woocommerce-subscriptions-gifting/\";}i:5;a:9:{s:4:\"slug\";s:42:\"product-edit-teams-woocommerce-memberships\";s:7:\"product\";s:33:\"woocommerce-memberships-for-teams\";s:14:\"show-if-active\";a:1:{i:0;s:23:\"woocommerce-memberships\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:112:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/teams-for-memberships.svg\";s:5:\"title\";s:21:\"Teams for Memberships\";s:4:\"copy\";s:123:\"Adds B2B functionality to WooCommerce Memberships, allowing sites to sell team, group, corporate, or family member accounts\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/teams-woocommerce-memberships/\";}i:6;a:8:{s:4:\"slug\";s:29:\"product-edit-variation-images\";s:7:\"product\";s:39:\"woocommerce-additional-variation-images\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/additional-variation-images.svg\";s:5:\"title\";s:27:\"Additional Variation Images\";s:4:\"copy\";s:72:\"Showcase your products in the best light with a image for each variation\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:73:\"https://woocommerce.com/products/woocommerce-additional-variation-images/\";}i:7;a:9:{s:4:\"slug\";s:47:\"product-edit-woocommerce-subscription-downloads\";s:7:\"product\";s:34:\"woocommerce-subscription-downloads\";s:14:\"show-if-active\";a:1:{i:0;s:25:\"woocommerce-subscriptions\";}s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:113:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscription-downloads.svg\";s:5:\"title\";s:22:\"Subscription Downloads\";s:4:\"copy\";s:57:\"Give customers special downloads with their subscriptions\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:68:\"https://woocommerce.com/products/woocommerce-subscription-downloads/\";}i:8;a:8:{s:4:\"slug\";s:31:\"product-edit-min-max-quantities\";s:7:\"product\";s:30:\"woocommerce-min-max-quantities\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:109:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/min-max-quantities.svg\";s:5:\"title\";s:18:\"Min/Max Quantities\";s:4:\"copy\";s:81:\"Specify minimum and maximum allowed product quantities for orders to be completed\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/min-max-quantities/\";}i:9;a:8:{s:4:\"slug\";s:28:\"product-edit-name-your-price\";s:7:\"product\";s:27:\"woocommerce-name-your-price\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/name-your-price.svg\";s:5:\"title\";s:15:\"Name Your Price\";s:4:\"copy\";s:70:\"Let customers pay what they want - useful for donations, tips and more\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/name-your-price/\";}i:10;a:8:{s:4:\"slug\";s:42:\"product-edit-woocommerce-one-page-checkout\";s:7:\"product\";s:29:\"woocommerce-one-page-checkout\";s:7:\"context\";a:1:{i:0;s:26:\"product-edit-meta-tab-body\";}s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/one-page-checkout.svg\";s:5:\"title\";s:17:\"One Page Checkout\";s:4:\"copy\";s:92:\"Don\'t make customers click around - let them choose products, checkout & pay all on one page\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:63:\"https://woocommerce.com/products/woocommerce-one-page-checkout/\";}i:11;a:4:{s:4:\"slug\";s:19:\"orders-empty-header\";s:7:\"context\";s:24:\"orders-list-empty-header\";s:5:\"title\";s:20:\"Tools for your store\";s:13:\"allow-dismiss\";b:0;}i:12;a:6:{s:4:\"slug\";s:30:\"orders-empty-footer-browse-all\";s:7:\"context\";s:24:\"orders-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:13;a:8:{s:4:\"slug\";s:19:\"orders-empty-wc-pay\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-payments\";s:4:\"icon\";s:111:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/woocommerce-payments.svg\";s:5:\"title\";s:20:\"WooCommerce Payments\";s:4:\"copy\";s:125:\"Securely accept payments and manage transactions directly from your WooCommerce dashboard – no setup costs or monthly fees.\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-payments/\";}i:14;a:8:{s:4:\"slug\";s:19:\"orders-empty-zapier\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:18:\"woocommerce-zapier\";s:4:\"icon\";s:97:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/zapier.svg\";s:5:\"title\";s:6:\"Zapier\";s:4:\"copy\";s:88:\"Save time and increase productivity by connecting your store to more than 1000+ services\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:52:\"https://woocommerce.com/products/woocommerce-zapier/\";}i:15;a:8:{s:4:\"slug\";s:30:\"orders-empty-shipment-tracking\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:29:\"woocommerce-shipment-tracking\";s:4:\"icon\";s:108:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipment-tracking.svg\";s:5:\"title\";s:17:\"Shipment Tracking\";s:4:\"copy\";s:86:\"Let customers know when their orders will arrive by adding shipment tracking to emails\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:51:\"https://woocommerce.com/products/shipment-tracking/\";}i:16;a:8:{s:4:\"slug\";s:32:\"orders-empty-table-rate-shipping\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:31:\"woocommerce-table-rate-shipping\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/table-rate-shipping.svg\";s:5:\"title\";s:19:\"Table Rate Shipping\";s:4:\"copy\";s:122:\"Advanced, flexible shipping. Define multiple shipping rates based on location, price, weight, shipping class or item count\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/table-rate-shipping/\";}i:17;a:8:{s:4:\"slug\";s:40:\"orders-empty-shipping-carrier-extensions\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:4:\"icon\";s:118:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/shipping-carrier-extensions.svg\";s:5:\"title\";s:27:\"Shipping Carrier Extensions\";s:4:\"copy\";s:116:\"Show live rates from FedEx, UPS, USPS and more directly on your store - never under or overcharge for shipping again\";s:11:\"button-text\";s:13:\"Find Carriers\";s:8:\"promoted\";s:26:\"category-shipping-carriers\";s:3:\"url\";s:99:\"https://woocommerce.com/product-category/woocommerce-extensions/shipping-methods/shipping-carriers/\";}i:18;a:8:{s:4:\"slug\";s:32:\"orders-empty-google-product-feed\";s:7:\"context\";s:22:\"orders-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-product-feeds\";s:4:\"icon\";s:110:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/google-product-feed.svg\";s:5:\"title\";s:19:\"Google Product Feed\";s:4:\"copy\";s:76:\"Increase sales by letting customers find you when they\'re shopping on Google\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:53:\"https://woocommerce.com/products/google-product-feed/\";}i:19;a:4:{s:4:\"slug\";s:35:\"products-empty-header-product-types\";s:7:\"context\";s:26:\"products-list-empty-header\";s:5:\"title\";s:23:\"Other types of products\";s:13:\"allow-dismiss\";b:0;}i:20;a:6:{s:4:\"slug\";s:32:\"products-empty-footer-browse-all\";s:7:\"context\";s:26:\"products-list-empty-footer\";s:9:\"link-text\";s:21:\"Browse all extensions\";s:3:\"url\";s:64:\"https://woocommerce.com/product-category/woocommerce-extensions/\";s:8:\"promoted\";s:31:\"category-woocommerce-extensions\";s:13:\"allow-dismiss\";b:0;}i:21;a:8:{s:4:\"slug\";s:30:\"products-empty-product-vendors\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-vendors\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-vendors.svg\";s:5:\"title\";s:15:\"Product Vendors\";s:4:\"copy\";s:47:\"Turn your store into a multi-vendor marketplace\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-vendors/\";}i:22;a:8:{s:4:\"slug\";s:26:\"products-empty-memberships\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:23:\"woocommerce-memberships\";s:4:\"icon\";s:102:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/memberships.svg\";s:5:\"title\";s:11:\"Memberships\";s:4:\"copy\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:57:\"https://woocommerce.com/products/woocommerce-memberships/\";}i:23;a:9:{s:4:\"slug\";s:35:\"products-empty-woocommerce-deposits\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-deposits\";s:14:\"show-if-active\";a:1:{i:0;s:20:\"woocommerce-bookings\";}s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/deposits.svg\";s:5:\"title\";s:8:\"Deposits\";s:4:\"copy\";s:75:\"Make it easier for customers to pay by offering a deposit or a payment plan\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-deposits/\";}i:24;a:8:{s:4:\"slug\";s:40:\"products-empty-woocommerce-subscriptions\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:25:\"woocommerce-subscriptions\";s:4:\"icon\";s:104:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/subscriptions.svg\";s:5:\"title\";s:13:\"Subscriptions\";s:4:\"copy\";s:97:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:59:\"https://woocommerce.com/products/woocommerce-subscriptions/\";}i:25;a:8:{s:4:\"slug\";s:35:\"products-empty-woocommerce-bookings\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:20:\"woocommerce-bookings\";s:4:\"icon\";s:99:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/bookings.svg\";s:5:\"title\";s:8:\"Bookings\";s:4:\"copy\";s:99:\"Allow customers to book appointments, make reservations or rent equipment without leaving your site\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:54:\"https://woocommerce.com/products/woocommerce-bookings/\";}i:26;a:8:{s:4:\"slug\";s:30:\"products-empty-product-bundles\";s:7:\"context\";s:24:\"products-list-empty-body\";s:7:\"product\";s:27:\"woocommerce-product-bundles\";s:4:\"icon\";s:106:\"https://woocommerce.com/wp-content/plugins/wccom-plugins/marketplace-suggestions/icons/product-bundles.svg\";s:5:\"title\";s:15:\"Product Bundles\";s:4:\"copy\";s:49:\"Offer customizable bundles and assembled products\";s:11:\"button-text\";s:10:\"Learn More\";s:3:\"url\";s:49:\"https://woocommerce.com/products/product-bundles/\";}}s:7:\"updated\";i:1628691843;}', 'no'),
(342, 'action_scheduler_migration_status', 'complete', 'yes'),
(348, 'current_theme', 'Ullapopken Theme', 'yes'),
(349, 'theme_mods_ullapopken-theme', 'a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;}', 'yes'),
(350, 'theme_switched', '', 'yes'),
(351, 'woocommerce_maybe_regenerate_images_hash', '991b1ca641921cf0f5baf7a2fe85861b', 'yes'),
(357, 'wp-smush-settings', 'a:22:{s:4:\"auto\";b:1;s:5:\"lossy\";b:0;s:10:\"strip_exif\";b:1;s:6:\"resize\";b:0;s:9:\"detection\";b:0;s:8:\"original\";b:0;s:6:\"backup\";b:0;s:10:\"png_to_jpg\";b:0;s:7:\"nextgen\";b:0;s:2:\"s3\";b:0;s:9:\"gutenberg\";b:0;s:10:\"js_builder\";b:0;s:3:\"cdn\";b:0;s:11:\"auto_resize\";b:0;s:4:\"webp\";b:1;s:5:\"usage\";b:0;s:17:\"accessible_colors\";b:0;s:9:\"keep_data\";b:1;s:9:\"lazy_load\";b:0;s:17:\"background_images\";b:1;s:16:\"rest_api_support\";b:0;s:8:\"webp_mod\";b:0;}', 'yes'),
(358, 'wp-smush-install-type', 'existing', 'no'),
(359, 'wp-smush-version', '3.8.8', 'no'),
(362, 'acf_version', '5.9.5', 'yes'),
(363, 'wdev-frash', 'a:3:{s:7:\"plugins\";a:1:{s:23:\"wp-smushit/wp-smush.php\";i:1628692017;}s:5:\"queue\";a:2:{s:32:\"7de3619981caadc55f30a002bfb299f6\";a:4:{s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:4:\"type\";s:5:\"email\";s:7:\"show_at\";i:1628692017;s:6:\"sticky\";b:1;}s:32:\"fc50097023d0d34c5a66f6cddcf77694\";a:3:{s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:4:\"type\";s:4:\"rate\";s:7:\"show_at\";i:1629296817;}}s:4:\"done\";a:0:{}}', 'no'),
(364, 'wpmudev_recommended_plugins_registered', 'a:1:{s:23:\"wp-smushit/wp-smush.php\";a:1:{s:13:\"registered_at\";i:1628692017;}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(384, 'dd9b23a13775ccc12b5389d301f8ef5d', 'a:2:{s:7:\"timeout\";i:1629139139;s:5:\"value\";s:26843:\"{\"new_version\":\"2.5.2\",\"stable_version\":\"2.5.2\",\"name\":\"ACF Theme Code Pro\",\"slug\":\"acf_theme_code_pro\",\"url\":\"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/?changelog=1\",\"last_updated\":\"2021-02-19 15:29:30\",\"homepage\":\"https:\\/\\/hookturn.io\\/downloads\\/acf-theme-code-pro\\/\",\"package\":\"\",\"download_link\":\"\",\"sections\":{\"description\":\"<p><strong>ACF Theme Code Pro saves you time by automatically generating the code needed to implement ACF PRO field groups and ACF Blocks in your WordPress themes.<\\/strong><\\/p>\\n<p><em>\\u201cWork smarter, not harder! Great work on this ACF plugin!\\u201d<\\/em> - Elliot Condon, Creator of Advanced Custom Fields<\\/p>\\n<p>ACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>The code required to implement your fields is displayed in the <em>Theme Code<\\/em> section at the bottom of your Edit Field Group page.<\\/p>\\n<p><strong>Features<\\/strong><\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation and includes escaping<\\/li>\\n<li>Support for field return types and single\\/muliple value options<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p><strong>ACF Free, ACF Pro &amp; 3rd party fields <\\/strong><\\/p>\\n<p>Theme Code Pro generates code for all of these fields:<\\/p>\\n<p><strong>ACF Free Fields<\\/strong><\\/p>\\n<ul>\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Range<\\/li>\\n<li>Email<\\/li>\\n<li>URL<\\/li>\\n<li>Password<\\/li>\\n<li>Image<\\/li>\\n<li>File<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>oEmbed<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio Button<\\/li>\\n<li>Button Group<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Page Link<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Group<\\/li>\\n<\\/ul>\\n<p><strong>ACF Pro Fields<\\/strong><\\/p>\\n<ul>\\n<li>Repeater<\\/li>\\n<li>Flexible content<\\/li>\\n<li>Gallery<\\/li>\\n<li>Clone<\\/li>\\n<\\/ul>\\n<p><strong>3rd Party Fields<\\/strong><\\/p>\\n<ul>\\n<li>Font Awesome<\\/li>\\n<li>Gravityforms<\\/li>\\n<li>Ninjaforms<\\/li>\\n<li>Contact Form 7<\\/li>\\n<li>RGBA Colour<\\/li>\\n<li>Color Palette<\\/li>\\n<li>Table<\\/li>\\n<li>TablePress<\\/li>\\n<li>Sidebar Selector<\\/li>\\n<li>Nav Menu<\\/li>\\n<li>Image Aspect Ratio Crop<\\/li>\\n<li>Audio\\/Video Player<\\/li>\\n<li>SVG Icon<\\/li>\\n<li>Icon Selector<\\/li>\\n<li>Code<\\/li>\\n<li>Address<\\/li>\\n<li>Number Slider<\\/li>\\n<li>Star Rating<\\/li>\\n<li>YouTube Picker<\\/li>\\n<li>Post Type Select<\\/li>\\n<li>Smart Button<\\/li>\\n<\\/ul>\\n<p><strong>Location Rule Support<\\/strong><\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules in each field group. This includes more complex locations like <em>Block, Options Page, Widget, Taxonomy, Comment, Attachment, Current User and User Form.<\\/em><\\/p>\\n<p><strong>Create Blocks and Options Pages<\\/strong><\\/p>\\n<p>ACF Theme Code Pro also includes a handy <em>Location Registration Tool<\\/em> that generates the code needed to create new Blocks and Options Pages.<\\/p>\\n<p><strong>Works best with<\\/strong><\\/p>\\n<ul>\\n<li>Advanced Custom Fields Pro v5.9 or higher<\\/li>\\n<li>Advanced Custom Fields Free v5.9 or higher<\\/li>\\n<li>WordPress 5.6 or higher<\\/li>\\n<li>PHP 7.0 or higher<\\/li>\\n<\\/ul>\\n<p><strong>Try our FREE version<\\/strong><\\/p>\\n<p>If you would like to \\u2018try before you buy\\u2019 you can check out our free version <a href=\\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">ACF Theme Code<\\/a> on WordPress.org. This plugin supports all the field types included in free version of Advanced Custom Fields.<\\/p>\\n<p><strong>Hi! We made this<\\/strong><\\/p>\\n<p>The ACF Theme Code Plugin was created by <a href=\\\"http:\\/\\/aaronrutley.com\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">AaronRutley<\\/a> &amp; <a href=\\\"http:\\/\\/benpearson.com.au\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">Ben Pearson<\\/a>, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p><strong>Theme Code Pro makes developers happy!<\\/strong><\\/p>\\n<p><em>\\u201cGreat time saver - No more constantly referring to the ACF documentation for the right ACF code.\\u201d<\\/em> - David McDonald, Freelance Web Developer<\\/p>\\n<p><em>\\u201cAwesome add-on for ACF - It will certainly speed up theme development.\\u201d<\\/em> - Matthew Heyes, Web Developer &amp; WordPress Specialist<\\/p>\\n<p><em>\\u201cI\'m going to use all the free time this plugin gives me to, I don\'t know, catch up on sleep!\\u201d<\\/em> - Joel Eade, Website Designer<\\/p>\\n<p><em>\\u201cI should have dropped the change a long time ago. AWESOME. Massive time saver. Wish I\\u2019d done it sooner.\\u201d<\\/em> - theatereleven, WordPress Developer<\\/p>\\n\",\"changelog\":\"<p><strong>2.5.2<\\/strong><\\/p>\\n<ul>\\n<li>Add support for the following third party fields:<\\/li>\\n<ul>\\n<li>ACF Field For Contact Form 7<\\/li>\\n<li>Advanced Custom Field: Audio\\/Video Player<\\/li>\\n<\\/ul>\\n<li>Improve code rendered for the following third party fields:<\\/li>\\n<ul>\\n<li>Advanced Custom Fields: Gravityforms Add-on (including displaying forms, support for Object and ID return types and Single and Multiple values)<\\/li>\\n<li>Advanced Custom Fields: Ninjaforms Add-on (including displaying forms, support for Object and ID return types and Single and Multiple values)<\\/li>\\n<li>TablePress (including support for ID and HTML return types)<\\/li>\\n<li>Table (including caption support and escaping)<\\/li>\\n<li>ACF Icon Selector Field (including escaping)<\\/li>\\n<li>ACF Smart Button (including escaping)<\\/li>\\n<li>Advanced Custom Fields: RGBA Color Field (including escaping)<\\/li>\\n<\\/ul>\\n<li>Update support for the following third party fields:<\\/li>\\n<ul>\\n<li>Advanced Custom Fields: Font Awesome Field<\\/li>\\n<li>Custom Fields: Nav Menu Field<\\/li>\\n<li>ACF Code Field<\\/li>\\n<li>Advanced Custom Fields: SVG Icon<\\/li>\\n<li>ACF YouTube Picker Field<\\/li>\\n<li>ACF Address Field<\\/li>\\n<li>Post Type Select Field for Advanced Custom Fields<\\/li>\\n<li>Advanced Custom Fields: Number Slider<\\/li>\\n<li>ACF Color Palette Field<\\/li>\\n<li>ACF Color Swatches<\\/li>\\n<\\/ul>\\n<li>Remove support for the following third party fields that no longer support the latest version of WordPress or ACF:<\\/li>\\n<ul>\\n<li>ACF qTranslate<\\/li>\\n<li>Advanced Custom Fields: Image Crop<\\/li>\\n<li>Advanced Custom Fields: Markdown Field<\\/li>\\n<li>Advanced Custom Fields: Link Picker Field<\\/li>\\n<li>ACF: Google Font Selector<\\/li>\\n<li>ACF: Focal Point<\\/li>\\n<\\/ul>\\n<li>Ignore `page` field used by Advanced Forms Pro for ACF for multi step forms<\\/li>\\n<\\/ul>\\n<p><strong>2.5.1<\\/strong><\\/p>\\n<ul>\\n<li>Improve support for WordPress 5.6<\\/li>\\n<li>Fix CSS and JS enqueue bugs<\\/li>\\n<li>Fix code formatting bug in \\\"Register ACF Blocks and Options Pages\\\" Tool<\\/li>\\n<li>Add link to Settings page in plugin description on core Plugins page<\\/li>\\n<li>Improve plugin update message on core Plugins page<\\/li>\\n<li>Add instructions to \\\"Download Failed\\\" error message on core Plugins page<\\/li>\\n<li>Updated licensing framework<\\/li>\\n<li>Improve plugin Settings page:\\n<ul>\\n<li>Improve instructions and validation messages<\\/li>\\n<li>Improve design and responsive styles<\\/li>\\n<li>Convert license key field from text input to password input to protect customer license keys<\\/li>\\n<\\/ul>\\n<\\/li>\\n<\\/ul>\\n<p><strong>2.5.0<\\/strong><\\/p>\\n<ul>\\n<li>Improve support for WordPress 5.4.<\\/li>\\n<li>Improve support for all field types included in ACF PRO 5.8.9 (including all their various settings).<\\/li>\\n<li>Improve codebase by syncing both free and pro foundations to facilitate faster development cycles and future features.<\\/li>\\n<li>Add escaping to code rendered to bring it in line with recent updates to ACF field documentation. See\\u00a0https:\\/\\/twitter.com\\/wp_acf\\/status\\/1181344882775875584.<\\/li>\\n<li>Improve code rendered for Taxonomy location.<\\/li>\\n<li>Add support for Current User, Current User Role, User Role locations.<\\/li>\\n<li>Add various enhancements to code rendered for the following fields and field settings:\\n<ul>\\n<li>Gallery field (return types Array, URL and ID)<\\/li>\\n<li>Image (return types Array, URL and ID)<\\/li>\\n<li>File (return types Array, URL and ID)<\\/li>\\n<li>Select (values Single and Multiple, return types Value, Label and Array)<\\/li>\\n<li>Checkbox (return types Value, Label and Array)<\\/li>\\n<li>Radio Button (return type Array)<\\/li>\\n<li>Button Group (return type Array)<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>Link (return types Array and URL)<\\/li>\\n<li>Post Object (values Single and Multiple, return types Post Object and Post ID)<\\/li>\\n<li>Page Link (values Single and Multiple)<\\/li>\\n<li>Relationship (return types Post Object and Post ID)<\\/li>\\n<li>Taxonomy (appearances Checkbox, Multi Select, Radio Buttons and Select, return types Term Object and Term ID)<\\/li>\\n<li>User (values Single and Multiple, return types User Array, User Object and User ID)<\\/li>\\n<li>Google Map<\\/li>\\n<\\/ul>\\n<\\/li>\\n<li>Fixed issue with \'Copy All\' fields functionality.<\\/li>\\n<\\/ul>\\n<p><strong>2.4.0<\\/strong><\\/p>\\n<ul>\\n<li>Core: Theme Code Pro generates code to register for ACF Blocks and Options!<\\/li>\\n<li>Core: Theme Code Pro generates code for use within for ACF Blocks!<\\/li>\\n<li>Core: Radio Button field (core): Add support for all return types<\\/li>\\n<li>Core: Refactoring that will allow for the more options for the code generated in the future<\\/li>\\n<li>New Field Supported: ACF Icon Field<\\/li>\\n<li>New Field Supported: ACF Star Rating Field<\\/li>\\n<li>New Field Supported: ACF Color Palette Field<\\/li>\\n<li>New Field Supported: ACF Image Aspect Ratio Crop<\\/li>\\n<li>New Field Supported: ACF Color Swatches<\\/li>\\n<li>New Field Supported: ACF SVG Icon<\\/li>\\n<\\/ul>\\n<p><strong>2.3.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p><strong>2.2.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p><strong>2.1.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p><strong>2.0.0<\\/strong><\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p><strong>1.2.0<\\/strong><\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p><strong>1.1.0<\\/strong><\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p><strong>1.0.3<\\/strong><\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p><strong>1.0.2<\\/strong><\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n\"},\"banners\":{\"high\":\"\",\"low\":\"\"},\"icons\":\"a:2:{s:2:\\\"1x\\\";s:81:\\\"https:\\/\\/hookturn.io\\/wp-content\\/uploads\\/edd\\/2020\\/05\\/acf-theme-code-pro-128x128.jpg\\\";s:2:\\\"2x\\\";s:81:\\\"https:\\/\\/hookturn.io\\/wp-content\\/uploads\\/edd\\/2020\\/05\\/acf-theme-code-pro-256x256.jpg\\\";}\",\"msg\":\"No license key has been provided.\",\"stable_tag\":\"\",\"tested\":\"\",\"description\":[\"<p><strong>ACF Theme Code Pro saves you time by automatically generating the code needed to implement ACF PRO field groups and ACF Blocks in your WordPress themes.<\\/strong><\\/p>\\n<p><em>\\u201cWork smarter, not harder! Great work on this ACF plugin!\\u201d<\\/em> - Elliot Condon, Creator of Advanced Custom Fields<\\/p>\\n<p>ACF Theme Code Pro is a premium add-on\\u00a0for the awesome\\u00a0<a href=\\\"https:\\/\\/www.advancedcustomfields.com\\/pro\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">Advanced Custom Fields Pro<\\/a>\\u00a0WordPress plugin.<\\/p>\\n<p>The code required to implement your fields is displayed in the <em>Theme Code<\\/em> section at the bottom of your Edit Field Group page.<\\/p>\\n<p><strong>Features<\\/strong><\\/p>\\n<ul>\\n<li>Clipboard icons to easily copy code blocks into your theme<\\/li>\\n<li>Field names and variables are automatically updated<\\/li>\\n<li>Code generated is based on the official ACF documentation and includes escaping<\\/li>\\n<li>Support for field return types and single\\/muliple value options<\\/li>\\n<li>Great for offline ACF documentation<\\/li>\\n<\\/ul>\\n<p><strong>ACF Free, ACF Pro &amp; 3rd party fields <\\/strong><\\/p>\\n<p>Theme Code Pro generates code for all of these fields:<\\/p>\\n<p><strong>ACF Free Fields<\\/strong><\\/p>\\n<ul>\\n<li>Text<\\/li>\\n<li>Text Area<\\/li>\\n<li>Number<\\/li>\\n<li>Range<\\/li>\\n<li>Email<\\/li>\\n<li>URL<\\/li>\\n<li>Password<\\/li>\\n<li>Image<\\/li>\\n<li>File<\\/li>\\n<li>WYSIWYG<\\/li>\\n<li>oEmbed<\\/li>\\n<li>Select<\\/li>\\n<li>Checkbox<\\/li>\\n<li>Radio Button<\\/li>\\n<li>Button Group<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>Link<\\/li>\\n<li>Post Object<\\/li>\\n<li>Page Link<\\/li>\\n<li>Relationship<\\/li>\\n<li>Taxonomy<\\/li>\\n<li>User<\\/li>\\n<li>Google Map<\\/li>\\n<li>Date Picker<\\/li>\\n<li>Date Time Picker<\\/li>\\n<li>Color Picker<\\/li>\\n<li>Group<\\/li>\\n<\\/ul>\\n<p><strong>ACF Pro Fields<\\/strong><\\/p>\\n<ul>\\n<li>Repeater<\\/li>\\n<li>Flexible content<\\/li>\\n<li>Gallery<\\/li>\\n<li>Clone<\\/li>\\n<\\/ul>\\n<p><strong>3rd Party Fields<\\/strong><\\/p>\\n<ul>\\n<li>Font Awesome<\\/li>\\n<li>Gravityforms<\\/li>\\n<li>Ninjaforms<\\/li>\\n<li>Contact Form 7<\\/li>\\n<li>RGBA Colour<\\/li>\\n<li>Color Palette<\\/li>\\n<li>Table<\\/li>\\n<li>TablePress<\\/li>\\n<li>Sidebar Selector<\\/li>\\n<li>Nav Menu<\\/li>\\n<li>Image Aspect Ratio Crop<\\/li>\\n<li>Audio\\/Video Player<\\/li>\\n<li>SVG Icon<\\/li>\\n<li>Icon Selector<\\/li>\\n<li>Code<\\/li>\\n<li>Address<\\/li>\\n<li>Number Slider<\\/li>\\n<li>Star Rating<\\/li>\\n<li>YouTube Picker<\\/li>\\n<li>Post Type Select<\\/li>\\n<li>Smart Button<\\/li>\\n<\\/ul>\\n<p><strong>Location Rule Support<\\/strong><\\/p>\\n<p>ACF Theme Code Pro can generate code for multiple location rules in each field group. This includes more complex locations like <em>Block, Options Page, Widget, Taxonomy, Comment, Attachment, Current User and User Form.<\\/em><\\/p>\\n<p><strong>Create Blocks and Options Pages<\\/strong><\\/p>\\n<p>ACF Theme Code Pro also includes a handy <em>Location Registration Tool<\\/em> that generates the code needed to create new Blocks and Options Pages.<\\/p>\\n<p><strong>Works best with<\\/strong><\\/p>\\n<ul>\\n<li>Advanced Custom Fields Pro v5.9 or higher<\\/li>\\n<li>Advanced Custom Fields Free v5.9 or higher<\\/li>\\n<li>WordPress 5.6 or higher<\\/li>\\n<li>PHP 7.0 or higher<\\/li>\\n<\\/ul>\\n<p><strong>Try our FREE version<\\/strong><\\/p>\\n<p>If you would like to \\u2018try before you buy\\u2019 you can check out our free version <a href=\\\"https:\\/\\/wordpress.org\\/plugins\\/acf-theme-code\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">ACF Theme Code<\\/a> on WordPress.org. This plugin supports all the field types included in free version of Advanced Custom Fields.<\\/p>\\n<p><strong>Hi! We made this<\\/strong><\\/p>\\n<p>The ACF Theme Code Plugin was created by <a href=\\\"http:\\/\\/aaronrutley.com\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">AaronRutley<\\/a> &amp; <a href=\\\"http:\\/\\/benpearson.com.au\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">Ben Pearson<\\/a>, two WordPress developers based in Melbourne, Australia.<\\/p>\\n<p><strong>Theme Code Pro makes developers happy!<\\/strong><\\/p>\\n<p><em>\\u201cGreat time saver - No more constantly referring to the ACF documentation for the right ACF code.\\u201d<\\/em> - David McDonald, Freelance Web Developer<\\/p>\\n<p><em>\\u201cAwesome add-on for ACF - It will certainly speed up theme development.\\u201d<\\/em> - Matthew Heyes, Web Developer &amp; WordPress Specialist<\\/p>\\n<p><em>\\u201cI\'m going to use all the free time this plugin gives me to, I don\'t know, catch up on sleep!\\u201d<\\/em> - Joel Eade, Website Designer<\\/p>\\n<p><em>\\u201cI should have dropped the change a long time ago. AWESOME. Massive time saver. Wish I\\u2019d done it sooner.\\u201d<\\/em> - theatereleven, WordPress Developer<\\/p>\\n\"],\"changelog\":[\"<p><strong>2.5.2<\\/strong><\\/p>\\n<ul>\\n<li>Add support for the following third party fields:<\\/li>\\n<ul>\\n<li>ACF Field For Contact Form 7<\\/li>\\n<li>Advanced Custom Field: Audio\\/Video Player<\\/li>\\n<\\/ul>\\n<li>Improve code rendered for the following third party fields:<\\/li>\\n<ul>\\n<li>Advanced Custom Fields: Gravityforms Add-on (including displaying forms, support for Object and ID return types and Single and Multiple values)<\\/li>\\n<li>Advanced Custom Fields: Ninjaforms Add-on (including displaying forms, support for Object and ID return types and Single and Multiple values)<\\/li>\\n<li>TablePress (including support for ID and HTML return types)<\\/li>\\n<li>Table (including caption support and escaping)<\\/li>\\n<li>ACF Icon Selector Field (including escaping)<\\/li>\\n<li>ACF Smart Button (including escaping)<\\/li>\\n<li>Advanced Custom Fields: RGBA Color Field (including escaping)<\\/li>\\n<\\/ul>\\n<li>Update support for the following third party fields:<\\/li>\\n<ul>\\n<li>Advanced Custom Fields: Font Awesome Field<\\/li>\\n<li>Custom Fields: Nav Menu Field<\\/li>\\n<li>ACF Code Field<\\/li>\\n<li>Advanced Custom Fields: SVG Icon<\\/li>\\n<li>ACF YouTube Picker Field<\\/li>\\n<li>ACF Address Field<\\/li>\\n<li>Post Type Select Field for Advanced Custom Fields<\\/li>\\n<li>Advanced Custom Fields: Number Slider<\\/li>\\n<li>ACF Color Palette Field<\\/li>\\n<li>ACF Color Swatches<\\/li>\\n<\\/ul>\\n<li>Remove support for the following third party fields that no longer support the latest version of WordPress or ACF:<\\/li>\\n<ul>\\n<li>ACF qTranslate<\\/li>\\n<li>Advanced Custom Fields: Image Crop<\\/li>\\n<li>Advanced Custom Fields: Markdown Field<\\/li>\\n<li>Advanced Custom Fields: Link Picker Field<\\/li>\\n<li>ACF: Google Font Selector<\\/li>\\n<li>ACF: Focal Point<\\/li>\\n<\\/ul>\\n<li>Ignore `page` field used by Advanced Forms Pro for ACF for multi step forms<\\/li>\\n<\\/ul>\\n<p><strong>2.5.1<\\/strong><\\/p>\\n<ul>\\n<li>Improve support for WordPress 5.6<\\/li>\\n<li>Fix CSS and JS enqueue bugs<\\/li>\\n<li>Fix code formatting bug in \\\"Register ACF Blocks and Options Pages\\\" Tool<\\/li>\\n<li>Add link to Settings page in plugin description on core Plugins page<\\/li>\\n<li>Improve plugin update message on core Plugins page<\\/li>\\n<li>Add instructions to \\\"Download Failed\\\" error message on core Plugins page<\\/li>\\n<li>Updated licensing framework<\\/li>\\n<li>Improve plugin Settings page:\\n<ul>\\n<li>Improve instructions and validation messages<\\/li>\\n<li>Improve design and responsive styles<\\/li>\\n<li>Convert license key field from text input to password input to protect customer license keys<\\/li>\\n<\\/ul>\\n<\\/li>\\n<\\/ul>\\n<p><strong>2.5.0<\\/strong><\\/p>\\n<ul>\\n<li>Improve support for WordPress 5.4.<\\/li>\\n<li>Improve support for all field types included in ACF PRO 5.8.9 (including all their various settings).<\\/li>\\n<li>Improve codebase by syncing both free and pro foundations to facilitate faster development cycles and future features.<\\/li>\\n<li>Add escaping to code rendered to bring it in line with recent updates to ACF field documentation. See\\u00a0https:\\/\\/twitter.com\\/wp_acf\\/status\\/1181344882775875584.<\\/li>\\n<li>Improve code rendered for Taxonomy location.<\\/li>\\n<li>Add support for Current User, Current User Role, User Role locations.<\\/li>\\n<li>Add various enhancements to code rendered for the following fields and field settings:\\n<ul>\\n<li>Gallery field (return types Array, URL and ID)<\\/li>\\n<li>Image (return types Array, URL and ID)<\\/li>\\n<li>File (return types Array, URL and ID)<\\/li>\\n<li>Select (values Single and Multiple, return types Value, Label and Array)<\\/li>\\n<li>Checkbox (return types Value, Label and Array)<\\/li>\\n<li>Radio Button (return type Array)<\\/li>\\n<li>Button Group (return type Array)<\\/li>\\n<li>True \\/ False<\\/li>\\n<li>Link (return types Array and URL)<\\/li>\\n<li>Post Object (values Single and Multiple, return types Post Object and Post ID)<\\/li>\\n<li>Page Link (values Single and Multiple)<\\/li>\\n<li>Relationship (return types Post Object and Post ID)<\\/li>\\n<li>Taxonomy (appearances Checkbox, Multi Select, Radio Buttons and Select, return types Term Object and Term ID)<\\/li>\\n<li>User (values Single and Multiple, return types User Array, User Object and User ID)<\\/li>\\n<li>Google Map<\\/li>\\n<\\/ul>\\n<\\/li>\\n<li>Fixed issue with \'Copy All\' fields functionality.<\\/li>\\n<\\/ul>\\n<p><strong>2.4.0<\\/strong><\\/p>\\n<ul>\\n<li>Core: Theme Code Pro generates code to register for ACF Blocks and Options!<\\/li>\\n<li>Core: Theme Code Pro generates code for use within for ACF Blocks!<\\/li>\\n<li>Core: Radio Button field (core): Add support for all return types<\\/li>\\n<li>Core: Refactoring that will allow for the more options for the code generated in the future<\\/li>\\n<li>New Field Supported: ACF Icon Field<\\/li>\\n<li>New Field Supported: ACF Star Rating Field<\\/li>\\n<li>New Field Supported: ACF Color Palette Field<\\/li>\\n<li>New Field Supported: ACF Image Aspect Ratio Crop<\\/li>\\n<li>New Field Supported: ACF Color Swatches<\\/li>\\n<li>New Field Supported: ACF SVG Icon<\\/li>\\n<\\/ul>\\n<p><strong>2.3.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: ACF Ninja Forms add on<\\/li>\\n<li>New Field Supported: ACF Gravity Forms add on<\\/li>\\n<li>New Field Supported: ACF RGBA Colour picker<\\/li>\\n<li>New Field(s) Supported: ACF qTranslate<\\/li>\\n<li>Core: Resolved EDD Conflicts<\\/li>\\n<li>Core: Improved Widget Location Variables<\\/li>\\n<li>Fix: EDD naming conflict<\\/li>\\n<li>Fix: Location error if visual editor is disabled<\\/li>\\n<li>Fix: Select Conflict with Seamless Field Group Option<\\/li>\\n<\\/ul>\\n<p><strong>2.2.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: Button Field found in ACF Pro v5.6.3<\\/li>\\n<li>New Field Supported: Range Field found in ACF Pro v5.6.2<\\/li>\\n<li>Core: Copy All Feature Added<\\/li>\\n<\\/ul>\\n<p><strong>2.1.0<\\/strong><\\/p>\\n<ul>\\n<li>New Field Supported: Group Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Link Field found in ACF Pro v5.6<\\/li>\\n<li>New Field Supported: Range Field (Third Party)<\\/li>\\n<li>New Field Supported: Focal Point Field (Third Party)<\\/li>\\n<li>Field: Code field improved to escape output by default<\\/li>\\n<li>Field: Google Map field improved to return lat, lng &amp;\\u00a0address<\\/li>\\n<li>Core: resolved an issue with legacy PHP versions<\\/li>\\n<li>Fix: Bug in File field PHP when returned as a URL<\\/li>\\n<\\/ul>\\n<p><strong>2.0.0<\\/strong><\\/p>\\n<ul>\\n<li>Core : Theme Code Pro now generates code based on your location rules!<\\/li>\\n<li>Core : Theme Code Pro now supports all official ACF Add ons!<\\/li>\\n<li>Core : Theme Code Pro now works when ACF Pro is included in a theme!<\\/li>\\n<li>Location Supported : Options Page<\\/li>\\n<li>Location Supported : Widget<\\/li>\\n<li>Location Supported : Comment<\\/li>\\n<li>Location Supported : Taxonomy Term<\\/li>\\n<li>Location Supported : User<\\/li>\\n<li>Location Supported : Attachment<\\/li>\\n<li>Add-on supported : Options Page<\\/li>\\n<li>Add on supported : Repeater Field<\\/li>\\n<li>Add on supported : Gallery Field<\\/li>\\n<li>Add on supported : Flexible Content Field<\\/li>\\n<li>Fix : Minor bug in file field example link markup<\\/li>\\n<li>Fix : Support for Quicklinks feature within locations<\\/li>\\n<\\/ul>\\n<p><strong>1.2.0<\\/strong><\\/p>\\n<ul>\\n<li>Field : Clone - major improvements to the clone field code output<\\/li>\\n<li>New Field Supported : Address Field<\\/li>\\n<li>New Field Supported : Number Slider Field<\\/li>\\n<li>New Field Supported : Post Type Select Field<\\/li>\\n<li>New Field Supported : Code Field<\\/li>\\n<li>New Field Supported : Link Field<\\/li>\\n<li>New Field Supported : Link Picker Field<\\/li>\\n<li>New Field Supported : YouTube Picker Field<\\/li>\\n<li>Core : Special characters now removed from variable names<\\/li>\\n<li>Fix : Compatibility with CPTUI Pro Plugin<\\/li>\\n<\\/ul>\\n<p><strong>1.1.0<\\/strong><\\/p>\\n<ul>\\n<li>Core: Quicklinks feature with anchor links to the relevant theme code block<\\/li>\\n<li>Core: Notice updates &amp; various bug fixes<\\/li>\\n<li>Core: Plugin options screen moved under Settings<\\/li>\\n<\\/ul>\\n<p><strong>1.0.3<\\/strong><\\/p>\\n<ul>\\n<li>Fix: Use the_sub_field method for nested File fields with return format URL<\\/li>\\n<\\/ul>\\n<p><strong>1.0.2<\\/strong><\\/p>\\n<ul>\\n<li>Field: Fix for Post Object when using ACF 4<\\/li>\\n<li>Core: Various internal code improvements<\\/li>\\n<\\/ul>\\n\"]}\";}', 'no'),
(385, '_site_transient_timeout_browser_65aa2869029c08b5f6f0c1621b8000aa', '1629388288', 'no'),
(386, '_site_transient_browser_65aa2869029c08b5f6f0c1621b8000aa', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"91.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:32:\"https://www.mozilla.org/firefox/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(387, '_transient_health-check-site-status-result', '{\"good\":13,\"recommended\":5,\"critical\":1}', 'yes'),
(391, 'woocommerce_tracker_last_send', '1628783491', 'yes'),
(395, '_transient_shipping-transient-version', '1628783497', 'yes'),
(396, '_transient_timeout_wc_shipping_method_count_legacy', '1631375497', 'no'),
(397, '_transient_wc_shipping_method_count_legacy', 'a:2:{s:7:\"version\";s:10:\"1628783497\";s:5:\"value\";i:0;}', 'no'),
(420, 'disable_gutenberg_options', 'a:31:{s:11:\"disable-all\";i:1;s:23:\"user-role_administrator\";i:1;s:16:\"user-role_editor\";i:1;s:16:\"user-role_author\";i:1;s:21:\"user-role_contributor\";i:1;s:20:\"user-role_subscriber\";i:1;s:18:\"user-role_customer\";i:1;s:22:\"user-role_shop_manager\";i:1;s:14:\"post-type_post\";i:1;s:14:\"post-type_page\";i:1;s:21:\"post-type_wp_template\";i:1;s:25:\"post-type_acf-field-group\";i:1;s:19:\"post-type_acf-field\";i:1;s:17:\"post-type_product\";i:1;s:27:\"post-type_product_variation\";i:1;s:20:\"post-type_shop_order\";i:1;s:27:\"post-type_shop_order_refund\";i:1;s:21:\"post-type_shop_coupon\";i:1;s:9:\"templates\";s:0:\"\";s:8:\"post-ids\";s:0:\"\";s:12:\"whitelist-id\";s:0:\"\";s:14:\"whitelist-slug\";s:0:\"\";s:15:\"whitelist-title\";s:0:\"\";s:15:\"classic-widgets\";i:1;s:11:\"disable-nag\";i:1;s:13:\"styles-enable\";i:0;s:9:\"whitelist\";i:0;s:9:\"hide-menu\";i:0;s:8:\"hide-gut\";i:0;s:12:\"links-enable\";i:0;s:10:\"acf-enable\";i:0;}', 'yes'),
(427, 'bodhi_svgs_plugin_version', '2.3.19', 'yes'),
(433, 'options_site_logo', '13', 'no'),
(434, '_options_site_logo', 'field_611544c1cae30', 'no'),
(436, '_transient_product_query-transient-version', '1629129637', 'yes'),
(437, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(441, 'yit_recently_activated', 'a:1:{i:0;s:34:\"yith-woocommerce-wishlist/init.php\";}', 'yes'),
(442, 'yith_wcwl_wishlist_page_id', '17', 'yes'),
(443, 'yith_wcwl_version', '3.0.25', 'yes'),
(444, 'yith_wcwl_db_version', '3.0.0', 'yes'),
(445, 'yith_wcwl_ajax_enable', 'no', 'yes'),
(446, 'yith_wfbt_enable_integration', 'yes', 'yes'),
(447, 'yith_wcwl_after_add_to_wishlist_behaviour', 'view', 'yes'),
(448, 'yith_wcwl_show_on_loop', 'no', 'yes'),
(449, 'yith_wcwl_loop_position', 'after_add_to_cart', 'yes'),
(450, 'yith_wcwl_button_position', 'after_add_to_cart', 'yes'),
(451, 'yith_wcwl_add_to_wishlist_text', 'Add to wishlist', 'yes'),
(452, 'yith_wcwl_product_added_text', 'Product added!', 'yes'),
(453, 'yith_wcwl_browse_wishlist_text', 'Browse wishlist', 'yes'),
(454, 'yith_wcwl_already_in_wishlist_text', 'The product is already in your wishlist!', 'yes'),
(455, 'yith_wcwl_add_to_wishlist_style', 'link', 'yes'),
(456, 'yith_wcwl_rounded_corners_radius', '16', 'yes'),
(457, 'yith_wcwl_add_to_wishlist_icon', 'fa-heart-o', 'yes'),
(458, 'yith_wcwl_add_to_wishlist_custom_icon', '', 'yes'),
(459, 'yith_wcwl_added_to_wishlist_icon', 'fa-heart', 'yes'),
(460, 'yith_wcwl_added_to_wishlist_custom_icon', '', 'yes'),
(461, 'yith_wcwl_custom_css', '', 'yes'),
(462, 'yith_wcwl_variation_show', '', 'yes'),
(463, 'yith_wcwl_price_show', 'yes', 'yes'),
(464, 'yith_wcwl_stock_show', 'yes', 'yes'),
(465, 'yith_wcwl_show_dateadded', '', 'yes'),
(466, 'yith_wcwl_add_to_cart_show', 'yes', 'yes'),
(467, 'yith_wcwl_show_remove', 'yes', 'yes'),
(468, 'yith_wcwl_repeat_remove_button', '', 'yes'),
(469, 'yith_wcwl_redirect_cart', 'no', 'yes'),
(470, 'yith_wcwl_remove_after_add_to_cart', 'yes', 'yes'),
(471, 'yith_wcwl_enable_share', 'yes', 'yes'),
(472, 'yith_wcwl_share_fb', 'yes', 'yes'),
(473, 'yith_wcwl_share_twitter', 'yes', 'yes'),
(474, 'yith_wcwl_share_pinterest', 'yes', 'yes'),
(475, 'yith_wcwl_share_email', 'yes', 'yes'),
(476, 'yith_wcwl_share_whatsapp', 'yes', 'yes'),
(477, 'yith_wcwl_share_url', 'no', 'yes'),
(478, 'yith_wcwl_socials_title', 'My wishlist on Ullapopken', 'yes'),
(479, 'yith_wcwl_socials_text', '', 'yes'),
(480, 'yith_wcwl_socials_image_url', '', 'yes'),
(481, 'yith_wcwl_wishlist_title', 'My wishlist', 'yes'),
(482, 'yith_wcwl_add_to_cart_text', 'Add to cart', 'yes'),
(483, 'yith_wcwl_add_to_cart_style', 'link', 'yes'),
(484, 'yith_wcwl_add_to_cart_rounded_corners_radius', '16', 'yes'),
(485, 'yith_wcwl_add_to_cart_icon', 'fa-shopping-cart', 'yes'),
(486, 'yith_wcwl_add_to_cart_custom_icon', '', 'yes'),
(487, 'yith_wcwl_color_headers_background', '#F4F4F4', 'yes'),
(488, 'yith_wcwl_fb_button_icon', 'fa-facebook', 'yes'),
(489, 'yith_wcwl_fb_button_custom_icon', '', 'yes'),
(490, 'yith_wcwl_tw_button_icon', 'fa-twitter', 'yes'),
(491, 'yith_wcwl_tw_button_custom_icon', '', 'yes'),
(492, 'yith_wcwl_pr_button_icon', 'fa-pinterest', 'yes'),
(493, 'yith_wcwl_pr_button_custom_icon', '', 'yes'),
(494, 'yith_wcwl_em_button_icon', 'fa-envelope-o', 'yes'),
(495, 'yith_wcwl_em_button_custom_icon', '', 'yes'),
(496, 'yith_wcwl_wa_button_icon', 'fa-whatsapp', 'yes'),
(497, 'yith_wcwl_wa_button_custom_icon', '', 'yes'),
(498, 'yit_plugin_fw_panel_wc_default_options_set', 'a:1:{s:15:\"yith_wcwl_panel\";b:1;}', 'yes'),
(499, 'yith_plugin_fw_promo_2019_bis', '1', 'yes'),
(500, '_site_transient_timeout_yith_promo_message', '3257654326', 'no'),
(501, '_site_transient_yith_promo_message', '<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!-- Default border color: #acc327 -->\n<!-- Default background color: #ecf7ed -->\n\n<promotions>\n    <expiry_date>2019-12-10</expiry_date>\n    <promo>\n        <promo_id>yithblackfriday2019</promo_id>\n        <title><![CDATA[<strong>YITH Black Friday</strong>]]></title>\n        <description><![CDATA[\n            Don\'t miss our <strong>30% discount</strong> on all our products! No coupon needed in cart. Valid from <strong>28th November</strong> to <strong>2nd December</strong>.\n        ]]></description>\n        <link>\n            <label>Get your deals now!</label>\n            <url><![CDATA[https://yithemes.com]]></url>\n        </link>\n        <style>\n            <image_bg_color>#272121</image_bg_color>\n            <border_color>#272121</border_color>\n            <background_color>#ffffff</background_color>\n        </style>\n        <start_date>2019-11-27 23:59:59</start_date>\n        <end_date>2019-12-03 08:00:00</end_date>\n    </promo>\n</promotions>', 'no'),
(505, 'widget_wc_brands_brand_description', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(506, 'widget_woocommerce_brand_nav', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(507, 'widget_wc_brands_brand_thumbnails', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(518, 'woocommerce_clear_ces_tracks_queue_for_page', '', 'yes'),
(519, 'woocommerce_ces_tracks_queue', 'a:0:{}', 'yes'),
(521, 'woocommerce_ces_shown_for_actions', 'a:1:{i:0;s:22:\"add_product_categories\";}', 'yes'),
(629, 'category_children', 'a:0:{}', 'yes'),
(633, 'options_women_menu', '31', 'no'),
(634, '_options_women_menu', 'field_61168a6d0aeed', 'no'),
(635, 'options_men_menu', '', 'no'),
(636, '_options_men_menu', 'field_61168a820aeef', 'no'),
(713, 'ai1wmue_plugin_key', '9f380c82-023e-41f6-ab94-2a84b04f96db', 'yes'),
(717, 'ai1wm_secret_key', 'WzJkZ2YTjxnA', 'yes'),
(719, 'options_promotion', '*13% off everything !\r\n\r\nValid until 15.08.2021. Discount is only valid on goods which are available and may not be combined with other vouchers or promotions. May not be used for the purchase of gift vouchers. Redeemable once online or by phone.', 'no'),
(720, '_options_promotion', 'field_6116971c88e94', 'no'),
(721, 'options_services_0_service', 'All sizes same price', 'no'),
(722, '_options_services_0_service', 'field_6116974788e96', 'no'),
(723, 'options_services_1_service', 'Return within 100 days', 'no'),
(724, '_options_services_1_service', 'field_6116974788e96', 'no'),
(725, 'options_services_2_service', 'SSL Data Security', 'no'),
(726, '_options_services_2_service', 'field_6116974788e96', 'no'),
(727, 'options_services_3_service', 'Alternate shipping address', 'no'),
(728, '_options_services_3_service', 'field_6116974788e96', 'no'),
(729, 'options_services', '4', 'no'),
(730, '_options_services', 'field_6116973c88e95', 'no'),
(731, 'options_telephone', '0049 4402 799 929', 'no'),
(732, '_options_telephone', 'field_6116975f88e97', 'no'),
(733, 'options_open_hour', 'Mon - Fri: 7 am to 10 pm', 'no'),
(734, '_options_open_hour', 'field_6116976888e98', 'no'),
(735, 'options_email', 'email@ullapopken.info', 'no'),
(736, '_options_email', 'field_6116976f88e99', 'no'),
(843, 'ai1wm_status', 'a:2:{s:4:\"type\";s:8:\"download\";s:7:\"message\";s:314:\"<a href=\"http://localhost/ullapopken/wp-content/ai1wm-backups/localhost-ullapopken-20210817-151416-peog68.wpress\" class=\"ai1wm-button-green ai1wm-emphasize ai1wm-button-download\" title=\"localhost\" download=\"localhost-ullapopken-20210817-151416-peog68.wpress\"><span>Download localhost</span><em>Size: 89 MB</em></a>\";}', 'yes'),
(904, '_site_transient_ai1wm_last_check_for_updates', '1629210779', 'no'),
(905, 'ai1wm_updater', 'a:1:{s:43:\"all-in-one-wp-migration-unlimited-extension\";a:13:{s:4:\"name\";s:19:\"Unlimited Extension\";s:4:\"slug\";s:19:\"unlimited-extension\";s:8:\"homepage\";s:51:\"https://servmask.com/extensions/unlimited-extension\";s:13:\"download_link\";s:29:\"https://servmask.com/purchase\";s:7:\"version\";s:4:\"2.42\";s:6:\"author\";s:8:\"ServMask\";s:15:\"author_homepage\";s:20:\"https://servmask.com\";s:8:\"sections\";a:1:{s:11:\"description\";s:259:\"<ul class=\"description\"><li>Remove the import limit of 512MB</li><li>Lifetime license with lifetime updates</li><li>Use on any number of websites that you own</li><li>Unlimited Extension included</li><li>WP CLI commands</li><li>Premium support</li></ul><br />\";}s:7:\"banners\";a:2:{s:3:\"low\";s:65:\"https://servmask.com/img/products/unlimited-extension-772x250.png\";s:4:\"high\";s:66:\"https://servmask.com/img/products/unlimited-extension-1544x500.png\";}s:5:\"icons\";a:3:{s:2:\"1x\";s:65:\"https://servmask.com/img/products/unlimited-extension-128x128.png\";s:2:\"2x\";s:65:\"https://servmask.com/img/products/unlimited-extension-256x256.png\";s:7:\"default\";s:65:\"https://servmask.com/img/products/unlimited-extension-256x256.png\";}s:6:\"rating\";i:99;s:11:\"num_ratings\";i:309;s:10:\"downloaded\";i:40188;}}', 'yes'),
(973, 'options_women_home', '2', 'no'),
(974, '_options_women_home', 'field_6119cfd45bc69', 'no'),
(975, 'options_men_home', '98', 'no'),
(976, '_options_men_home', 'field_6119cfe55bc6a', 'no'),
(1007, 'widget_pwf-woo-filter', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(1020, '_transient_wc_attribute_taxonomies', 'a:3:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:5:\"color\";s:15:\"attribute_label\";s:5:\"Color\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"3\";s:14:\"attribute_name\";s:8:\"material\";s:15:\"attribute_label\";s:8:\"Material\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:2;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:4:\"size\";s:15:\"attribute_label\";s:4:\"Size\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}', 'yes'),
(1063, 'options_women_category', '17', 'no'),
(1064, '_options_women_category', 'field_6119db22e3b3f', 'no'),
(1065, 'options_men_category', '18', 'no'),
(1066, '_options_men_category', 'field_6119db44e3b40', 'no'),
(1120, '_transient_product-transient-version', '1629129637', 'yes'),
(1146, '_transient_timeout_wc_product_children_105', '1631720757', 'no'),
(1147, '_transient_wc_product_children_105', 'a:2:{s:3:\"all\";a:1:{i:0;i:109;}s:7:\"visible\";a:1:{i:0;i:109;}}', 'no'),
(1177, '_transient_timeout_wc_product_children_110', '1631721004', 'no'),
(1178, '_transient_wc_product_children_110', 'a:2:{s:3:\"all\";a:2:{i:0;i:111;i:1;i:112;}s:7:\"visible\";a:2:{i:0;i:111;i:1;i:112;}}', 'no'),
(1184, 'product_cat_children', 'a:3:{i:17;a:20:{i:0;i:67;i:1;i:68;i:2;i:69;i:3;i:70;i:4;i:71;i:5;i:72;i:6;i:73;i:7;i:74;i:8;i:75;i:9;i:76;i:10;i:77;i:11;i:78;i:12;i:79;i:13;i:80;i:14;i:81;i:15;i:82;i:16;i:83;i:17;i:84;i:18;i:85;i:19;i:86;}i:67;a:5:{i:0;i:87;i:1;i:88;i:2;i:89;i:3;i:90;i:4;i:91;}i:70;a:4:{i:0;i:92;i:1;i:93;i:2;i:94;i:3;i:95;}}', 'yes'),
(1252, 'product_brand_children', 'a:0:{}', 'yes'),
(1261, '_transient_timeout_wc_var_prices_110', '1631722255', 'no'),
(1262, '_transient_wc_var_prices_110', '{\"version\":\"1629129637\",\"f9e544f77b7eac7add281ef28ca5559f\":{\"price\":{\"111\":\"29.99\"},\"regular_price\":{\"111\":\"29.99\"},\"sale_price\":{\"111\":\"29.99\"}}}', 'no'),
(1263, '_transient_timeout_wc_var_prices_105', '1631722255', 'no'),
(1264, '_transient_wc_var_prices_105', '{\"version\":\"1629129637\",\"f9e544f77b7eac7add281ef28ca5559f\":{\"price\":{\"109\":\"69.99\"},\"regular_price\":{\"109\":\"69.99\"},\"sale_price\":{\"109\":\"69.99\"}}}', 'no'),
(1277, '_transient_timeout_wc_term_counts', '1631732757', 'no'),
(1278, '_transient_wc_term_counts', 'a:29:{i:70;s:1:\"1\";i:92;s:1:\"1\";i:17;s:1:\"3\";i:15;s:0:\"\";i:18;s:0:\"\";i:67;s:1:\"2\";i:68;s:0:\"\";i:69;s:0:\"\";i:71;s:0:\"\";i:72;s:0:\"\";i:73;s:0:\"\";i:74;s:0:\"\";i:75;s:0:\"\";i:76;s:0:\"\";i:77;s:0:\"\";i:78;s:0:\"\";i:79;s:0:\"\";i:80;s:0:\"\";i:81;s:0:\"\";i:82;s:0:\"\";i:83;s:0:\"\";i:84;s:0:\"\";i:85;s:0:\"\";i:86;s:0:\"\";i:93;s:0:\"\";i:94;s:0:\"\";i:95;s:0:\"\";i:87;s:1:\"1\";i:90;s:1:\"1\";}', 'no'),
(1279, '_transient_timeout_wc_product_children_117', '1631721656', 'no'),
(1280, '_transient_wc_product_children_117', 'a:2:{s:3:\"all\";a:6:{i:0;i:118;i:1;i:123;i:2;i:124;i:3;i:125;i:4;i:126;i:5;i:127;}s:7:\"visible\";a:6:{i:0;i:118;i:1;i:123;i:2;i:124;i:3;i:125;i:4;i:126;i:5;i:127;}}', 'no'),
(1296, '_transient_timeout_wc_var_prices_117', '1631722255', 'no'),
(1297, '_transient_wc_var_prices_117', '{\"version\":\"1629129637\",\"f9e544f77b7eac7add281ef28ca5559f\":{\"price\":{\"118\":\"49.99\",\"123\":\"49.99\",\"124\":\"49.99\",\"125\":\"49.99\",\"126\":\"49.99\",\"127\":\"49.99\"},\"regular_price\":{\"118\":\"49.99\",\"123\":\"49.99\",\"124\":\"49.99\",\"125\":\"49.99\",\"126\":\"49.99\",\"127\":\"49.99\"},\"sale_price\":{\"118\":\"49.99\",\"123\":\"49.99\",\"124\":\"49.99\",\"125\":\"49.99\",\"126\":\"49.99\",\"127\":\"49.99\"}}}', 'no'),
(1351, '_transient_pwf_woo_filter_product_query-transient-version', '1629138550', 'yes'),
(1352, '_transient_timeout_pwf_woo_filter_product_loop_578cb043daf970a39dbb211009c51cdd', '1629224950', 'no'),
(1353, '_transient_pwf_woo_filter_product_loop_578cb043daf970a39dbb211009c51cdd', 'a:2:{s:7:\"version\";s:10:\"1629138550\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:3:{i:0;i:117;i:1;i:110;i:2;i:105;}s:5:\"total\";i:3;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:10;s:12:\"current_page\";i:1;}}', 'no'),
(1363, '_transient_timeout_pwf_woo_filter_product_loop_585396ccfabb29431e72f28cf1335226', '1629225438', 'no'),
(1364, '_transient_pwf_woo_filter_product_loop_585396ccfabb29431e72f28cf1335226', 'a:2:{s:7:\"version\";s:10:\"1629138550\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:3:{i:0;i:117;i:1;i:110;i:2;i:105;}s:5:\"total\";i:3;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:10;s:12:\"current_page\";i:1;}}', 'no'),
(1365, '_transient_timeout_pwf_woo_filter_product_loop_02e63fd1517418ed6148bca670f2be49', '1629225441', 'no'),
(1366, '_transient_pwf_woo_filter_product_loop_02e63fd1517418ed6148bca670f2be49', 'a:2:{s:7:\"version\";s:10:\"1629138550\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:3:{i:0;i:117;i:1;i:105;i:2;i:110;}s:5:\"total\";i:3;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:10;s:12:\"current_page\";i:1;}}', 'no'),
(1376, '_transient_timeout_pwf_woo_filter_product_loop_3da42531d2cce8bb22032d1693d7d144', '1629226147', 'no'),
(1377, '_transient_pwf_woo_filter_product_loop_3da42531d2cce8bb22032d1693d7d144', 'a:2:{s:7:\"version\";s:10:\"1629138550\";s:5:\"value\";O:8:\"stdClass\":5:{s:3:\"ids\";a:1:{i:0;i:117;}s:5:\"total\";i:1;s:11:\"total_pages\";i:1;s:8:\"per_page\";i:10;s:12:\"current_page\";i:1;}}', 'no'),
(1407, '_transient_timeout_wc_child_has_weight_117', '1631732757', 'no'),
(1408, '_transient_wc_child_has_weight_117', '0', 'no'),
(1409, '_transient_timeout_wc_child_has_dimensions_117', '1631732757', 'no'),
(1410, '_transient_wc_child_has_dimensions_117', '0', 'no'),
(1411, '_transient_timeout_wc_related_117', '1629231335', 'no'),
(1412, '_transient_wc_related_117', 'a:1:{s:51:\"limit=4&exclude_ids%5B0%5D=0&exclude_ids%5B1%5D=117\";a:2:{i:0;s:3:\"105\";i:1;s:3:\"110\";}}', 'no'),
(1496, '_transient_timeout_pwf_woo_filter_item_term_counts_pa_size', '1629216255', 'no'),
(1497, '_transient_pwf_woo_filter_item_term_counts_pa_size', 'a:3:{i:0;b:0;s:32:\"34d804702d0eb6714c253702bd017331\";a:5:{i:22;i:1;i:23;i:1;i:25;i:1;i:37;i:1;i:39;i:1;}s:32:\"3874b5de36824110b5730d802d3c9438\";a:5:{i:22;i:1;i:23;i:1;i:25;i:1;i:37;i:1;i:39;i:1;}}', 'no'),
(1498, '_transient_timeout_pwf_woo_filter_item_term_counts_pa_color', '1629216255', 'no'),
(1499, '_transient_pwf_woo_filter_item_term_counts_pa_color', 'a:3:{i:0;b:0;s:32:\"cf8a63d13eab2b5b9be5ab91e8ee7529\";a:5:{i:44;i:1;i:45;i:1;i:47;i:1;i:49;i:1;i:56;i:1;}s:32:\"7b5bfc62da910960546eaa1612090aff\";a:2:{i:44;i:1;i:45;i:1;}}', 'no'),
(1500, '_transient_timeout_pwf_woo_filter_item_price_range_maybe_cache', '1629216255', 'no'),
(1501, '_transient_pwf_woo_filter_item_price_range_maybe_cache', 'a:3:{i:0;b:0;s:32:\"356234f4c493d8b17546741c7045b7ef\";O:8:\"stdClass\":2:{s:9:\"min_price\";s:7:\"29.9900\";s:9:\"max_price\";s:7:\"69.9900\";}s:32:\"953150966185c65dce7caca0dca378c9\";O:8:\"stdClass\":2:{s:9:\"min_price\";s:7:\"49.9900\";s:9:\"max_price\";s:7:\"49.9900\";}}', 'no'),
(1502, '_transient_timeout_pwf_woo_filter_item_term_counts_pa_material', '1629216255', 'no'),
(1503, '_transient_pwf_woo_filter_item_term_counts_pa_material', 'a:3:{i:0;b:0;s:32:\"0f213900c81e289b7dcbefc36e25d8ff\";a:0:{}s:32:\"12fac10e0692284a5eb19e672b3a8695\";a:0:{}}', 'no'),
(1505, '_transient_timeout_acf_plugin_updates', '1629383580', 'no'),
(1506, '_transient_acf_plugin_updates', 'a:4:{s:7:\"plugins\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";a:8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"5.9.9\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:3:\"5.8\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:10:\"expiration\";i:172800;s:6:\"status\";i:1;s:7:\"checked\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.9.5\";}}', 'no'),
(1511, '_transient_timeout__woocommerce_helper_updates', '1629253980', 'no'),
(1512, '_transient__woocommerce_helper_updates', 'a:4:{s:4:\"hash\";s:32:\"bf43d0204900f683dfb24798a705c40a\";s:7:\"updated\";i:1629210780;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1513, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1629210782;s:8:\"response\";a:1:{s:34:\"advanced-custom-fields-pro/acf.php\";O:8:\"stdClass\":8:{s:4:\"slug\";s:26:\"advanced-custom-fields-pro\";s:6:\"plugin\";s:34:\"advanced-custom-fields-pro/acf.php\";s:11:\"new_version\";s:5:\"5.9.9\";s:3:\"url\";s:36:\"https://www.advancedcustomfields.com\";s:6:\"tested\";s:3:\"5.8\";s:7:\"package\";s:0:\"\";s:5:\"icons\";a:1:{s:7:\"default\";s:63:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";s:4:\"high\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:6:{s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:37:\"w.org/plugins/all-in-one-wp-migration\";s:4:\"slug\";s:23:\"all-in-one-wp-migration\";s:6:\"plugin\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:11:\"new_version\";s:4:\"7.46\";s:3:\"url\";s:54:\"https://wordpress.org/plugins/all-in-one-wp-migration/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/all-in-one-wp-migration.7.46.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-256x256.png?rev=2458334\";s:2:\"1x\";s:76:\"https://ps.w.org/all-in-one-wp-migration/assets/icon-128x128.png?rev=2458334\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:79:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-1544x500.jpg?rev=2538919\";s:2:\"1x\";s:78:\"https://ps.w.org/all-in-one-wp-migration/assets/banner-772x250.png?rev=2538919\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"3.3\";}s:39:\"disable-gutenberg/disable-gutenberg.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:31:\"w.org/plugins/disable-gutenberg\";s:4:\"slug\";s:17:\"disable-gutenberg\";s:6:\"plugin\";s:39:\"disable-gutenberg/disable-gutenberg.php\";s:11:\"new_version\";s:5:\"2.5.1\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/disable-gutenberg/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/disable-gutenberg.2.5.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/disable-gutenberg/assets/icon-256x256.png?rev=1925990\";s:2:\"1x\";s:70:\"https://ps.w.org/disable-gutenberg/assets/icon-128x128.png?rev=1925990\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.9\";}s:23:\"wp-smushit/wp-smush.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:24:\"w.org/plugins/wp-smushit\";s:4:\"slug\";s:10:\"wp-smushit\";s:6:\"plugin\";s:23:\"wp-smushit/wp-smush.php\";s:11:\"new_version\";s:5:\"3.8.8\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/wp-smushit/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/wp-smushit.3.8.8.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/wp-smushit/assets/icon-256x256.gif?rev=2263432\";s:2:\"1x\";s:63:\"https://ps.w.org/wp-smushit/assets/icon-128x128.gif?rev=2263431\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/wp-smushit/assets/banner-1544x500.png?rev=1863697\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-smushit/assets/banner-772x250.png?rev=1863697\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.2\";}s:27:\"svg-support/svg-support.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/svg-support\";s:4:\"slug\";s:11:\"svg-support\";s:6:\"plugin\";s:27:\"svg-support/svg-support.php\";s:11:\"new_version\";s:6:\"2.3.19\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/svg-support/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/svg-support.2.3.19.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:64:\"https://ps.w.org/svg-support/assets/icon-256x256.png?rev=1417738\";s:2:\"1x\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";s:3:\"svg\";s:56:\"https://ps.w.org/svg-support/assets/icon.svg?rev=1417738\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/svg-support/assets/banner-1544x500.jpg?rev=1215377\";s:2:\"1x\";s:66:\"https://ps.w.org/svg-support/assets/banner-772x250.jpg?rev=1215377\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"4.8\";}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"5.5.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.5.5.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.5\";}s:34:\"yith-woocommerce-wishlist/init.php\";O:8:\"stdClass\":10:{s:2:\"id\";s:39:\"w.org/plugins/yith-woocommerce-wishlist\";s:4:\"slug\";s:25:\"yith-woocommerce-wishlist\";s:6:\"plugin\";s:34:\"yith-woocommerce-wishlist/init.php\";s:11:\"new_version\";s:6:\"3.0.25\";s:3:\"url\";s:56:\"https://wordpress.org/plugins/yith-woocommerce-wishlist/\";s:7:\"package\";s:75:\"https://downloads.wordpress.org/plugin/yith-woocommerce-wishlist.3.0.25.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:78:\"https://ps.w.org/yith-woocommerce-wishlist/assets/icon-128x128.jpg?rev=2215573\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:81:\"https://ps.w.org/yith-woocommerce-wishlist/assets/banner-1544x500.jpg?rev=2209192\";s:2:\"1x\";s:80:\"https://ps.w.org/yith-woocommerce-wishlist/assets/banner-772x250.jpg?rev=2209192\";}s:11:\"banners_rtl\";a:0:{}s:8:\"requires\";s:3:\"5.6\";}}s:7:\"checked\";a:11:{s:41:\"acf-theme-code-pro/acf_theme_code_pro.php\";s:5:\"2.3.0\";s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"5.9.5\";s:51:\"all-in-one-wp-migration/all-in-one-wp-migration.php\";s:4:\"7.46\";s:91:\"all-in-one-wp-migration-unlimited-extension/all-in-one-wp-migration-unlimited-extension.php\";s:4:\"2.37\";s:39:\"disable-gutenberg/disable-gutenberg.php\";s:5:\"2.5.1\";s:29:\"pwfwoofilter/pwfwoofilter.php\";s:5:\"1.2.6\";s:23:\"wp-smushit/wp-smush.php\";s:5:\"3.8.8\";s:27:\"svg-support/svg-support.php\";s:6:\"2.3.19\";s:27:\"woocommerce/woocommerce.php\";s:5:\"5.5.2\";s:41:\"woocommerce-brands/woocommerce-brands.php\";s:6:\"1.6.25\";s:34:\"yith-woocommerce-wishlist/init.php\";s:6:\"3.0.25\";}}', 'no'),
(1538, 'ai1wm_backups_labels', 'a:0:{}', 'yes'),
(1539, '_site_transient_timeout_theme_roots', '1629215058', 'no'),
(1540, '_site_transient_theme_roots', 'a:2:{s:15:\"twentytwentyone\";s:7:\"/themes\";s:16:\"ullapopken-theme\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'page-home.php'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', 'woocommerce-placeholder.png'),
(4, 5, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(5, 2, '_edit_lock', '1629081917:1'),
(6, 2, '_edit_last', '1'),
(7, 11, '_edit_last', '1'),
(8, 11, '_edit_lock', '1629084266:1'),
(9, 13, '_wp_attached_file', '2021/08/logo-ullapopken.svg'),
(10, 13, '_wp_attachment_metadata', 'a:4:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"file\";s:28:\"/2021/08/logo-ullapopken.svg\";s:5:\"sizes\";a:12:{s:9:\"thumbnail\";a:5:{s:5:\"width\";i:150;s:6:\"height\";i:150;s:4:\"crop\";s:1:\"1\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:6:\"medium\";a:5:{s:5:\"width\";i:300;s:6:\"height\";i:300;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"medium_large\";a:5:{s:5:\"width\";i:768;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:5:\"large\";a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"1536x1536\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:9:\"2048x2048\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:21:\"woocommerce_thumbnail\";a:6:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";s:9:\"uncropped\";s:1:\"0\";}s:18:\"woocommerce_single\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:29:\"woocommerce_gallery_thumbnail\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:12:\"shop_catalog\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:11:\"shop_single\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}s:14:\"shop_thumbnail\";a:5:{s:5:\"width\";i:0;s:6:\"height\";i:0;s:4:\"crop\";s:1:\"0\";s:4:\"file\";s:19:\"logo-ullapopken.svg\";s:9:\"mime-type\";s:13:\"image/svg+xml\";}}}'),
(11, 13, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(12, 14, '_menu_item_type', 'custom'),
(13, 14, '_menu_item_menu_item_parent', '0'),
(14, 14, '_menu_item_object_id', '14'),
(15, 14, '_menu_item_object', 'custom'),
(16, 14, '_menu_item_target', ''),
(17, 14, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(18, 14, '_menu_item_xfn', ''),
(19, 14, '_menu_item_url', '#'),
(21, 15, '_menu_item_type', 'custom'),
(22, 15, '_menu_item_menu_item_parent', '0'),
(23, 15, '_menu_item_object_id', '15'),
(24, 15, '_menu_item_object', 'custom'),
(25, 15, '_menu_item_target', ''),
(26, 15, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(27, 15, '_menu_item_xfn', ''),
(28, 15, '_menu_item_url', '#'),
(30, 16, '_menu_item_type', 'custom'),
(31, 16, '_menu_item_menu_item_parent', '0'),
(32, 16, '_menu_item_object_id', '16'),
(33, 16, '_menu_item_object', 'custom'),
(34, 16, '_menu_item_target', ''),
(35, 16, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(36, 16, '_menu_item_xfn', ''),
(37, 16, '_menu_item_url', '#'),
(39, 17, 'inline_featured_image', '0'),
(42, 19, '_edit_last', '1'),
(43, 19, '_edit_lock', '1628883558:1'),
(44, 31, '_edit_last', '1'),
(45, 31, '_edit_lock', '1628883557:1'),
(46, 32, '_wp_attached_file', '2021/08/9174907551774.jpg'),
(47, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:218;s:6:\"height\";i:145;s:4:\"file\";s:25:\"2021/08/9174907551774.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"9174907551774-150x145.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"9174907551774-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"9174907551774-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(48, 33, '_wp_attached_file', '2021/08/9098161553438.jpg'),
(49, 33, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:218;s:6:\"height\";i:145;s:4:\"file\";s:25:\"2021/08/9098161553438.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"9098161553438-150x145.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"9098161553438-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"9098161553438-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(50, 34, '_wp_attached_file', '2021/08/9187958161438.jpg'),
(51, 34, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:218;s:6:\"height\";i:145;s:4:\"file\";s:25:\"2021/08/9187958161438.jpg\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"9187958161438-150x145.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:145;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"9187958161438-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"9187958161438-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(52, 32, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.235874374410677;s:5:\"bytes\";i:584;s:11:\"size_before\";i:13787;s:10:\"size_after\";i:13203;s:4:\"time\";d:0.07;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.31;s:5:\"bytes\";i:363;s:11:\"size_before\";i:6840;s:10:\"size_after\";i:6477;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.17;s:5:\"bytes\";i:221;s:11:\"size_before\";i:3584;s:10:\"size_after\";i:3363;s:4:\"time\";d:0.03;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3363;s:10:\"size_after\";i:3363;s:4:\"time\";d:0.02;}}}'),
(53, 33, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.41031050168106;s:5:\"bytes\";i:669;s:11:\"size_before\";i:15169;s:10:\"size_after\";i:14500;s:4:\"time\";d:0.05;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.48;s:5:\"bytes\";i:408;s:11:\"size_before\";i:7448;s:10:\"size_after\";i:7040;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.54;s:5:\"bytes\";i:261;s:11:\"size_before\";i:3991;s:10:\"size_after\";i:3730;s:4:\"time\";d:0.01;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3730;s:10:\"size_after\";i:3730;s:4:\"time\";d:0.01;}}}'),
(54, 34, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:5.172215182582652;s:5:\"bytes\";i:898;s:11:\"size_before\";i:17362;s:10:\"size_after\";i:16464;s:4:\"time\";d:0.07;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.78;s:5:\"bytes\";i:585;s:11:\"size_before\";i:8629;s:10:\"size_after\";i:8044;s:4:\"time\";d:0.01;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.92;s:5:\"bytes\";i:313;s:11:\"size_before\";i:4523;s:10:\"size_after\";i:4210;s:4:\"time\";d:0.01;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:4210;s:10:\"size_after\";i:4210;s:4:\"time\";d:0.05;}}}'),
(55, 31, 'menu_layout_0_parent_menu_item', 'a:3:{s:5:\"title\";s:3:\"New\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(56, 31, '_menu_layout_0_parent_menu_item', 'field_611684eff4515'),
(57, 31, 'menu_layout_0_submenu_column', 'column-2'),
(58, 31, '_menu_layout_0_submenu_column', 'field_6116858df4517'),
(59, 31, 'menu_layout_0_sub_menu_layout_0_title', 'New'),
(60, 31, '_menu_layout_0_sub_menu_layout_0_title', 'field_611685e3f4518'),
(61, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_0_menu_item', 'a:3:{s:5:\"title\";s:7:\"See all\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(62, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_0_menu_item', 'field_611685fcf451a'),
(63, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_1_menu_item', 'a:3:{s:5:\"title\";s:11:\"Accessories\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(64, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_1_menu_item', 'field_611685fcf451a'),
(65, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_2_menu_item', 'a:3:{s:5:\"title\";s:9:\"Bathrobes\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(66, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_2_menu_item', 'field_611685fcf451a'),
(67, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_3_menu_item', 'a:3:{s:5:\"title\";s:7:\"Blouses\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(68, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_3_menu_item', 'field_611685fcf451a'),
(69, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_4_menu_item', 'a:3:{s:5:\"title\";s:9:\"Cardigans\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(70, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_4_menu_item', 'field_611685fcf451a'),
(71, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_5_menu_item', 'a:3:{s:5:\"title\";s:5:\"Coats\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(72, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_5_menu_item', 'field_611685fcf451a'),
(73, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_6_menu_item', 'a:3:{s:5:\"title\";s:7:\"Dresses\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(74, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_6_menu_item', 'field_611685fcf451a'),
(75, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_7_menu_item', 'a:3:{s:5:\"title\";s:7:\"Jackets\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(76, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_7_menu_item', 'field_611685fcf451a'),
(77, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_8_menu_item', 'a:3:{s:5:\"title\";s:8:\"Lingerie\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(78, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_8_menu_item', 'field_611685fcf451a'),
(79, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_9_menu_item', 'a:3:{s:5:\"title\";s:10:\"Nightgowns\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(80, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_9_menu_item', 'field_611685fcf451a'),
(81, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_10_menu_item', 'a:3:{s:5:\"title\";s:5:\"Pants\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(82, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_10_menu_item', 'field_611685fcf451a'),
(83, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_11_menu_item', 'a:3:{s:5:\"title\";s:8:\"Sweaters\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(84, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_11_menu_item', 'field_611685fcf451a'),
(85, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_12_menu_item', 'a:3:{s:5:\"title\";s:5:\"Shoes\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(86, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_12_menu_item', 'field_611685fcf451a'),
(87, 31, 'menu_layout_0_sub_menu_layout_0_menu_items_13_menu_item', 'a:3:{s:5:\"title\";s:6:\"Skirts\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(88, 31, '_menu_layout_0_sub_menu_layout_0_menu_items_13_menu_item', 'field_611685fcf451a'),
(89, 31, 'menu_layout_0_sub_menu_layout_0_menu_items', '14'),
(90, 31, '_menu_layout_0_sub_menu_layout_0_menu_items', 'field_611685ecf4519'),
(91, 31, 'menu_layout_0_sub_menu_layout_1_title', 'Collection preview'),
(92, 31, '_menu_layout_0_sub_menu_layout_1_title', 'field_61168628f451c'),
(93, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_0_image', '32'),
(94, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_0_image', 'field_6116864ff451e'),
(95, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_0_link', 'a:3:{s:5:\"title\";s:8:\"November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(96, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_0_link', 'field_6116865df451f'),
(97, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_1_image', '33'),
(98, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_1_image', 'field_6116864ff451e'),
(99, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_1_link', 'a:3:{s:5:\"title\";s:9:\"September\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(100, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_1_link', 'field_6116865df451f'),
(101, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_2_image', '34'),
(102, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_2_image', 'field_6116864ff451e'),
(103, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items_2_link', 'a:3:{s:5:\"title\";s:7:\"October\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(104, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items_2_link', 'field_6116865df451f'),
(105, 31, 'menu_layout_0_sub_menu_layout_1_image_menu_items', '3'),
(106, 31, '_menu_layout_0_sub_menu_layout_1_image_menu_items', 'field_6116862ff451d'),
(107, 31, 'menu_layout_0_sub_menu_layout', 'a:2:{i:0;s:10:\"link_menus\";i:1;s:15:\"image_menu_item\";}'),
(108, 31, '_menu_layout_0_sub_menu_layout', 'field_61168510f4516'),
(109, 31, 'menu_layout_1_parent_menu_item', 'a:3:{s:5:\"title\";s:8:\"Clothing\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(110, 31, '_menu_layout_1_parent_menu_item', 'field_611684eff4515'),
(111, 31, 'menu_layout_1_submenu_column', 'column-2'),
(112, 31, '_menu_layout_1_submenu_column', 'field_6116858df4517'),
(113, 31, 'menu_layout_1_sub_menu_layout', ''),
(114, 31, '_menu_layout_1_sub_menu_layout', 'field_61168510f4516'),
(115, 31, 'menu_layout_2_parent_menu_item', 'a:3:{s:5:\"title\";s:8:\"Lingerie\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(116, 31, '_menu_layout_2_parent_menu_item', 'field_611684eff4515'),
(117, 31, 'menu_layout_2_submenu_column', 'column-2'),
(118, 31, '_menu_layout_2_submenu_column', 'field_6116858df4517'),
(119, 31, 'menu_layout_2_sub_menu_layout', ''),
(120, 31, '_menu_layout_2_sub_menu_layout', 'field_61168510f4516'),
(121, 31, 'menu_layout_3_parent_menu_item', 'a:3:{s:5:\"title\";s:10:\"Sportswear\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(122, 31, '_menu_layout_3_parent_menu_item', 'field_611684eff4515'),
(123, 31, 'menu_layout_3_submenu_column', 'column-2'),
(124, 31, '_menu_layout_3_submenu_column', 'field_6116858df4517'),
(125, 31, 'menu_layout_3_sub_menu_layout', ''),
(126, 31, '_menu_layout_3_sub_menu_layout', 'field_61168510f4516'),
(127, 31, 'menu_layout_4_parent_menu_item', 'a:3:{s:5:\"title\";s:4:\"PURE\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(128, 31, '_menu_layout_4_parent_menu_item', 'field_611684eff4515'),
(129, 31, 'menu_layout_4_submenu_column', 'column-2'),
(130, 31, '_menu_layout_4_submenu_column', 'field_6116858df4517'),
(131, 31, 'menu_layout_4_sub_menu_layout', ''),
(132, 31, '_menu_layout_4_sub_menu_layout', 'field_61168510f4516'),
(133, 31, 'menu_layout_5_parent_menu_item', 'a:3:{s:5:\"title\";s:9:\"selection\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(134, 31, '_menu_layout_5_parent_menu_item', 'field_611684eff4515'),
(135, 31, 'menu_layout_5_submenu_column', 'column-2'),
(136, 31, '_menu_layout_5_submenu_column', 'field_6116858df4517'),
(137, 31, 'menu_layout_5_sub_menu_layout', ''),
(138, 31, '_menu_layout_5_sub_menu_layout', 'field_61168510f4516'),
(139, 31, 'menu_layout_6_parent_menu_item', 'a:3:{s:5:\"title\";s:6:\"Studio\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(140, 31, '_menu_layout_6_parent_menu_item', 'field_611684eff4515'),
(141, 31, 'menu_layout_6_submenu_column', 'column-2'),
(142, 31, '_menu_layout_6_submenu_column', 'field_6116858df4517'),
(143, 31, 'menu_layout_6_sub_menu_layout', ''),
(144, 31, '_menu_layout_6_sub_menu_layout', 'field_61168510f4516'),
(145, 31, 'menu_layout_7_parent_menu_item', 'a:3:{s:5:\"title\";s:5:\"Shoes\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(146, 31, '_menu_layout_7_parent_menu_item', 'field_611684eff4515'),
(147, 31, 'menu_layout_7_submenu_column', 'column-2'),
(148, 31, '_menu_layout_7_submenu_column', 'field_6116858df4517'),
(149, 31, 'menu_layout_7_sub_menu_layout', ''),
(150, 31, '_menu_layout_7_sub_menu_layout', 'field_61168510f4516'),
(151, 31, 'menu_layout_8_parent_menu_item', 'a:3:{s:5:\"title\";s:4:\"Sale\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(152, 31, '_menu_layout_8_parent_menu_item', 'field_611684eff4515'),
(153, 31, 'menu_layout_8_submenu_column', 'column-2'),
(154, 31, '_menu_layout_8_submenu_column', 'field_6116858df4517'),
(155, 31, 'menu_layout_8_sub_menu_layout', ''),
(156, 31, '_menu_layout_8_sub_menu_layout', 'field_61168510f4516'),
(157, 31, 'menu_layout', '9'),
(158, 31, '_menu_layout', 'field_6116849bf4514'),
(159, 31, 'menu_layout_0_custom_class', ''),
(160, 31, '_menu_layout_0_custom_class', 'field_6116885d78376'),
(161, 31, 'menu_layout_0_custom_id', ''),
(162, 31, '_menu_layout_0_custom_id', 'field_61168eb33d2c0'),
(163, 31, 'menu_layout_1_custom_class', ''),
(164, 31, '_menu_layout_1_custom_class', 'field_6116885d78376'),
(165, 31, 'menu_layout_1_custom_id', ''),
(166, 31, '_menu_layout_1_custom_id', 'field_61168eb33d2c0'),
(167, 31, 'menu_layout_2_custom_class', ''),
(168, 31, '_menu_layout_2_custom_class', 'field_6116885d78376'),
(169, 31, 'menu_layout_2_custom_id', ''),
(170, 31, '_menu_layout_2_custom_id', 'field_61168eb33d2c0'),
(171, 31, 'menu_layout_3_custom_class', ''),
(172, 31, '_menu_layout_3_custom_class', 'field_6116885d78376'),
(173, 31, 'menu_layout_3_custom_id', ''),
(174, 31, '_menu_layout_3_custom_id', 'field_61168eb33d2c0'),
(175, 31, 'menu_layout_4_custom_class', ''),
(176, 31, '_menu_layout_4_custom_class', 'field_6116885d78376'),
(177, 31, 'menu_layout_4_custom_id', ''),
(178, 31, '_menu_layout_4_custom_id', 'field_61168eb33d2c0'),
(179, 31, 'menu_layout_5_custom_class', ''),
(180, 31, '_menu_layout_5_custom_class', 'field_6116885d78376'),
(181, 31, 'menu_layout_5_custom_id', ''),
(182, 31, '_menu_layout_5_custom_id', 'field_61168eb33d2c0'),
(183, 31, 'menu_layout_6_custom_class', ''),
(184, 31, '_menu_layout_6_custom_class', 'field_6116885d78376'),
(185, 31, 'menu_layout_6_custom_id', ''),
(186, 31, '_menu_layout_6_custom_id', 'field_61168eb33d2c0'),
(187, 31, 'menu_layout_7_custom_class', ''),
(188, 31, '_menu_layout_7_custom_class', 'field_6116885d78376'),
(189, 31, 'menu_layout_7_custom_id', ''),
(190, 31, '_menu_layout_7_custom_id', 'field_61168eb33d2c0'),
(191, 31, 'menu_layout_8_custom_class', 'sale_menu'),
(192, 31, '_menu_layout_8_custom_class', 'field_6116885d78376'),
(193, 31, 'menu_layout_8_custom_id', ''),
(194, 31, '_menu_layout_8_custom_id', 'field_61168eb33d2c0'),
(195, 40, '_edit_last', '1'),
(196, 40, '_edit_lock', '1628883557:1'),
(199, 69, '_menu_item_type', 'custom'),
(200, 69, '_menu_item_menu_item_parent', '0'),
(201, 69, '_menu_item_object_id', '69'),
(202, 69, '_menu_item_object', 'custom'),
(203, 69, '_menu_item_target', ''),
(204, 69, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(205, 69, '_menu_item_xfn', ''),
(206, 69, '_menu_item_url', '#'),
(208, 70, '_menu_item_type', 'custom'),
(209, 70, '_menu_item_menu_item_parent', '0'),
(210, 70, '_menu_item_object_id', '70'),
(211, 70, '_menu_item_object', 'custom'),
(212, 70, '_menu_item_target', ''),
(213, 70, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(214, 70, '_menu_item_xfn', ''),
(215, 70, '_menu_item_url', '#'),
(217, 71, '_menu_item_type', 'custom'),
(218, 71, '_menu_item_menu_item_parent', '0'),
(219, 71, '_menu_item_object_id', '71'),
(220, 71, '_menu_item_object', 'custom'),
(221, 71, '_menu_item_target', ''),
(222, 71, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(223, 71, '_menu_item_xfn', ''),
(224, 71, '_menu_item_url', '#'),
(226, 72, '_menu_item_type', 'custom'),
(227, 72, '_menu_item_menu_item_parent', '0'),
(228, 72, '_menu_item_object_id', '72'),
(229, 72, '_menu_item_object', 'custom'),
(230, 72, '_menu_item_target', ''),
(231, 72, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(232, 72, '_menu_item_xfn', ''),
(233, 72, '_menu_item_url', '#'),
(235, 73, '_menu_item_type', 'custom'),
(236, 73, '_menu_item_menu_item_parent', '0'),
(237, 73, '_menu_item_object_id', '73'),
(238, 73, '_menu_item_object', 'custom'),
(239, 73, '_menu_item_target', ''),
(240, 73, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(241, 73, '_menu_item_xfn', ''),
(242, 73, '_menu_item_url', '#'),
(244, 74, '_menu_item_type', 'custom'),
(245, 74, '_menu_item_menu_item_parent', '0'),
(246, 74, '_menu_item_object_id', '74'),
(247, 74, '_menu_item_object', 'custom'),
(248, 74, '_menu_item_target', ''),
(249, 74, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(250, 74, '_menu_item_xfn', ''),
(251, 74, '_menu_item_url', '#'),
(253, 75, '_menu_item_type', 'custom'),
(254, 75, '_menu_item_menu_item_parent', '0'),
(255, 75, '_menu_item_object_id', '75'),
(256, 75, '_menu_item_object', 'custom'),
(257, 75, '_menu_item_target', ''),
(258, 75, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(259, 75, '_menu_item_xfn', ''),
(260, 75, '_menu_item_url', '#'),
(262, 76, '_menu_item_type', 'custom'),
(263, 76, '_menu_item_menu_item_parent', '0'),
(264, 76, '_menu_item_object_id', '76'),
(265, 76, '_menu_item_object', 'custom'),
(266, 76, '_menu_item_target', ''),
(267, 76, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(268, 76, '_menu_item_xfn', ''),
(269, 76, '_menu_item_url', '#'),
(271, 77, '_menu_item_type', 'custom'),
(272, 77, '_menu_item_menu_item_parent', '0'),
(273, 77, '_menu_item_object_id', '77'),
(274, 77, '_menu_item_object', 'custom'),
(275, 77, '_menu_item_target', ''),
(276, 77, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(277, 77, '_menu_item_xfn', ''),
(278, 77, '_menu_item_url', '#'),
(280, 78, '_wp_attached_file', '2021/08/8813329317918.png'),
(281, 78, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:36;s:4:\"file\";s:25:\"2021/08/8813329317918.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"8813329317918-150x36.png\";s:5:\"width\";i:150;s:6:\"height\";i:36;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"8813329317918-100x36.png\";s:5:\"width\";i:100;s:6:\"height\";i:36;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"8813329317918-100x36.png\";s:5:\"width\";i:100;s:6:\"height\";i:36;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(282, 78, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:7.180945609669393;s:5:\"bytes\";i:606;s:11:\"size_before\";i:8439;s:10:\"size_after\";i:7833;s:4:\"time\";d:0.11;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:3:{s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.93;s:5:\"bytes\";i:390;s:11:\"size_before\";i:3927;s:10:\"size_after\";i:3537;s:4:\"time\";d:0.08;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:9.14;s:5:\"bytes\";i:216;s:11:\"size_before\";i:2364;s:10:\"size_after\";i:2148;s:4:\"time\";d:0.01;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2148;s:10:\"size_after\";i:2148;s:4:\"time\";d:0.02;}}}'),
(283, 79, '_menu_item_type', 'custom'),
(284, 79, '_menu_item_menu_item_parent', '0'),
(285, 79, '_menu_item_object_id', '79'),
(286, 79, '_menu_item_object', 'custom'),
(287, 79, '_menu_item_target', ''),
(288, 79, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(289, 79, '_menu_item_xfn', ''),
(290, 79, '_menu_item_url', '#'),
(292, 80, '_menu_item_type', 'custom'),
(293, 80, '_menu_item_menu_item_parent', '0'),
(294, 80, '_menu_item_object_id', '80'),
(295, 80, '_menu_item_object', 'custom'),
(296, 80, '_menu_item_target', ''),
(297, 80, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(298, 80, '_menu_item_xfn', ''),
(299, 80, '_menu_item_url', '#'),
(301, 81, '_menu_item_type', 'custom'),
(302, 81, '_menu_item_menu_item_parent', '0'),
(303, 81, '_menu_item_object_id', '81'),
(304, 81, '_menu_item_object', 'custom'),
(305, 81, '_menu_item_target', ''),
(306, 81, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(307, 81, '_menu_item_xfn', ''),
(308, 81, '_menu_item_url', '#'),
(310, 82, '_menu_item_type', 'custom'),
(311, 82, '_menu_item_menu_item_parent', '0'),
(312, 82, '_menu_item_object_id', '82'),
(313, 82, '_menu_item_object', 'custom'),
(314, 82, '_menu_item_target', ''),
(315, 82, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(316, 82, '_menu_item_xfn', ''),
(317, 82, '_menu_item_url', '#'),
(319, 83, '_wp_attached_file', '2021/08/9188995989534.jpg'),
(320, 83, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:500;s:4:\"file\";s:25:\"2021/08/9188995989534.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"9188995989534-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"9188995989534-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"9188995989534-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"9188995989534-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:26:\"9188995989534-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"9188995989534-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";s:1:\"0\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"9188995989534-600x188.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"9188995989534-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"9188995989534-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"9188995989534-600x188.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"9188995989534-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(321, 83, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.273204903677758;s:5:\"bytes\";i:11956;s:11:\"size_before\";i:279790;s:10:\"size_after\";i:267834;s:4:\"time\";d:0.38;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.43;s:5:\"bytes\";i:283;s:11:\"size_before\";i:6394;s:10:\"size_after\";i:6111;s:4:\"time\";d:0.01;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.19;s:5:\"bytes\";i:2723;s:11:\"size_before\";i:52451;s:10:\"size_after\";i:49728;s:4:\"time\";d:0.06;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.28;s:5:\"bytes\";i:291;s:11:\"size_before\";i:5515;s:10:\"size_after\";i:5224;s:4:\"time\";d:0.01;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.09;s:5:\"bytes\";i:1600;s:11:\"size_before\";i:31406;s:10:\"size_after\";i:29806;s:4:\"time\";d:0.02;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.9;s:5:\"bytes\";i:5145;s:11:\"size_before\";i:105070;s:10:\"size_after\";i:99925;s:4:\"time\";d:0.04;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.6;s:5:\"bytes\";i:760;s:11:\"size_before\";i:16529;s:10:\"size_after\";i:15769;s:4:\"time\";d:0.06;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.68;s:5:\"bytes\";i:966;s:11:\"size_before\";i:20662;s:10:\"size_after\";i:19696;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.8;s:5:\"bytes\";i:188;s:11:\"size_before\";i:3243;s:10:\"size_after\";i:3055;s:4:\"time\";d:0.01;}s:12:\"shop_catalog\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:15769;s:10:\"size_after\";i:15769;s:4:\"time\";d:0.05;}s:11:\"shop_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:19696;s:10:\"size_after\";i:19696;s:4:\"time\";d:0.08;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3055;s:10:\"size_after\";i:3055;s:4:\"time\";d:0.02;}}}'),
(322, 84, '_wp_attached_file', '2021/08/banner.png'),
(323, 84, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1140;s:6:\"height\";i:194;s:4:\"file\";s:18:\"2021/08/banner.png\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"banner-300x51.png\";s:5:\"width\";i:300;s:6:\"height\";i:51;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"banner-1024x174.png\";s:5:\"width\";i:1024;s:6:\"height\";i:174;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"banner-768x131.png\";s:5:\"width\";i:768;s:6:\"height\";i:131;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"banner-600x102.png\";s:5:\"width\";i:600;s:6:\"height\";i:102;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"banner-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"banner-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"banner-600x102.png\";s:5:\"width\";i:600;s:6:\"height\";i:102;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"banner-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(324, 84, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:29.536213067900064;s:5:\"bytes\";i:65519;s:11:\"size_before\";i:221826;s:10:\"size_after\";i:156307;s:4:\"time\";d:2.09;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:10:{s:12:\"shop_catalog\";O:8:\"stdClass\":5:{s:7:\"percent\";d:33.95;s:5:\"bytes\";i:7032;s:11:\"size_before\";i:20710;s:10:\"size_after\";i:13678;s:4:\"time\";d:0.06;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:33.95;s:5:\"bytes\";i:9990;s:11:\"size_before\";i:20710;s:10:\"size_after\";i:13678;s:4:\"time\";d:0.07;}s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:20.81;s:5:\"bytes\";i:1067;s:11:\"size_before\";i:5127;s:10:\"size_after\";i:4060;s:4:\"time\";d:0.08;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:35.42;s:5:\"bytes\";i:29953;s:11:\"size_before\";i:84570;s:10:\"size_after\";i:54617;s:4:\"time\";d:0.47;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:33.95;s:5:\"bytes\";i:7032;s:11:\"size_before\";i:20710;s:10:\"size_after\";i:13678;s:4:\"time\";d:0.3;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:25.36;s:5:\"bytes\";i:6186;s:11:\"size_before\";i:24394;s:10:\"size_after\";i:18208;s:4:\"time\";d:0.4;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:25.96;s:5:\"bytes\";i:4220;s:11:\"size_before\";i:16255;s:10:\"size_after\";i:12035;s:4:\"time\";d:0.37;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:29.51;s:5:\"bytes\";i:2997;s:11:\"size_before\";i:10156;s:10:\"size_after\";i:7159;s:4:\"time\";d:0.15;}s:11:\"shop_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:12035;s:10:\"size_after\";i:12035;s:4:\"time\";d:0.1;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:7159;s:10:\"size_after\";i:7159;s:4:\"time\";d:0.09;}}}'),
(325, 2, 'top_banner', '83'),
(326, 2, '_top_banner', 'field_611695387762b'),
(327, 2, 'top_banner_title', 'New In'),
(328, 2, '_top_banner_title', 'field_611695477762c'),
(329, 2, 'top_banner_content', 'Discover our new collecion'),
(330, 2, '_top_banner_content', 'field_6116956b7762d'),
(331, 2, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(332, 2, '_top_banner_link', 'field_611695767762e'),
(333, 2, 'banner', '84'),
(334, 2, '_banner', 'field_6116958f7762f'),
(335, 2, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(336, 2, '_banner_link', 'field_6116959777630'),
(337, 2, 'trends_title', 'Current topics and trends'),
(338, 2, '_trends_title', 'field_611695b277631'),
(339, 2, 'trends', '4'),
(340, 2, '_trends', 'field_611695bc77632'),
(341, 2, 'featured_banner', '91'),
(342, 2, '_featured_banner', 'field_61169603f4a63'),
(343, 2, 'featured_banner_link', 'a:3:{s:5:\"title\";s:14:\"Denim Accepted\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(344, 2, '_featured_banner_link', 'field_61169624f4a65'),
(345, 2, 'featured_banner_content', 'We say that denim is what you make of it.'),
(346, 2, '_featured_banner_content', 'field_61169632f4a66'),
(347, 2, 'subscribe_text', '<h3 style=\"text-align: center;\">10€ VOUCHER</h3>\r\n<p style=\"text-align: center;\">for subscribing!</p>'),
(348, 2, '_subscribe_text', 'field_611696792d3b9'),
(349, 2, 'subscribe_link', 'a:3:{s:5:\"title\";s:12:\"Register now\";s:3:\"url\";s:39:\"http://localhost/ullapopken/my-account/\";s:6:\"target\";s:0:\"\";}'),
(350, 2, '_subscribe_link', 'field_611696842d3ba'),
(351, 2, 'about_title', 'Individual and trendy fashion in big sizes'),
(352, 2, '_about_title', 'field_611696992d3bb'),
(353, 2, 'about_content', 'There were times when it was almost impossible for people of all ages to dress fashion-consciously and dress appropriately. The fashion for large sizes at that time consisted of inconspicuous, baggy garments, which often seemed more than unfavorable and in the worst case visually even applied a few kilos. But a lot has happened since then. Not least thanks to role models from film and television, curvy people have found new self-confidence and only want to let their taste and not the offer decide on their clothing style.\r\n\r\nThe industry has responded by producing trendy fashion and big sizes so that everyone can dress according to their preferences, regardless of their size and weight. At Ulla Popken you will find a wide selection of fashion items for tall people, with which you can create your very own style. Figurative cuts and flowing fabrics in high quality emphasize your preferences and conceal the problem areas.\r\n\r\nFresh colors and patterned fabrics follow the latest trends, turning classic, plain-colored basics into outfits that leave fashionable everyday life behind. Sometimes it can be difficult to find the right outfit of the right size for a formal or formal occasion. Especially in shops and non-specialized online shops, the selection is often limited. But here you will find fashion in oversize, which fits all occasions.\r\n\r\nOf course it can also be more courageous. Who puts his advantages such as a slender waist or long legs in scene - whether with a tailored skirt, a pair of pants or a belted trench coat - can hide the less loved places with appropriate materials, cuts and colors. With fashion from Ulla Popken in sizes 42 to 68 you are always on the right page.'),
(354, 2, '_about_content', 'field_611696a12d3bc'),
(355, 85, 'top_banner', '83'),
(356, 85, '_top_banner', 'field_611695387762b'),
(357, 85, 'top_banner_title', 'New In'),
(358, 85, '_top_banner_title', 'field_611695477762c'),
(359, 85, 'top_banner_content', 'Discover our new collecion'),
(360, 85, '_top_banner_content', 'field_6116956b7762d'),
(361, 85, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(362, 85, '_top_banner_link', 'field_611695767762e'),
(363, 85, 'banner', '84'),
(364, 85, '_banner', 'field_6116958f7762f'),
(365, 85, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(366, 85, '_banner_link', 'field_6116959777630'),
(367, 85, 'trends_title', 'Current topics and trends'),
(368, 85, '_trends_title', 'field_611695b277631'),
(369, 85, 'trends', ''),
(370, 85, '_trends', 'field_611695bc77632'),
(371, 85, 'featured_banner', ''),
(372, 85, '_featured_banner', 'field_61169603f4a63'),
(373, 85, 'featured_banner_link', ''),
(374, 85, '_featured_banner_link', 'field_61169624f4a65'),
(375, 85, 'featured_banner_content', ''),
(376, 85, '_featured_banner_content', 'field_61169632f4a66'),
(377, 85, 'subscribe_text', ''),
(378, 85, '_subscribe_text', 'field_611696792d3b9'),
(379, 85, 'subscribe_link', ''),
(380, 85, '_subscribe_link', 'field_611696842d3ba'),
(381, 85, 'about_title', ''),
(382, 85, '_about_title', 'field_611696992d3bb'),
(383, 85, 'about_content', ''),
(384, 85, '_about_content', 'field_611696a12d3bc'),
(385, 2, 'inline_featured_image', '0'),
(386, 86, '_wp_attached_file', '2021/08/up_dy_campaign_vorschau.webp'),
(387, 86, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:420;s:6:\"height\";i:680;s:4:\"file\";s:36:\"2021/08/up_dy_campaign_vorschau.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-185x300.webp\";s:5:\"width\";i:185;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_vorschau-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(388, 86, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(389, 87, '_wp_attached_file', '2021/08/up_dy_campaign_socken.webp'),
(390, 87, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:420;s:6:\"height\";i:680;s:4:\"file\";s:34:\"2021/08/up_dy_campaign_socken.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"up_dy_campaign_socken-185x300.webp\";s:5:\"width\";i:185;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"up_dy_campaign_socken-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:34:\"up_dy_campaign_socken-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:34:\"up_dy_campaign_socken-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:34:\"up_dy_campaign_socken-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:34:\"up_dy_campaign_socken-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(391, 87, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(392, 88, '_wp_attached_file', '2021/08/up_dy_campaign_bohemian.webp'),
(393, 88, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:420;s:6:\"height\";i:680;s:4:\"file\";s:36:\"2021/08/up_dy_campaign_bohemian.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-185x300.webp\";s:5:\"width\";i:185;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_bohemian-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(394, 88, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(395, 89, '_wp_attached_file', '2021/08/up_dy_campaign_neuheiten.jpg'),
(396, 89, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:420;s:6:\"height\";i:680;s:4:\"file\";s:36:\"2021/08/up_dy_campaign_neuheiten.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-185x300.jpg\";s:5:\"width\";i:185;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:36:\"up_dy_campaign_neuheiten-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(397, 89, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:3.543237311011438;s:5:\"bytes\";i:2599;s:11:\"size_before\";i:73351;s:10:\"size_after\";i:70752;s:4:\"time\";d:0.2;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.52;s:5:\"bytes\";i:870;s:11:\"size_before\";i:15754;s:10:\"size_after\";i:14884;s:4:\"time\";d:0.03;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.15;s:5:\"bytes\";i:452;s:11:\"size_before\";i:7344;s:10:\"size_after\";i:6892;s:4:\"time\";d:0.05;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.63;s:5:\"bytes\";i:1002;s:11:\"size_before\";i:21623;s:10:\"size_after\";i:20621;s:4:\"time\";d:0.03;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.64;s:5:\"bytes\";i:275;s:11:\"size_before\";i:4142;s:10:\"size_after\";i:3867;s:4:\"time\";d:0.04;}s:12:\"shop_catalog\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:20621;s:10:\"size_after\";i:20621;s:4:\"time\";d:0.04;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3867;s:10:\"size_after\";i:3867;s:4:\"time\";d:0.01;}}}'),
(398, 2, 'trends_0_image', '89'),
(399, 2, '_trends_0_image', 'field_611695c977633'),
(400, 2, 'trends_0_title', 'Discover our new summer collection');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(401, 2, '_trends_0_title', 'field_611695d577634'),
(402, 2, 'trends_0_link', 'a:3:{s:5:\"title\";s:6:\"New In\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(403, 2, '_trends_0_link', 'field_611695de77635'),
(404, 2, 'trends_1_image', '86'),
(405, 2, '_trends_1_image', 'field_611695c977633'),
(406, 2, 'trends_1_title', 'Discover now'),
(407, 2, '_trends_1_title', 'field_611695d577634'),
(408, 2, 'trends_1_link', 'a:3:{s:5:\"title\";s:16:\"Preview November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(409, 2, '_trends_1_link', 'field_611695de77635'),
(410, 2, 'trends_2_image', '87'),
(411, 2, '_trends_2_image', 'field_611695c977633'),
(412, 2, 'trends_2_title', 'Discover now'),
(413, 2, '_trends_2_title', 'field_611695d577634'),
(414, 2, 'trends_2_link', 'a:3:{s:5:\"title\";s:5:\"Socks\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(415, 2, '_trends_2_link', 'field_611695de77635'),
(416, 2, 'trends_3_image', '88'),
(417, 2, '_trends_3_image', 'field_611695c977633'),
(418, 2, 'trends_3_title', 'Looks to be happy'),
(419, 2, '_trends_3_title', 'field_611695d577634'),
(420, 2, 'trends_3_link', 'a:3:{s:5:\"title\";s:13:\"Bohemian Flow\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(421, 2, '_trends_3_link', 'field_611695de77635'),
(422, 90, 'top_banner', '83'),
(423, 90, '_top_banner', 'field_611695387762b'),
(424, 90, 'top_banner_title', 'New In'),
(425, 90, '_top_banner_title', 'field_611695477762c'),
(426, 90, 'top_banner_content', 'Discover our new collecion'),
(427, 90, '_top_banner_content', 'field_6116956b7762d'),
(428, 90, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(429, 90, '_top_banner_link', 'field_611695767762e'),
(430, 90, 'banner', '84'),
(431, 90, '_banner', 'field_6116958f7762f'),
(432, 90, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(433, 90, '_banner_link', 'field_6116959777630'),
(434, 90, 'trends_title', 'Current topics and trends'),
(435, 90, '_trends_title', 'field_611695b277631'),
(436, 90, 'trends', '4'),
(437, 90, '_trends', 'field_611695bc77632'),
(438, 90, 'featured_banner', ''),
(439, 90, '_featured_banner', 'field_61169603f4a63'),
(440, 90, 'featured_banner_link', ''),
(441, 90, '_featured_banner_link', 'field_61169624f4a65'),
(442, 90, 'featured_banner_content', ''),
(443, 90, '_featured_banner_content', 'field_61169632f4a66'),
(444, 90, 'subscribe_text', ''),
(445, 90, '_subscribe_text', 'field_611696792d3b9'),
(446, 90, 'subscribe_link', ''),
(447, 90, '_subscribe_link', 'field_611696842d3ba'),
(448, 90, 'about_title', ''),
(449, 90, '_about_title', 'field_611696992d3bb'),
(450, 90, 'about_content', ''),
(451, 90, '_about_content', 'field_611696a12d3bc'),
(452, 90, 'trends_0_image', '89'),
(453, 90, '_trends_0_image', 'field_611695c977633'),
(454, 90, 'trends_0_title', 'Discover our new summer collection'),
(455, 90, '_trends_0_title', 'field_611695d577634'),
(456, 90, 'trends_0_link', 'a:3:{s:5:\"title\";s:6:\"New In\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(457, 90, '_trends_0_link', 'field_611695de77635'),
(458, 90, 'trends_1_image', '86'),
(459, 90, '_trends_1_image', 'field_611695c977633'),
(460, 90, 'trends_1_title', 'Discover now'),
(461, 90, '_trends_1_title', 'field_611695d577634'),
(462, 90, 'trends_1_link', 'a:3:{s:5:\"title\";s:16:\"Preview November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(463, 90, '_trends_1_link', 'field_611695de77635'),
(464, 90, 'trends_2_image', '87'),
(465, 90, '_trends_2_image', 'field_611695c977633'),
(466, 90, 'trends_2_title', 'Discover now'),
(467, 90, '_trends_2_title', 'field_611695d577634'),
(468, 90, 'trends_2_link', 'a:3:{s:5:\"title\";s:5:\"Socks\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(469, 90, '_trends_2_link', 'field_611695de77635'),
(470, 90, 'trends_3_image', '88'),
(471, 90, '_trends_3_image', 'field_611695c977633'),
(472, 90, 'trends_3_title', 'Looks to be happy'),
(473, 90, '_trends_3_title', 'field_611695d577634'),
(474, 90, 'trends_3_link', 'a:3:{s:5:\"title\";s:13:\"Bohemian Flow\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(475, 90, '_trends_3_link', 'field_611695de77635'),
(476, 91, '_wp_attached_file', '2021/08/70ff05712de1__up_kw29_herol_denim.jpg'),
(477, 91, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:500;s:4:\"file\";s:45:\"2021/08/70ff05712de1__up_kw29_herol_denim.jpg\";s:5:\"sizes\";a:11:{s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"70ff05712de1__up_kw29_herol_denim-300x94.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:94;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:46:\"70ff05712de1__up_kw29_herol_denim-1024x320.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:320;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-768x240.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:240;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:46:\"70ff05712de1__up_kw29_herol_denim-1536x480.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";s:1:\"0\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-600x188.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-600x188.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:45:\"70ff05712de1__up_kw29_herol_denim-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(478, 91, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:4.031506693033161;s:5:\"bytes\";i:16962;s:11:\"size_before\";i:420736;s:10:\"size_after\";i:403774;s:4:\"time\";d:0.53;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:11:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:6.38;s:5:\"bytes\";i:590;s:11:\"size_before\";i:9253;s:10:\"size_after\";i:8663;s:4:\"time\";d:0.07;}s:5:\"large\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.75;s:5:\"bytes\";i:3712;s:11:\"size_before\";i:78071;s:10:\"size_after\";i:74359;s:4:\"time\";d:0.11;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.79;s:5:\"bytes\";i:418;s:11:\"size_before\";i:7214;s:10:\"size_after\";i:6796;s:4:\"time\";d:0.03;}s:12:\"medium_large\";O:8:\"stdClass\":5:{s:7:\"percent\";i:5;s:5:\"bytes\";i:2314;s:11:\"size_before\";i:46274;s:10:\"size_after\";i:43960;s:4:\"time\";d:0.01;}s:9:\"1536x1536\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.11;s:5:\"bytes\";i:6772;s:11:\"size_before\";i:164750;s:10:\"size_after\";i:157978;s:4:\"time\";d:0.06;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.17;s:5:\"bytes\";i:1290;s:11:\"size_before\";i:24928;s:10:\"size_after\";i:23638;s:4:\"time\";d:0.04;}s:18:\"woocommerce_single\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.23;s:5:\"bytes\";i:1585;s:11:\"size_before\";i:30300;s:10:\"size_after\";i:28715;s:4:\"time\";d:0.06;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:7.14;s:5:\"bytes\";i:281;s:11:\"size_before\";i:3937;s:10:\"size_after\";i:3656;s:4:\"time\";d:0.03;}s:12:\"shop_catalog\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:23638;s:10:\"size_after\";i:23638;s:4:\"time\";d:0.02;}s:11:\"shop_single\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:28715;s:10:\"size_after\";i:28715;s:4:\"time\";d:0.07;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:3656;s:10:\"size_after\";i:3656;s:4:\"time\";d:0.03;}}}'),
(479, 92, 'top_banner', '83'),
(480, 92, '_top_banner', 'field_611695387762b'),
(481, 92, 'top_banner_title', 'New In'),
(482, 92, '_top_banner_title', 'field_611695477762c'),
(483, 92, 'top_banner_content', 'Discover our new collecion'),
(484, 92, '_top_banner_content', 'field_6116956b7762d'),
(485, 92, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(486, 92, '_top_banner_link', 'field_611695767762e'),
(487, 92, 'banner', '84'),
(488, 92, '_banner', 'field_6116958f7762f'),
(489, 92, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(490, 92, '_banner_link', 'field_6116959777630'),
(491, 92, 'trends_title', 'Current topics and trends'),
(492, 92, '_trends_title', 'field_611695b277631'),
(493, 92, 'trends', '4'),
(494, 92, '_trends', 'field_611695bc77632'),
(495, 92, 'featured_banner', '91'),
(496, 92, '_featured_banner', 'field_61169603f4a63'),
(497, 92, 'featured_banner_link', 'a:3:{s:5:\"title\";s:14:\"Denim Accepted\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(498, 92, '_featured_banner_link', 'field_61169624f4a65'),
(499, 92, 'featured_banner_content', 'We say that denim is what you make of it.'),
(500, 92, '_featured_banner_content', 'field_61169632f4a66'),
(501, 92, 'subscribe_text', '<h3 style=\"text-align: center;\">10€ VOUCHER</h3>\r\n<p style=\"text-align: center;\">for subscribing!</p>'),
(502, 92, '_subscribe_text', 'field_611696792d3b9'),
(503, 92, 'subscribe_link', 'a:3:{s:5:\"title\";s:12:\"Register now\";s:3:\"url\";s:39:\"http://localhost/ullapopken/my-account/\";s:6:\"target\";s:0:\"\";}'),
(504, 92, '_subscribe_link', 'field_611696842d3ba'),
(505, 92, 'about_title', 'Individual and trendy fashion in big sizes'),
(506, 92, '_about_title', 'field_611696992d3bb'),
(507, 92, 'about_content', 'There were times when it was almost impossible for people of all ages to dress fashion-consciously and dress appropriately. The fashion for large sizes at that time consisted of inconspicuous, baggy garments, which often seemed more than unfavorable and in the worst case visually even applied a few kilos. But a lot has happened since then. Not least thanks to role models from film and television, curvy people have found new self-confidence and only want to let their taste and not the offer decide on their clothing style.\r\n\r\nThe industry has responded by producing trendy fashion and big sizes so that everyone can dress according to their preferences, regardless of their size and weight. At Ulla Popken you will find a wide selection of fashion items for tall people, with which you can create your very own style. Figurative cuts and flowing fabrics in high quality emphasize your preferences and conceal the problem areas.\r\n\r\nFresh colors and patterned fabrics follow the latest trends, turning classic, plain-colored basics into outfits that leave fashionable everyday life behind. Sometimes it can be difficult to find the right outfit of the right size for a formal or formal occasion. Especially in shops and non-specialized online shops, the selection is often limited. But here you will find fashion in oversize, which fits all occasions.\r\n\r\nOf course it can also be more courageous. Who puts his advantages such as a slender waist or long legs in scene - whether with a tailored skirt, a pair of pants or a belted trench coat - can hide the less loved places with appropriate materials, cuts and colors. With fashion from Ulla Popken in sizes 42 to 68 you are always on the right page.'),
(508, 92, '_about_content', 'field_611696a12d3bc'),
(509, 92, 'trends_0_image', '89'),
(510, 92, '_trends_0_image', 'field_611695c977633'),
(511, 92, 'trends_0_title', 'Discover our new summer collection'),
(512, 92, '_trends_0_title', 'field_611695d577634'),
(513, 92, 'trends_0_link', 'a:3:{s:5:\"title\";s:6:\"New In\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(514, 92, '_trends_0_link', 'field_611695de77635'),
(515, 92, 'trends_1_image', '86'),
(516, 92, '_trends_1_image', 'field_611695c977633'),
(517, 92, 'trends_1_title', 'Discover now'),
(518, 92, '_trends_1_title', 'field_611695d577634'),
(519, 92, 'trends_1_link', 'a:3:{s:5:\"title\";s:16:\"Preview November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(520, 92, '_trends_1_link', 'field_611695de77635'),
(521, 92, 'trends_2_image', '87'),
(522, 92, '_trends_2_image', 'field_611695c977633'),
(523, 92, 'trends_2_title', 'Discover now'),
(524, 92, '_trends_2_title', 'field_611695d577634'),
(525, 92, 'trends_2_link', 'a:3:{s:5:\"title\";s:5:\"Socks\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(526, 92, '_trends_2_link', 'field_611695de77635'),
(527, 92, 'trends_3_image', '88'),
(528, 92, '_trends_3_image', 'field_611695c977633'),
(529, 92, 'trends_3_title', 'Looks to be happy'),
(530, 92, '_trends_3_title', 'field_611695d577634'),
(531, 92, 'trends_3_link', 'a:3:{s:5:\"title\";s:13:\"Bohemian Flow\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(532, 92, '_trends_3_link', 'field_611695de77635'),
(533, 2, 'trends_0_color', '#191c45'),
(534, 2, '_trends_0_color', 'field_6116a014d1ca5'),
(535, 2, 'trends_1_color', '#a4bcd7'),
(536, 2, '_trends_1_color', 'field_6116a014d1ca5'),
(537, 2, 'trends_2_color', '#c1815d'),
(538, 2, '_trends_2_color', 'field_6116a014d1ca5'),
(539, 2, 'trends_3_color', '#a4bcd7'),
(540, 2, '_trends_3_color', 'field_6116a014d1ca5'),
(541, 94, 'top_banner', '83'),
(542, 94, '_top_banner', 'field_611695387762b'),
(543, 94, 'top_banner_title', 'New In'),
(544, 94, '_top_banner_title', 'field_611695477762c'),
(545, 94, 'top_banner_content', 'Discover our new collecion'),
(546, 94, '_top_banner_content', 'field_6116956b7762d'),
(547, 94, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(548, 94, '_top_banner_link', 'field_611695767762e'),
(549, 94, 'banner', '84'),
(550, 94, '_banner', 'field_6116958f7762f'),
(551, 94, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(552, 94, '_banner_link', 'field_6116959777630'),
(553, 94, 'trends_title', 'Current topics and trends'),
(554, 94, '_trends_title', 'field_611695b277631'),
(555, 94, 'trends', '4'),
(556, 94, '_trends', 'field_611695bc77632'),
(557, 94, 'featured_banner', '91'),
(558, 94, '_featured_banner', 'field_61169603f4a63'),
(559, 94, 'featured_banner_link', 'a:3:{s:5:\"title\";s:14:\"Denim Accepted\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(560, 94, '_featured_banner_link', 'field_61169624f4a65'),
(561, 94, 'featured_banner_content', 'We say that denim is what you make of it.'),
(562, 94, '_featured_banner_content', 'field_61169632f4a66'),
(563, 94, 'subscribe_text', '<h3 style=\"text-align: center;\">10€ VOUCHER</h3>\r\n<p style=\"text-align: center;\">for subscribing!</p>'),
(564, 94, '_subscribe_text', 'field_611696792d3b9'),
(565, 94, 'subscribe_link', 'a:3:{s:5:\"title\";s:12:\"Register now\";s:3:\"url\";s:39:\"http://localhost/ullapopken/my-account/\";s:6:\"target\";s:0:\"\";}'),
(566, 94, '_subscribe_link', 'field_611696842d3ba'),
(567, 94, 'about_title', 'Individual and trendy fashion in big sizes'),
(568, 94, '_about_title', 'field_611696992d3bb'),
(569, 94, 'about_content', 'There were times when it was almost impossible for people of all ages to dress fashion-consciously and dress appropriately. The fashion for large sizes at that time consisted of inconspicuous, baggy garments, which often seemed more than unfavorable and in the worst case visually even applied a few kilos. But a lot has happened since then. Not least thanks to role models from film and television, curvy people have found new self-confidence and only want to let their taste and not the offer decide on their clothing style.\r\n\r\nThe industry has responded by producing trendy fashion and big sizes so that everyone can dress according to their preferences, regardless of their size and weight. At Ulla Popken you will find a wide selection of fashion items for tall people, with which you can create your very own style. Figurative cuts and flowing fabrics in high quality emphasize your preferences and conceal the problem areas.\r\n\r\nFresh colors and patterned fabrics follow the latest trends, turning classic, plain-colored basics into outfits that leave fashionable everyday life behind. Sometimes it can be difficult to find the right outfit of the right size for a formal or formal occasion. Especially in shops and non-specialized online shops, the selection is often limited. But here you will find fashion in oversize, which fits all occasions.\r\n\r\nOf course it can also be more courageous. Who puts his advantages such as a slender waist or long legs in scene - whether with a tailored skirt, a pair of pants or a belted trench coat - can hide the less loved places with appropriate materials, cuts and colors. With fashion from Ulla Popken in sizes 42 to 68 you are always on the right page.'),
(570, 94, '_about_content', 'field_611696a12d3bc'),
(571, 94, 'trends_0_image', '89'),
(572, 94, '_trends_0_image', 'field_611695c977633'),
(573, 94, 'trends_0_title', 'Discover our new summer collection'),
(574, 94, '_trends_0_title', 'field_611695d577634'),
(575, 94, 'trends_0_link', 'a:3:{s:5:\"title\";s:6:\"New In\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(576, 94, '_trends_0_link', 'field_611695de77635'),
(577, 94, 'trends_1_image', '86'),
(578, 94, '_trends_1_image', 'field_611695c977633'),
(579, 94, 'trends_1_title', 'Discover now'),
(580, 94, '_trends_1_title', 'field_611695d577634'),
(581, 94, 'trends_1_link', 'a:3:{s:5:\"title\";s:16:\"Preview November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(582, 94, '_trends_1_link', 'field_611695de77635'),
(583, 94, 'trends_2_image', '87'),
(584, 94, '_trends_2_image', 'field_611695c977633'),
(585, 94, 'trends_2_title', 'Discover now'),
(586, 94, '_trends_2_title', 'field_611695d577634'),
(587, 94, 'trends_2_link', 'a:3:{s:5:\"title\";s:5:\"Socks\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(588, 94, '_trends_2_link', 'field_611695de77635'),
(589, 94, 'trends_3_image', '88'),
(590, 94, '_trends_3_image', 'field_611695c977633'),
(591, 94, 'trends_3_title', 'Looks to be happy'),
(592, 94, '_trends_3_title', 'field_611695d577634'),
(593, 94, 'trends_3_link', 'a:3:{s:5:\"title\";s:13:\"Bohemian Flow\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(594, 94, '_trends_3_link', 'field_611695de77635'),
(595, 94, 'trends_0_color', '#191c45'),
(596, 94, '_trends_0_color', 'field_6116a014d1ca5'),
(597, 94, 'trends_1_color', '#a4bcd7'),
(598, 94, '_trends_1_color', 'field_6116a014d1ca5'),
(599, 94, 'trends_2_color', '#c1815d'),
(600, 94, '_trends_2_color', 'field_6116a014d1ca5'),
(601, 94, 'trends_3_color', '#a4bcd7'),
(602, 94, '_trends_3_color', 'field_6116a014d1ca5'),
(603, 97, 'top_banner', '83'),
(604, 97, '_top_banner', 'field_611695387762b'),
(605, 97, 'top_banner_title', 'New In'),
(606, 97, '_top_banner_title', 'field_611695477762c'),
(607, 97, 'top_banner_content', 'Discover our new collecion'),
(608, 97, '_top_banner_content', 'field_6116956b7762d'),
(609, 97, 'top_banner_link', 'a:3:{s:5:\"title\";s:12:\"Discover now\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(610, 97, '_top_banner_link', 'field_611695767762e'),
(611, 97, 'banner', '84'),
(612, 97, '_banner', 'field_6116958f7762f'),
(613, 97, 'banner_link', 'a:3:{s:5:\"title\";s:0:\"\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(614, 97, '_banner_link', 'field_6116959777630'),
(615, 97, 'trends_title', 'Current topics and trends'),
(616, 97, '_trends_title', 'field_611695b277631'),
(617, 97, 'trends', '4'),
(618, 97, '_trends', 'field_611695bc77632'),
(619, 97, 'featured_banner', '91'),
(620, 97, '_featured_banner', 'field_61169603f4a63'),
(621, 97, 'featured_banner_link', 'a:3:{s:5:\"title\";s:14:\"Denim Accepted\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(622, 97, '_featured_banner_link', 'field_61169624f4a65'),
(623, 97, 'featured_banner_content', 'We say that denim is what you make of it.'),
(624, 97, '_featured_banner_content', 'field_61169632f4a66'),
(625, 97, 'subscribe_text', '<h3 style=\"text-align: center;\">10€ VOUCHER</h3>\r\n<p style=\"text-align: center;\">for subscribing!</p>'),
(626, 97, '_subscribe_text', 'field_611696792d3b9'),
(627, 97, 'subscribe_link', 'a:3:{s:5:\"title\";s:12:\"Register now\";s:3:\"url\";s:39:\"http://localhost/ullapopken/my-account/\";s:6:\"target\";s:0:\"\";}'),
(628, 97, '_subscribe_link', 'field_611696842d3ba'),
(629, 97, 'about_title', 'Individual and trendy fashion in big sizes'),
(630, 97, '_about_title', 'field_611696992d3bb'),
(631, 97, 'about_content', 'There were times when it was almost impossible for people of all ages to dress fashion-consciously and dress appropriately. The fashion for large sizes at that time consisted of inconspicuous, baggy garments, which often seemed more than unfavorable and in the worst case visually even applied a few kilos. But a lot has happened since then. Not least thanks to role models from film and television, curvy people have found new self-confidence and only want to let their taste and not the offer decide on their clothing style.\r\n\r\nThe industry has responded by producing trendy fashion and big sizes so that everyone can dress according to their preferences, regardless of their size and weight. At Ulla Popken you will find a wide selection of fashion items for tall people, with which you can create your very own style. Figurative cuts and flowing fabrics in high quality emphasize your preferences and conceal the problem areas.\r\n\r\nFresh colors and patterned fabrics follow the latest trends, turning classic, plain-colored basics into outfits that leave fashionable everyday life behind. Sometimes it can be difficult to find the right outfit of the right size for a formal or formal occasion. Especially in shops and non-specialized online shops, the selection is often limited. But here you will find fashion in oversize, which fits all occasions.\r\n\r\nOf course it can also be more courageous. Who puts his advantages such as a slender waist or long legs in scene - whether with a tailored skirt, a pair of pants or a belted trench coat - can hide the less loved places with appropriate materials, cuts and colors. With fashion from Ulla Popken in sizes 42 to 68 you are always on the right page.'),
(632, 97, '_about_content', 'field_611696a12d3bc'),
(633, 97, 'trends_0_image', '89'),
(634, 97, '_trends_0_image', 'field_611695c977633'),
(635, 97, 'trends_0_title', 'Discover our new summer collection'),
(636, 97, '_trends_0_title', 'field_611695d577634'),
(637, 97, 'trends_0_link', 'a:3:{s:5:\"title\";s:6:\"New In\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(638, 97, '_trends_0_link', 'field_611695de77635'),
(639, 97, 'trends_1_image', '86'),
(640, 97, '_trends_1_image', 'field_611695c977633'),
(641, 97, 'trends_1_title', 'Discover now'),
(642, 97, '_trends_1_title', 'field_611695d577634'),
(643, 97, 'trends_1_link', 'a:3:{s:5:\"title\";s:16:\"Preview November\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(644, 97, '_trends_1_link', 'field_611695de77635'),
(645, 97, 'trends_2_image', '87'),
(646, 97, '_trends_2_image', 'field_611695c977633'),
(647, 97, 'trends_2_title', 'Discover now'),
(648, 97, '_trends_2_title', 'field_611695d577634'),
(649, 97, 'trends_2_link', 'a:3:{s:5:\"title\";s:5:\"Socks\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(650, 97, '_trends_2_link', 'field_611695de77635'),
(651, 97, 'trends_3_image', '88'),
(652, 97, '_trends_3_image', 'field_611695c977633'),
(653, 97, 'trends_3_title', 'Looks to be happy'),
(654, 97, '_trends_3_title', 'field_611695d577634'),
(655, 97, 'trends_3_link', 'a:3:{s:5:\"title\";s:13:\"Bohemian Flow\";s:3:\"url\";s:1:\"#\";s:6:\"target\";s:0:\"\";}'),
(656, 97, '_trends_3_link', 'field_611695de77635'),
(657, 97, 'trends_0_color', '#191c45'),
(658, 97, '_trends_0_color', 'field_6116a014d1ca5'),
(659, 97, 'trends_1_color', '#a4bcd7'),
(660, 97, '_trends_1_color', 'field_6116a014d1ca5'),
(661, 97, 'trends_2_color', '#c1815d'),
(662, 97, '_trends_2_color', 'field_6116a014d1ca5'),
(663, 97, 'trends_3_color', '#a4bcd7'),
(664, 97, '_trends_3_color', 'field_6116a014d1ca5'),
(665, 98, 'inline_featured_image', '0'),
(666, 98, '_edit_last', '1'),
(667, 98, '_edit_lock', '1629083221:1'),
(668, 98, '_wp_page_template', 'page-home.php'),
(669, 98, 'top_banner', ''),
(670, 98, '_top_banner', 'field_611695387762b'),
(671, 98, 'top_banner_title', ''),
(672, 98, '_top_banner_title', 'field_611695477762c'),
(673, 98, 'top_banner_content', ''),
(674, 98, '_top_banner_content', 'field_6116956b7762d'),
(675, 98, 'top_banner_link', ''),
(676, 98, '_top_banner_link', 'field_611695767762e'),
(677, 98, 'banner', ''),
(678, 98, '_banner', 'field_6116958f7762f'),
(679, 98, 'banner_link', ''),
(680, 98, '_banner_link', 'field_6116959777630'),
(681, 98, 'trends_title', ''),
(682, 98, '_trends_title', 'field_611695b277631'),
(683, 98, 'trends', ''),
(684, 98, '_trends', 'field_611695bc77632'),
(685, 98, 'featured_banner', ''),
(686, 98, '_featured_banner', 'field_61169603f4a63'),
(687, 98, 'featured_banner_link', ''),
(688, 98, '_featured_banner_link', 'field_61169624f4a65'),
(689, 98, 'featured_banner_content', ''),
(690, 98, '_featured_banner_content', 'field_61169632f4a66'),
(691, 98, 'subscribe_text', ''),
(692, 98, '_subscribe_text', 'field_611696792d3b9'),
(693, 98, 'subscribe_link', ''),
(694, 98, '_subscribe_link', 'field_611696842d3ba'),
(695, 98, 'about_title', ''),
(696, 98, '_about_title', 'field_611696992d3bb'),
(697, 98, 'about_content', ''),
(698, 98, '_about_content', 'field_611696a12d3bc'),
(699, 99, 'top_banner', ''),
(700, 99, '_top_banner', 'field_611695387762b'),
(701, 99, 'top_banner_title', ''),
(702, 99, '_top_banner_title', 'field_611695477762c'),
(703, 99, 'top_banner_content', ''),
(704, 99, '_top_banner_content', 'field_6116956b7762d'),
(705, 99, 'top_banner_link', ''),
(706, 99, '_top_banner_link', 'field_611695767762e'),
(707, 99, 'banner', ''),
(708, 99, '_banner', 'field_6116958f7762f'),
(709, 99, 'banner_link', ''),
(710, 99, '_banner_link', 'field_6116959777630'),
(711, 99, 'trends_title', ''),
(712, 99, '_trends_title', 'field_611695b277631'),
(713, 99, 'trends', ''),
(714, 99, '_trends', 'field_611695bc77632'),
(715, 99, 'featured_banner', ''),
(716, 99, '_featured_banner', 'field_61169603f4a63'),
(717, 99, 'featured_banner_link', ''),
(718, 99, '_featured_banner_link', 'field_61169624f4a65'),
(719, 99, 'featured_banner_content', ''),
(720, 99, '_featured_banner_content', 'field_61169632f4a66'),
(721, 99, 'subscribe_text', ''),
(722, 99, '_subscribe_text', 'field_611696792d3b9'),
(723, 99, 'subscribe_link', ''),
(724, 99, '_subscribe_link', 'field_611696842d3ba'),
(725, 99, 'about_title', ''),
(726, 99, '_about_title', 'field_611696992d3bb'),
(727, 99, 'about_content', ''),
(728, 99, '_about_content', 'field_611696a12d3bc'),
(731, 101, '_edit_last', '1'),
(732, 101, '_edit_lock', '1629138380:1'),
(733, 105, 'inline_featured_image', '0'),
(734, 105, '_edit_last', '1'),
(735, 105, '_edit_lock', '1629128662:1'),
(736, 106, '_wp_attached_file', '2021/08/798552820_ecom_g_02.webp'),
(737, 106, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/798552820_ecom_g_02.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_02-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_02-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"798552820_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(738, 106, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(739, 107, '_wp_attached_file', '2021/08/798552820_ecom_g_01.jpg'),
(740, 107, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:31:\"2021/08/798552820_ecom_g_01.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"798552820_ecom_g_01-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"798552820_ecom_g_01-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"798552820_ecom_g_01-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"798552820_ecom_g_01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:31:\"798552820_ecom_g_01-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"798552820_ecom_g_01-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(741, 108, '_wp_attached_file', '2021/08/798552820_ecom_g_03.webp'),
(742, 108, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/798552820_ecom_g_03.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_03-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_03-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"798552820_ecom_g_03-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_03-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_03-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"798552820_ecom_g_03-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(743, 108, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(744, 107, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";d:2.4992919852732935;s:5:\"bytes\";i:1059;s:11:\"size_before\";i:42372;s:10:\"size_after\";i:41313;s:4:\"time\";d:0.10999999999999999;s:11:\"api_version\";s:3:\"1.0\";s:5:\"lossy\";b:0;s:9:\"keep_exif\";i:0;}s:5:\"sizes\";a:6:{s:6:\"medium\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.88;s:5:\"bytes\";i:298;s:11:\"size_before\";i:7683;s:10:\"size_after\";i:7385;s:4:\"time\";d:0.05;}s:9:\"thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:4.19;s:5:\"bytes\";i:208;s:11:\"size_before\";i:4966;s:10:\"size_after\";i:4758;s:4:\"time\";d:0.01;}s:21:\"woocommerce_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:3.29;s:5:\"bytes\";i:395;s:11:\"size_before\";i:11994;s:10:\"size_after\";i:11599;s:4:\"time\";d:0.02;}s:29:\"woocommerce_gallery_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";d:5.03;s:5:\"bytes\";i:158;s:11:\"size_before\";i:3144;s:10:\"size_after\";i:2986;s:4:\"time\";d:0.01;}s:12:\"shop_catalog\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:11599;s:10:\"size_after\";i:11599;s:4:\"time\";d:0.01;}s:14:\"shop_thumbnail\";O:8:\"stdClass\":5:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:2986;s:10:\"size_after\";i:2986;s:4:\"time\";d:0.01;}}}'),
(745, 105, '_thumbnail_id', '107'),
(747, 105, 'total_sales', '0'),
(748, 105, '_tax_status', 'taxable'),
(749, 105, '_tax_class', ''),
(750, 105, '_manage_stock', 'no'),
(751, 105, '_backorders', 'no'),
(752, 105, '_sold_individually', 'no'),
(753, 105, '_virtual', 'no'),
(754, 105, '_downloadable', 'no'),
(755, 105, '_download_limit', '-1'),
(756, 105, '_download_expiry', '-1'),
(757, 105, '_stock', NULL),
(758, 105, '_stock_status', 'instock'),
(759, 105, '_wc_average_rating', '0'),
(760, 105, '_wc_review_count', '0'),
(761, 105, '_product_version', '5.5.2'),
(763, 105, '_product_image_gallery', '108,106'),
(764, 105, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}'),
(765, 109, '_variation_description', ''),
(766, 109, 'total_sales', '0'),
(767, 109, '_tax_status', 'taxable'),
(768, 109, '_tax_class', 'parent'),
(769, 109, '_manage_stock', 'no'),
(770, 109, '_backorders', 'no'),
(771, 109, '_sold_individually', 'no'),
(772, 109, '_virtual', 'no'),
(773, 109, '_downloadable', 'no'),
(774, 109, '_download_limit', '-1'),
(775, 109, '_download_expiry', '-1'),
(776, 109, '_stock', NULL),
(777, 109, '_stock_status', 'instock'),
(778, 109, '_wc_average_rating', '0'),
(779, 109, '_wc_review_count', '0'),
(780, 109, 'attribute_pa_color', 'red'),
(781, 109, '_product_version', '5.5.2'),
(782, 105, '_default_attributes', 'a:1:{s:8:\"pa_color\";s:3:\"red\";}'),
(783, 109, '_regular_price', '69.99'),
(784, 109, '_price', '69.99'),
(786, 105, '_price', '69.99'),
(787, 105, '_regular_price', '49.99'),
(788, 110, 'inline_featured_image', '0'),
(789, 110, 'total_sales', '0'),
(790, 110, '_tax_status', 'taxable'),
(791, 110, '_tax_class', ''),
(792, 110, '_manage_stock', 'no'),
(793, 110, '_backorders', 'no'),
(794, 110, '_sold_individually', 'no'),
(795, 110, '_virtual', 'no'),
(796, 110, '_downloadable', 'no'),
(797, 110, '_download_limit', '-1'),
(798, 110, '_download_expiry', '-1'),
(799, 110, '_stock', NULL),
(800, 110, '_stock_status', 'instock'),
(801, 110, '_wc_average_rating', '0'),
(802, 110, '_wc_review_count', '0'),
(803, 110, '_product_attributes', 'a:1:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}'),
(804, 110, '_product_version', '5.5.2'),
(805, 110, '_edit_lock', '1629128927:1'),
(806, 111, '_variation_description', ''),
(807, 111, 'total_sales', '0'),
(808, 111, '_tax_status', 'taxable'),
(809, 111, '_tax_class', 'parent'),
(810, 111, '_manage_stock', 'no'),
(811, 111, '_backorders', 'no'),
(812, 111, '_sold_individually', 'no'),
(813, 111, '_virtual', 'no'),
(814, 111, '_downloadable', 'no'),
(815, 111, '_download_limit', '-1'),
(816, 111, '_download_expiry', '-1'),
(817, 111, '_stock', NULL),
(818, 111, '_stock_status', 'instock'),
(819, 111, '_wc_average_rating', '0'),
(820, 111, '_wc_review_count', '0'),
(821, 111, 'attribute_pa_color', 'black'),
(822, 111, '_product_version', '5.5.2'),
(823, 112, '_variation_description', ''),
(824, 112, 'total_sales', '0'),
(825, 112, '_tax_status', 'taxable'),
(826, 112, '_tax_class', 'parent'),
(827, 112, '_manage_stock', 'no'),
(828, 112, '_backorders', 'no'),
(829, 112, '_sold_individually', 'no'),
(830, 112, '_virtual', 'no'),
(831, 112, '_downloadable', 'no'),
(832, 112, '_download_limit', '-1'),
(833, 112, '_download_expiry', '-1'),
(834, 112, '_stock', NULL),
(835, 112, '_stock_status', 'instock'),
(836, 112, '_wc_average_rating', '0'),
(837, 112, '_wc_review_count', '0'),
(838, 112, 'attribute_pa_color', 'yellow'),
(839, 112, '_product_version', '5.5.2'),
(840, 113, '_wp_attached_file', '2021/08/797353100_ecom_g_02.webp'),
(841, 113, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/797353100_ecom_g_02.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_02-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_02-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"797353100_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(842, 113, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(843, 114, '_wp_attached_file', '2021/08/797353100_ecom_g_01.webp'),
(844, 114, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/797353100_ecom_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"797353100_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353100_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(845, 114, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(846, 115, '_wp_attached_file', '2021/08/797353402_ecom_g_01.webp'),
(847, 115, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/797353402_ecom_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"797353402_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(848, 115, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(849, 116, '_wp_attached_file', '2021/08/797353402_ecom_g_02.webp'),
(850, 116, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/797353402_ecom_g_02.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_02-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_02-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"797353402_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"797353402_ecom_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(851, 116, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(852, 110, '_default_attributes', 'a:1:{s:8:\"pa_color\";s:5:\"black\";}'),
(853, 111, '_regular_price', '29.99'),
(854, 111, '_thumbnail_id', '114'),
(855, 111, '_price', '29.99'),
(856, 112, '_thumbnail_id', '115'),
(857, 110, '_price', '29.99'),
(858, 110, '_edit_last', '1'),
(859, 110, '_product_image_gallery', '116,113'),
(860, 117, 'inline_featured_image', '0'),
(861, 117, '_edit_last', '1'),
(862, 117, '_edit_lock', '1629129513:1'),
(863, 117, 'total_sales', '0'),
(864, 117, '_tax_status', 'taxable'),
(865, 117, '_tax_class', ''),
(866, 117, '_manage_stock', 'no'),
(867, 117, '_backorders', 'no'),
(868, 117, '_sold_individually', 'no'),
(869, 117, '_virtual', 'no'),
(870, 117, '_downloadable', 'no'),
(871, 117, '_download_limit', '-1'),
(872, 117, '_download_expiry', '-1'),
(873, 117, '_stock', NULL),
(874, 117, '_stock_status', 'instock'),
(875, 117, '_wc_average_rating', '0'),
(876, 117, '_wc_review_count', '0'),
(877, 117, '_product_attributes', 'a:2:{s:8:\"pa_color\";a:6:{s:4:\"name\";s:8:\"pa_color\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:0;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}s:7:\"pa_size\";a:6:{s:4:\"name\";s:7:\"pa_size\";s:5:\"value\";s:0:\"\";s:8:\"position\";i:1;s:10:\"is_visible\";i:1;s:12:\"is_variation\";i:1;s:11:\"is_taxonomy\";i:1;}}'),
(878, 117, '_product_version', '5.5.2'),
(879, 118, '_variation_description', ''),
(880, 118, 'total_sales', '0'),
(881, 118, '_tax_status', 'taxable'),
(882, 118, '_tax_class', 'parent'),
(883, 118, '_manage_stock', 'no'),
(884, 118, '_backorders', 'no'),
(885, 118, '_sold_individually', 'no'),
(886, 118, '_virtual', 'no'),
(887, 118, '_downloadable', 'no'),
(888, 118, '_download_limit', '-1'),
(889, 118, '_download_expiry', '-1'),
(890, 118, '_stock', NULL),
(891, 118, '_stock_status', 'instock'),
(892, 118, '_wc_average_rating', '0'),
(893, 118, '_wc_review_count', '0'),
(894, 118, 'attribute_pa_size', '38-40'),
(895, 118, 'attribute_pa_color', 'blue'),
(896, 118, '_product_version', '5.5.2'),
(969, 123, '_variation_description', ''),
(970, 123, 'total_sales', '0'),
(971, 123, '_tax_status', 'taxable'),
(972, 123, '_tax_class', 'parent'),
(973, 123, '_manage_stock', 'no'),
(974, 123, '_backorders', 'no'),
(975, 123, '_sold_individually', 'no'),
(976, 123, '_virtual', 'no'),
(977, 123, '_downloadable', 'no'),
(978, 123, '_download_limit', '-1'),
(979, 123, '_download_expiry', '-1'),
(980, 123, '_stock', NULL),
(981, 123, '_stock_status', 'instock'),
(982, 123, '_wc_average_rating', '0'),
(983, 123, '_wc_review_count', '0'),
(984, 123, 'attribute_pa_size', '38-40'),
(985, 123, 'attribute_pa_color', 'grey'),
(986, 123, '_product_version', '5.5.2'),
(987, 124, '_variation_description', ''),
(988, 124, 'total_sales', '0'),
(989, 124, '_tax_status', 'taxable'),
(990, 124, '_tax_class', 'parent'),
(991, 124, '_manage_stock', 'no'),
(992, 124, '_backorders', 'no'),
(993, 124, '_sold_individually', 'no'),
(994, 124, '_virtual', 'no'),
(995, 124, '_downloadable', 'no'),
(996, 124, '_download_limit', '-1'),
(997, 124, '_download_expiry', '-1'),
(998, 124, '_stock', NULL),
(999, 124, '_stock_status', 'instock'),
(1000, 124, '_wc_average_rating', '0'),
(1001, 124, '_wc_review_count', '0'),
(1002, 124, 'attribute_pa_size', '42-44'),
(1003, 124, 'attribute_pa_color', 'grey'),
(1004, 124, '_product_version', '5.5.2'),
(1005, 125, '_variation_description', ''),
(1006, 125, 'total_sales', '0'),
(1007, 125, '_tax_status', 'taxable'),
(1008, 125, '_tax_class', 'parent'),
(1009, 125, '_manage_stock', 'no'),
(1010, 125, '_backorders', 'no'),
(1011, 125, '_sold_individually', 'no'),
(1012, 125, '_virtual', 'no'),
(1013, 125, '_downloadable', 'no'),
(1014, 125, '_download_limit', '-1'),
(1015, 125, '_download_expiry', '-1'),
(1016, 125, '_stock', NULL),
(1017, 125, '_stock_status', 'instock'),
(1018, 125, '_wc_average_rating', '0'),
(1019, 125, '_wc_review_count', '0'),
(1020, 125, 'attribute_pa_size', '46-48'),
(1021, 125, 'attribute_pa_color', 'grey'),
(1022, 125, '_product_version', '5.5.2'),
(1023, 126, '_variation_description', ''),
(1024, 126, 'total_sales', '0'),
(1025, 126, '_tax_status', 'taxable'),
(1026, 126, '_tax_class', 'parent'),
(1027, 126, '_manage_stock', 'no'),
(1028, 126, '_backorders', 'no'),
(1029, 126, '_sold_individually', 'no'),
(1030, 126, '_virtual', 'no'),
(1031, 126, '_downloadable', 'no'),
(1032, 126, '_download_limit', '-1'),
(1033, 126, '_download_expiry', '-1'),
(1034, 126, '_stock', NULL),
(1035, 126, '_stock_status', 'instock'),
(1036, 126, '_wc_average_rating', '0'),
(1037, 126, '_wc_review_count', '0'),
(1038, 126, 'attribute_pa_size', '50-52'),
(1039, 126, 'attribute_pa_color', 'grey'),
(1040, 126, '_product_version', '5.5.2'),
(1041, 127, '_variation_description', ''),
(1042, 127, 'total_sales', '0'),
(1043, 127, '_tax_status', 'taxable'),
(1044, 127, '_tax_class', 'parent'),
(1045, 127, '_manage_stock', 'no'),
(1046, 127, '_backorders', 'no'),
(1047, 127, '_sold_individually', 'no'),
(1048, 127, '_virtual', 'no'),
(1049, 127, '_downloadable', 'no'),
(1050, 127, '_download_limit', '-1'),
(1051, 127, '_download_expiry', '-1'),
(1052, 127, '_stock', NULL),
(1053, 127, '_stock_status', 'instock'),
(1054, 127, '_wc_average_rating', '0'),
(1055, 127, '_wc_review_count', '0'),
(1056, 127, 'attribute_pa_size', '54-56');
INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1057, 127, 'attribute_pa_color', 'grey'),
(1058, 127, '_product_version', '5.5.2'),
(1059, 118, '_regular_price', '49.99'),
(1060, 118, '_thumbnail_id', '131'),
(1061, 118, '_price', '49.99'),
(1062, 123, '_regular_price', '49.99'),
(1063, 123, '_thumbnail_id', '132'),
(1064, 123, '_price', '49.99'),
(1065, 124, '_regular_price', '49.99'),
(1066, 124, '_thumbnail_id', '132'),
(1067, 124, '_price', '49.99'),
(1068, 125, '_regular_price', '49.99'),
(1069, 125, '_thumbnail_id', '132'),
(1070, 125, '_price', '49.99'),
(1071, 126, '_regular_price', '49.99'),
(1072, 126, '_thumbnail_id', '132'),
(1073, 126, '_price', '49.99'),
(1074, 127, '_regular_price', '49.99'),
(1075, 127, '_thumbnail_id', '132'),
(1076, 127, '_price', '49.99'),
(1078, 117, '_default_attributes', 'a:1:{s:8:\"pa_color\";s:4:\"grey\";}'),
(1080, 128, '_wp_attached_file', '2021/08/748007904_ecom_g_01.webp'),
(1081, 128, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/748007904_ecom_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"748007904_ecom_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"748007904_ecom_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"748007904_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"748007904_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"748007904_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"748007904_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1082, 128, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1083, 129, '_wp_attached_file', '2021/08/748007904_model_g_02.webp'),
(1084, 129, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007904_model_g_02.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_02-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_02-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007904_model_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1085, 129, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1086, 130, '_wp_attached_file', '2021/08/748007904_model_g_21.webp'),
(1087, 130, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007904_model_g_21.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_21-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_21-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007904_model_g_21-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_21-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_21-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_21-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1088, 130, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1089, 131, '_wp_attached_file', '2021/08/748007904_model_g_01.webp'),
(1090, 131, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007904_model_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007904_model_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007904_model_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1091, 131, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1092, 132, '_wp_attached_file', '2021/08/748007903_model_g_21.webp'),
(1093, 132, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007903_model_g_21.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_21-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_21-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007903_model_g_21-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_21-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_21-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_21-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1094, 132, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1095, 133, '_wp_attached_file', '2021/08/748007903_model_g_01.webp'),
(1096, 133, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007903_model_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007903_model_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1097, 133, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1098, 134, '_wp_attached_file', '2021/08/748007903_ecom_g_01.webp'),
(1099, 134, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:32:\"2021/08/748007903_ecom_g_01.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"748007903_ecom_g_01-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"748007903_ecom_g_01-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"748007903_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"748007903_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"748007903_ecom_g_01-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"748007903_ecom_g_01-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1100, 134, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1101, 135, '_wp_attached_file', '2021/08/748007903_model_g_02.webp'),
(1102, 135, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:468;s:6:\"height\";i:702;s:4:\"file\";s:33:\"2021/08/748007903_model_g_02.webp\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_02-200x300.webp\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_02-150x150.webp\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/webp\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:33:\"748007903_model_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";s:9:\"uncropped\";s:1:\"0\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_02-300x300.webp\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/webp\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:33:\"748007903_model_g_02-100x100.webp\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/webp\";}}s:10:\"image_meta\";a:11:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";}}'),
(1103, 135, 'wp-smpro-smush-data', 'a:2:{s:5:\"stats\";a:8:{s:7:\"percent\";i:0;s:5:\"bytes\";i:0;s:11:\"size_before\";i:0;s:10:\"size_after\";i:0;s:4:\"time\";i:0;s:11:\"api_version\";i:-1;s:5:\"lossy\";i:-1;s:9:\"keep_exif\";b:0;}s:5:\"sizes\";a:0:{}}'),
(1105, 117, '_thumbnail_id', '131'),
(1106, 117, '_product_image_gallery', '130,129,128,132,133,134,135'),
(1107, 117, '_price', '49.99'),
(1108, 137, '_pwf_woo_post_filter', 'a:2:{s:7:\"setting\";a:24:{s:10:\"post_title\";s:11:\"Shop Filter\";s:16:\"filtering_starts\";s:4:\"auto\";s:8:\"cssclass\";s:0:\"\";s:13:\"usecomponents\";a:3:{i:0;s:10:\"pagination\";i:1;s:7:\"sorting\";i:2;s:13:\"results_count\";}s:15:\"pagination_type\";s:7:\"numbers\";s:15:\"pagination_ajax\";s:2:\"on\";s:12:\"sorting_ajax\";s:2:\"on\";s:27:\"products_container_selector\";s:9:\".products\";s:19:\"pagination_selector\";s:23:\".woocommerce-pagination\";s:21:\"result_count_selector\";s:25:\".woocommerce-result-count\";s:16:\"sorting_selector\";s:21:\".woocommerce-ordering\";s:23:\"active_filters_selector\";s:15:\".active-filters\";s:9:\"scroll_to\";s:0:\"\";s:17:\"display_filter_as\";s:0:\"\";s:19:\"filter_button_state\";s:4:\"show\";s:14:\"posts_per_page\";s:0:\"\";s:12:\"browser_hash\";s:2:\"on\";s:25:\"api_remove_columns_layout\";s:2:\"on\";s:12:\"is_shortcode\";s:0:\"\";s:16:\"shortcode_string\";s:0:\"\";s:10:\"responsive\";s:2:\"on\";s:27:\"responsive_filtering_starts\";s:11:\"send_button\";s:24:\"responsive_append_sticky\";s:4:\"body\";s:16:\"responsive_width\";s:3:\"768\";}s:5:\"items\";a:5:{s:4:\"id-0\";a:34:{s:5:\"title\";s:4:\"Sort\";s:7:\"url_key\";s:7:\"orderby\";s:17:\"source_of_options\";s:7:\"orderby\";s:20:\"item_source_category\";s:0:\"\";s:21:\"item_source_attribute\";s:0:\"\";s:20:\"item_source_taxonomy\";s:0:\"\";s:24:\"item_source_taxonomy_sub\";s:0:\"\";s:10:\"user_roles\";s:0:\"\";s:12:\"item_display\";s:3:\"all\";s:7:\"include\";s:0:\"\";s:7:\"exclude\";s:0:\"\";s:24:\"item_source_stock_status\";s:0:\"\";s:19:\"item_source_orderby\";a:6:{i:0;s:10:\"menu_order\";i:1;s:10:\"popularity\";i:2;s:6:\"rating\";i:3;s:4:\"date\";i:4;s:5:\"price\";i:5;s:10:\"price-desc\";}s:13:\"in_stock_text\";s:8:\"In stock\";s:17:\"out_of_stock_text\";s:12:\"Out of stock\";s:17:\"on_backorder_text\";s:12:\"On backorder\";s:13:\"show_all_text\";s:8:\"Show all\";s:8:\"meta_key\";s:0:\"\";s:12:\"meta_compare\";s:0:\"\";s:9:\"meta_type\";s:0:\"\";s:9:\"metafield\";s:0:\"\";s:8:\"order_by\";s:4:\"name\";s:12:\"hidden_rules\";s:0:\"\";s:13:\"display_title\";s:2:\"on\";s:22:\"display_toggle_content\";s:2:\"on\";s:20:\"default_toggle_state\";s:4:\"hide\";s:9:\"css_class\";s:0:\"\";s:20:\"display_hierarchical\";s:2:\"on\";s:30:\"display_hierarchical_collapsed\";s:0:\"\";s:24:\"action_for_empty_options\";s:4:\"hide\";s:22:\"display_product_counts\";s:2:\"on\";s:15:\"more_options_by\";s:8:\"disabled\";s:25:\"height_of_visible_content\";s:0:\"\";s:9:\"item_type\";s:9:\"radiolist\";}s:4:\"id-1\";a:34:{s:5:\"title\";s:4:\"Size\";s:7:\"url_key\";s:4:\"size\";s:10:\"query_type\";s:2:\"or\";s:17:\"source_of_options\";s:9:\"attribute\";s:20:\"item_source_category\";s:0:\"\";s:21:\"item_source_attribute\";s:7:\"pa_size\";s:20:\"item_source_taxonomy\";s:0:\"\";s:24:\"item_source_taxonomy_sub\";s:0:\"\";s:10:\"user_roles\";s:0:\"\";s:12:\"item_display\";s:8:\"selected\";s:7:\"include\";a:22:{i:0;s:2:\"22\";i:1;s:2:\"33\";i:2;s:2:\"34\";i:3;s:2:\"23\";i:4;s:2:\"24\";i:5;s:2:\"35\";i:6;s:2:\"25\";i:7;s:2:\"36\";i:8;s:2:\"26\";i:9;s:2:\"27\";i:10;s:2:\"37\";i:11;s:2:\"38\";i:12;s:2:\"28\";i:13;s:2:\"39\";i:14;s:2:\"29\";i:15;s:2:\"40\";i:16;s:2:\"41\";i:17;s:2:\"30\";i:18;s:2:\"31\";i:19;s:2:\"42\";i:20;s:2:\"32\";i:21;s:2:\"43\";}s:7:\"exclude\";s:0:\"\";s:24:\"item_source_stock_status\";s:0:\"\";s:19:\"item_source_orderby\";s:0:\"\";s:13:\"in_stock_text\";s:8:\"In stock\";s:17:\"out_of_stock_text\";s:12:\"Out of stock\";s:17:\"on_backorder_text\";s:12:\"On backorder\";s:8:\"meta_key\";s:0:\"\";s:12:\"meta_compare\";s:0:\"\";s:9:\"meta_type\";s:0:\"\";s:9:\"metafield\";s:0:\"\";s:8:\"order_by\";s:4:\"name\";s:12:\"hidden_rules\";s:0:\"\";s:13:\"display_title\";s:2:\"on\";s:22:\"display_toggle_content\";s:2:\"on\";s:20:\"default_toggle_state\";s:4:\"hide\";s:9:\"css_class\";s:0:\"\";s:20:\"display_hierarchical\";s:2:\"on\";s:30:\"display_hierarchical_collapsed\";s:0:\"\";s:24:\"action_for_empty_options\";s:4:\"hide\";s:22:\"display_product_counts\";s:2:\"on\";s:15:\"more_options_by\";s:8:\"disabled\";s:25:\"height_of_visible_content\";s:0:\"\";s:9:\"item_type\";s:12:\"checkboxlist\";}s:4:\"id-2\";a:28:{s:5:\"title\";s:5:\"Color\";s:7:\"url_key\";s:5:\"color\";s:12:\"multi_select\";s:2:\"on\";s:10:\"query_type\";s:2:\"or\";s:17:\"source_of_options\";s:9:\"attribute\";s:20:\"item_source_category\";s:0:\"\";s:21:\"item_source_attribute\";s:8:\"pa_color\";s:20:\"item_source_taxonomy\";s:0:\"\";s:24:\"item_source_taxonomy_sub\";s:0:\"\";s:10:\"user_roles\";s:0:\"\";s:6:\"colors\";a:13:{i:0;a:6:{s:7:\"term_id\";i:46;s:5:\"color\";s:7:\"#f1d3b1\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:7:\"#f1d3b1\";s:6:\"marker\";s:5:\"light\";}i:1;a:6:{s:7:\"term_id\";i:47;s:5:\"color\";s:7:\"#000000\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:7:\"#000000\";s:6:\"marker\";s:5:\"light\";}i:2;a:6:{s:7:\"term_id\";i:44;s:5:\"color\";s:7:\"#003399\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:3;a:6:{s:7:\"term_id\";i:55;s:5:\"color\";s:7:\"#663300\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:4;a:6:{s:7:\"term_id\";i:52;s:5:\"color\";s:7:\"#008733\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:5;a:6:{s:7:\"term_id\";i:45;s:5:\"color\";s:7:\"#a0a0a0\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:6;a:6:{s:7:\"term_id\";i:54;s:5:\"color\";s:7:\"#dd9933\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:7;a:6:{s:7:\"term_id\";i:50;s:5:\"color\";s:7:\"#f29999\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:8;a:6:{s:7:\"term_id\";i:51;s:5:\"color\";s:7:\"#663399\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:9;a:6:{s:7:\"term_id\";i:49;s:5:\"color\";s:7:\"#ff0101\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:10;a:6:{s:7:\"term_id\";i:53;s:5:\"color\";s:7:\"#00ffff\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:11;a:6:{s:7:\"term_id\";i:48;s:5:\"color\";s:7:\"#ffffff\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}i:12;a:6:{s:7:\"term_id\";i:56;s:5:\"color\";s:7:\"#eeee22\";s:5:\"image\";s:0:\"\";s:4:\"type\";s:5:\"color\";s:11:\"bordercolor\";s:0:\"\";s:6:\"marker\";s:5:\"light\";}}s:8:\"meta_key\";s:0:\"\";s:12:\"meta_compare\";s:0:\"\";s:9:\"meta_type\";s:0:\"\";s:9:\"metafield\";s:0:\"\";s:8:\"order_by\";s:4:\"name\";s:12:\"hidden_rules\";s:0:\"\";s:13:\"display_title\";s:2:\"on\";s:22:\"display_toggle_content\";s:2:\"on\";s:20:\"default_toggle_state\";s:4:\"hide\";s:9:\"css_class\";s:0:\"\";s:9:\"box_style\";s:7:\"rounded\";s:24:\"action_for_empty_options\";s:4:\"hide\";s:22:\"display_product_counts\";s:2:\"on\";s:4:\"size\";s:2:\"45\";s:9:\"item_type\";s:9:\"colorlist\";s:24:\"item_source_stock_status\";s:0:\"\";s:19:\"item_source_orderby\";s:0:\"\";}s:4:\"id-3\";a:17:{s:5:\"title\";s:5:\"Price\";s:16:\"price_url_format\";s:3:\"two\";s:7:\"url_key\";s:5:\"price\";s:17:\"url_key_min_price\";s:9:\"min-price\";s:17:\"url_key_max_price\";s:9:\"max-price\";s:11:\"interaction\";s:2:\"on\";s:13:\"display_title\";s:2:\"on\";s:22:\"display_toggle_content\";s:2:\"on\";s:20:\"default_toggle_state\";s:4:\"hide\";s:9:\"css_class\";s:0:\"\";s:10:\"price_step\";s:1:\"1\";s:11:\"price_start\";s:0:\"\";s:9:\"price_end\";s:0:\"\";s:22:\"display_max_min_inputs\";s:2:\"on\";s:19:\"display_price_label\";s:2:\"on\";s:15:\"display_tooltip\";s:0:\"\";s:9:\"item_type\";s:11:\"priceslider\";}s:4:\"id-4\";a:34:{s:5:\"title\";s:8:\"Material\";s:7:\"url_key\";s:8:\"material\";s:10:\"query_type\";s:2:\"or\";s:17:\"source_of_options\";s:9:\"attribute\";s:20:\"item_source_category\";s:0:\"\";s:21:\"item_source_attribute\";s:11:\"pa_material\";s:20:\"item_source_taxonomy\";s:0:\"\";s:24:\"item_source_taxonomy_sub\";s:0:\"\";s:10:\"user_roles\";s:0:\"\";s:12:\"item_display\";s:3:\"all\";s:7:\"include\";s:0:\"\";s:7:\"exclude\";s:0:\"\";s:24:\"item_source_stock_status\";s:0:\"\";s:19:\"item_source_orderby\";s:0:\"\";s:13:\"in_stock_text\";s:8:\"In stock\";s:17:\"out_of_stock_text\";s:12:\"Out of stock\";s:17:\"on_backorder_text\";s:12:\"On backorder\";s:8:\"meta_key\";s:0:\"\";s:12:\"meta_compare\";s:0:\"\";s:9:\"meta_type\";s:0:\"\";s:9:\"metafield\";s:0:\"\";s:8:\"order_by\";s:4:\"name\";s:12:\"hidden_rules\";s:0:\"\";s:13:\"display_title\";s:2:\"on\";s:22:\"display_toggle_content\";s:2:\"on\";s:20:\"default_toggle_state\";s:4:\"show\";s:9:\"css_class\";s:0:\"\";s:20:\"display_hierarchical\";s:2:\"on\";s:30:\"display_hierarchical_collapsed\";s:0:\"\";s:24:\"action_for_empty_options\";s:4:\"hide\";s:22:\"display_product_counts\";s:2:\"on\";s:15:\"more_options_by\";s:8:\"disabled\";s:25:\"height_of_visible_content\";s:0:\"\";s:9:\"item_type\";s:12:\"checkboxlist\";}}}'),
(1109, 137, '_edit_lock', '1629212600:1'),
(1110, 138, '_edit_last', '1'),
(1111, 138, '_edit_lock', '1629212453:1');

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-08-11 14:21:40', '2021-08-11 14:21:40', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2021-08-11 14:21:40', '2021-08-11 14:21:40', '', 0, 'http://localhost/ullapopken/?p=1', 0, 'post', '', 1),
(2, 1, '2021-08-11 14:21:40', '2021-08-11 14:21:40', '', 'Women Home', '', 'publish', 'closed', 'open', '', 'home', '', '', '2021-08-16 02:47:37', '2021-08-16 02:47:37', '', 0, 'http://localhost/ullapopken/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-08-11 14:21:40', '2021-08-11 14:21:40', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/ullapopken.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-08-11 14:21:40', '2021-08-11 14:21:40', '', 0, 'http://localhost/ullapopken/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-08-11 14:21:49', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-08-11 14:21:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/ullapopken/?p=4', 0, 'post', '', 0),
(5, 1, '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 0, 'http://localhost/ullapopken/wp-content/uploads/2021/08/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 0, 'http://localhost/ullapopken/shop/', 0, 'page', '', 0),
(7, 1, '2021-08-11 14:22:53', '2021-08-11 14:22:53', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 0, 'http://localhost/ullapopken/cart/', 0, 'page', '', 0),
(8, 1, '2021-08-11 14:22:53', '2021-08-11 14:22:53', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 0, 'http://localhost/ullapopken/checkout/', 0, 'page', '', 0),
(9, 1, '2021-08-11 14:22:53', '2021-08-11 14:22:53', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2021-08-11 14:22:53', '2021-08-11 14:22:53', '', 0, 'http://localhost/ullapopken/my-account/', 0, 'page', '', 0),
(10, 1, '2021-08-12 15:54:00', '2021-08-12 15:54:00', '', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-12 15:54:00', '2021-08-12 15:54:00', '', 2, 'http://localhost/ullapopken/?p=10', 0, 'revision', '', 0),
(11, 1, '2021-08-12 15:57:00', '2021-08-12 15:57:00', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:22:\"theme-general-settings\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Theme Settings', 'theme-settings', 'publish', 'closed', 'closed', '', 'group_611544b44c0bf', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 0, 'http://localhost/ullapopken/?post_type=acf-field-group&#038;p=11', 0, 'acf-field-group', '', 0),
(12, 1, '2021-08-12 15:57:00', '2021-08-12 15:57:00', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Site Logo', 'site_logo', 'publish', 'closed', 'closed', '', 'field_611544c1cae30', '', '', '2021-08-13 16:02:01', '2021-08-13 16:02:01', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=12', 1, 'acf-field', '', 0),
(13, 1, '2021-08-12 15:57:12', '2021-08-12 15:57:12', '', 'logo-ullapopken', '', 'inherit', 'open', 'closed', '', 'logo-ullapopken', '', '', '2021-08-12 15:57:12', '2021-08-12 15:57:12', '', 0, 'http://localhost/ullapopken/wp-content/uploads/2021/08/logo-ullapopken.svg', 0, 'attachment', 'image/svg+xml', 0),
(14, 1, '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 'Customer Service', '', 'publish', 'closed', 'closed', '', 'customer-service', '', '', '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 0, 'http://localhost/ullapopken/?p=14', 1, 'nav_menu_item', '', 0),
(15, 1, '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 'Store Finder', '', 'publish', 'closed', 'closed', '', 'store-finder', '', '', '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 0, 'http://localhost/ullapopken/?p=15', 2, 'nav_menu_item', '', 0),
(16, 1, '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 'Quick Order', '', 'publish', 'closed', 'closed', '', 'quick-order', '', '', '2021-08-12 15:58:18', '2021-08-12 15:58:18', '', 0, 'http://localhost/ullapopken/?p=16', 3, 'nav_menu_item', '', 0),
(17, 1, '2021-08-12 15:59:23', '2021-08-12 15:59:23', '<!-- wp:shortcode -->[yith_wcwl_wishlist]<!-- /wp:shortcode -->', 'Wishlist', '', 'publish', 'closed', 'closed', '', 'wishlist', '', '', '2021-08-12 15:59:23', '2021-08-12 15:59:23', '', 0, 'http://localhost/ullapopken/wishlist/', 0, 'page', '', 0),
(19, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:4:\"menu\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Menu Settings', 'menu-settings', 'publish', 'closed', 'closed', '', 'group_6116848926877', '', '', '2021-08-13 17:35:42', '2021-08-13 17:35:42', '', 0, 'http://localhost/ullapopken/?post_type=acf-field-group&#038;p=19', 0, 'acf-field-group', '', 0),
(20, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:19:\"field_611684eff4515\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:0:\"\";}', 'Menu Layout', 'menu_layout', 'publish', 'closed', 'closed', '', 'field_6116849bf4514', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 19, 'http://localhost/ullapopken/?post_type=acf-field&p=20', 0, 'acf-field', '', 0),
(21, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Parent Menu Item', 'parent_menu_item', 'publish', 'closed', 'closed', '', 'field_611684eff4515', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 20, 'http://localhost/ullapopken/?post_type=acf-field&p=21', 0, 'acf-field', '', 0),
(22, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:13:{s:4:\"type\";s:6:\"select\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:2:{s:8:\"column-2\";s:8:\"2 Column\";s:8:\"column-3\";s:8:\"3 Column\";}s:13:\"default_value\";s:8:\"2-column\";s:10:\"allow_null\";i:0;s:8:\"multiple\";i:0;s:2:\"ui\";i:0;s:13:\"return_format\";s:5:\"value\";s:4:\"ajax\";i:0;s:11:\"placeholder\";s:0:\"\";}', 'Submenu Column', 'submenu_column', 'publish', 'closed', 'closed', '', 'field_6116858df4517', '', '', '2021-08-13 17:35:42', '2021-08-13 17:35:42', '', 20, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=22', 1, 'acf-field', '', 0),
(23, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:9:{s:4:\"type\";s:16:\"flexible_content\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"layouts\";a:2:{s:20:\"layout_611685205172c\";a:6:{s:3:\"key\";s:20:\"layout_611685205172c\";s:5:\"label\";s:10:\"Link Menus\";s:4:\"name\";s:10:\"link_menus\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}s:20:\"layout_61168617f451b\";a:6:{s:3:\"key\";s:20:\"layout_61168617f451b\";s:5:\"label\";s:15:\"Image Menu Item\";s:4:\"name\";s:15:\"image_menu_item\";s:7:\"display\";s:5:\"block\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}}s:12:\"button_label\";s:7:\"Add Row\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";}', 'Sub Menu Layout', 'sub_menu_layout', 'publish', 'closed', 'closed', '', 'field_61168510f4516', '', '', '2021-08-13 15:24:45', '2021-08-13 15:24:45', '', 20, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=23', 4, 'acf-field', '', 0),
(24, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_611685205172c\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_611685e3f4518', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 23, 'http://localhost/ullapopken/?post_type=acf-field&p=24', 0, 'acf-field', '', 0),
(25, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_611685205172c\";s:9:\"collapsed\";s:19:\"field_611685fcf451a\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:0:\"\";}', 'Menu Items', 'menu_items', 'publish', 'closed', 'closed', '', 'field_611685ecf4519', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 23, 'http://localhost/ullapopken/?post_type=acf-field&p=25', 1, 'acf-field', '', 0),
(26, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Menu Item', 'menu_item', 'publish', 'closed', 'closed', '', 'field_611685fcf451a', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 25, 'http://localhost/ullapopken/?post_type=acf-field&p=26', 0, 'acf-field', '', 0),
(27, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:11:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_61168617f451b\";s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_61168628f451c', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 23, 'http://localhost/ullapopken/?post_type=acf-field&p=27', 0, 'acf-field', '', 0),
(28, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:11:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"parent_layout\";s:20:\"layout_61168617f451b\";s:9:\"collapsed\";s:19:\"field_6116865df451f\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:0:\"\";}', 'Image Menu Items', 'image_menu_items', 'publish', 'closed', 'closed', '', 'field_6116862ff451d', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 23, 'http://localhost/ullapopken/?post_type=acf-field&p=28', 1, 'acf-field', '', 0),
(29, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_6116864ff451e', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 28, 'http://localhost/ullapopken/?post_type=acf-field&p=29', 0, 'acf-field', '', 0),
(30, 1, '2021-08-13 14:49:29', '2021-08-13 14:49:29', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_6116865df451f', '', '', '2021-08-13 14:49:29', '2021-08-13 14:49:29', '', 28, 'http://localhost/ullapopken/?post_type=acf-field&p=30', 1, 'acf-field', '', 0),
(31, 1, '2021-08-13 14:57:30', '2021-08-13 14:57:30', '', 'Women Menu', '', 'publish', 'closed', 'closed', '', 'women-menu', '', '', '2021-08-13 17:36:16', '2021-08-13 17:36:16', '', 0, 'http://localhost/ullapopken/?post_type=menu&#038;p=31', 0, 'menu', '', 0),
(32, 1, '2021-08-13 14:54:05', '2021-08-13 14:54:05', '', '9174907551774', '', 'inherit', 'open', 'closed', '', '9174907551774', '', '', '2021-08-13 14:54:05', '2021-08-13 14:54:05', '', 31, 'http://localhost/ullapopken/wp-content/uploads/2021/08/9174907551774.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2021-08-13 14:54:07', '2021-08-13 14:54:07', '', '9098161553438', '', 'inherit', 'open', 'closed', '', '9098161553438', '', '', '2021-08-13 14:54:07', '2021-08-13 14:54:07', '', 31, 'http://localhost/ullapopken/wp-content/uploads/2021/08/9098161553438.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2021-08-13 14:54:08', '2021-08-13 14:54:08', '', '9187958161438', '', 'inherit', 'open', 'closed', '', '9187958161438', '', '', '2021-08-13 14:54:08', '2021-08-13 14:54:08', '', 31, 'http://localhost/ullapopken/wp-content/uploads/2021/08/9187958161438.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2021-08-13 14:57:57', '2021-08-13 14:57:57', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Custom Class', 'custom_class', 'publish', 'closed', 'closed', '', 'field_6116885d78376', '', '', '2021-08-13 14:57:57', '2021-08-13 14:57:57', '', 20, 'http://localhost/ullapopken/?post_type=acf-field&p=35', 2, 'acf-field', '', 0),
(37, 1, '2021-08-13 15:06:55', '2021-08-13 15:06:55', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"menu\";}s:8:\"taxonomy\";s:0:\"\";s:10:\"allow_null\";i:1;s:8:\"multiple\";i:0;s:13:\"return_format\";s:2:\"id\";s:2:\"ui\";i:1;}', 'Women Menu', 'women_menu', 'publish', 'closed', 'closed', '', 'field_61168a6d0aeed', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=37', 2, 'acf-field', '', 0),
(38, 1, '2021-08-13 15:06:55', '2021-08-13 15:06:55', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"menu\";}s:8:\"taxonomy\";s:0:\"\";s:10:\"allow_null\";i:1;s:8:\"multiple\";i:0;s:13:\"return_format\";s:2:\"id\";s:2:\"ui\";i:1;}', 'Men Menu', 'men_menu', 'publish', 'closed', 'closed', '', 'field_61168a820aeef', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=38', 6, 'acf-field', '', 0),
(39, 1, '2021-08-13 15:24:45', '2021-08-13 15:24:45', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Custom ID', 'custom_id', 'publish', 'closed', 'closed', '', 'field_61168eb33d2c0', '', '', '2021-08-13 15:24:45', '2021-08-13 15:24:45', '', 20, 'http://localhost/ullapopken/?post_type=acf-field&p=39', 3, 'acf-field', '', 0),
(40, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:13:\"page_template\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:13:\"page-home.php\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Home Content', 'home-content', 'publish', 'closed', 'closed', '', 'group_61169525dd405', '', '', '2021-08-13 16:39:04', '2021-08-13 16:39:04', '', 0, 'http://localhost/ullapopken/?post_type=acf-field-group&#038;p=40', 0, 'acf-field-group', '', 0),
(41, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Top Banner', 'top_banner', 'publish', 'closed', 'closed', '', 'field_611695387762b', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=41', 0, 'acf-field', '', 0),
(42, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Top Banner Title', 'top_banner_title', 'publish', 'closed', 'closed', '', 'field_611695477762c', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=42', 1, 'acf-field', '', 0),
(43, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Top Banner Content', 'top_banner_content', 'publish', 'closed', 'closed', '', 'field_6116956b7762d', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=43', 2, 'acf-field', '', 0),
(44, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Top Banner Link', 'top_banner_link', 'publish', 'closed', 'closed', '', 'field_611695767762e', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=44', 3, 'acf-field', '', 0),
(45, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Banner', 'banner', 'publish', 'closed', 'closed', '', 'field_6116958f7762f', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=45', 4, 'acf-field', '', 0),
(46, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Banner Link', 'banner_link', 'publish', 'closed', 'closed', '', 'field_6116959777630', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=46', 5, 'acf-field', '', 0),
(47, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Trends Title', 'trends_title', 'publish', 'closed', 'closed', '', 'field_611695b277631', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=47', 6, 'acf-field', '', 0),
(48, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:19:\"field_611695d577634\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:0:\"\";}', 'Trends', 'trends', 'publish', 'closed', 'closed', '', 'field_611695bc77632', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=48', 7, 'acf-field', '', 0),
(49, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_611695c977633', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 48, 'http://localhost/ullapopken/?post_type=acf-field&p=49', 0, 'acf-field', '', 0),
(50, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Title', 'title', 'publish', 'closed', 'closed', '', 'field_611695d577634', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 48, 'http://localhost/ullapopken/?post_type=acf-field&p=50', 1, 'acf-field', '', 0),
(51, 1, '2021-08-13 15:55:22', '2021-08-13 15:55:22', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Link', 'link', 'publish', 'closed', 'closed', '', 'field_611695de77635', '', '', '2021-08-13 15:55:22', '2021-08-13 15:55:22', '', 48, 'http://localhost/ullapopken/?post_type=acf-field&p=51', 2, 'acf-field', '', 0),
(52, 1, '2021-08-13 15:56:49', '2021-08-13 15:56:49', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Featured Banner', 'featured_banner', 'publish', 'closed', 'closed', '', 'field_61169603f4a63', '', '', '2021-08-13 15:56:49', '2021-08-13 15:56:49', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=52', 8, 'acf-field', '', 0),
(53, 1, '2021-08-13 15:56:49', '2021-08-13 15:56:49', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Featured Banner Link', 'featured_banner_link', 'publish', 'closed', 'closed', '', 'field_61169624f4a65', '', '', '2021-08-13 15:56:49', '2021-08-13 15:56:49', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=53', 9, 'acf-field', '', 0),
(54, 1, '2021-08-13 15:56:49', '2021-08-13 15:56:49', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Featured Banner Content', 'featured_banner_content', 'publish', 'closed', 'closed', '', 'field_61169632f4a66', '', '', '2021-08-13 15:56:49', '2021-08-13 15:56:49', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=54', 10, 'acf-field', '', 0),
(55, 1, '2021-08-13 15:58:41', '2021-08-13 15:58:41', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'Subscribe Text', 'subscribe_text', 'publish', 'closed', 'closed', '', 'field_611696792d3b9', '', '', '2021-08-13 15:58:41', '2021-08-13 15:58:41', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=55', 11, 'acf-field', '', 0),
(56, 1, '2021-08-13 15:58:41', '2021-08-13 15:58:41', 'a:6:{s:4:\"type\";s:4:\"link\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";}', 'Subscribe Link', 'subscribe_link', 'publish', 'closed', 'closed', '', 'field_611696842d3ba', '', '', '2021-08-13 15:58:41', '2021-08-13 15:58:41', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=56', 12, 'acf-field', '', 0),
(57, 1, '2021-08-13 15:58:41', '2021-08-13 15:58:41', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'About Title', 'about_title', 'publish', 'closed', 'closed', '', 'field_611696992d3bb', '', '', '2021-08-13 15:58:41', '2021-08-13 15:58:41', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=57', 13, 'acf-field', '', 0),
(58, 1, '2021-08-13 15:58:41', '2021-08-13 15:58:41', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'About Content', 'about_content', 'publish', 'closed', 'closed', '', 'field_611696a12d3bc', '', '', '2021-08-13 15:58:41', '2021-08-13 15:58:41', '', 40, 'http://localhost/ullapopken/?post_type=acf-field&p=58', 14, 'acf-field', '', 0),
(59, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Common', 'genaral', 'publish', 'closed', 'closed', '', 'field_611696ea88e91', '', '', '2021-08-13 16:02:01', '2021-08-13 16:02:01', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&p=59', 0, 'acf-field', '', 0),
(60, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Men', 'men', 'publish', 'closed', 'closed', '', 'field_6116971188e93', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=60', 4, 'acf-field', '', 0),
(61, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Footer', 'genaral_copy', 'publish', 'closed', 'closed', '', 'field_6116970488e92', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=61', 2, 'acf-field', '', 0),
(62, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'Promotion', 'promotion', 'publish', 'closed', 'closed', '', 'field_6116971c88e94', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=62', 3, 'acf-field', '', 0),
(63, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:8:\"repeater\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"collapsed\";s:0:\"\";s:3:\"min\";s:0:\"\";s:3:\"max\";s:0:\"\";s:6:\"layout\";s:5:\"block\";s:12:\"button_label\";s:0:\"\";}', 'Services', 'services', 'publish', 'closed', 'closed', '', 'field_6116973c88e95', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=63', 4, 'acf-field', '', 0),
(64, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Service', 'service', 'publish', 'closed', 'closed', '', 'field_6116974788e96', '', '', '2021-08-13 16:02:01', '2021-08-13 16:02:01', '', 63, 'http://localhost/ullapopken/?post_type=acf-field&p=64', 0, 'acf-field', '', 0),
(65, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Telephone', 'telephone', 'publish', 'closed', 'closed', '', 'field_6116975f88e97', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=65', 5, 'acf-field', '', 0),
(66, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Open Hour', 'open_hour', 'publish', 'closed', 'closed', '', 'field_6116976888e98', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=66', 6, 'acf-field', '', 0),
(67, 1, '2021-08-13 16:02:01', '2021-08-13 16:02:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Email', 'email', 'publish', 'closed', 'closed', '', 'field_6116976f88e99', '', '', '2021-08-16 03:26:46', '2021-08-16 03:26:46', '', 11, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=67', 7, 'acf-field', '', 0),
(69, 1, '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 'FAQ', '', 'publish', 'closed', 'closed', '', 'faq', '', '', '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 0, 'http://localhost/ullapopken/?p=69', 1, 'nav_menu_item', '', 0),
(70, 1, '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 'Quick Order', '', 'publish', 'closed', 'closed', '', 'quick-order-2', '', '', '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 0, 'http://localhost/ullapopken/?p=70', 2, 'nav_menu_item', '', 0),
(71, 1, '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 'Birthday discount', '', 'publish', 'closed', 'closed', '', 'birthday-discount', '', '', '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 0, 'http://localhost/ullapopken/?p=71', 3, 'nav_menu_item', '', 0),
(72, 1, '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 'Newsletter', '', 'publish', 'closed', 'closed', '', 'newsletter', '', '', '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 0, 'http://localhost/ullapopken/?p=72', 4, 'nav_menu_item', '', 0),
(73, 1, '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 'Payment', '', 'publish', 'closed', 'closed', '', 'payment', '', '', '2021-08-13 16:16:20', '2021-08-13 16:16:20', '', 0, 'http://localhost/ullapopken/?p=73', 5, 'nav_menu_item', '', 0),
(74, 1, '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 'Company', '', 'publish', 'closed', 'closed', '', 'company', '', '', '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 0, 'http://localhost/ullapopken/?p=74', 1, 'nav_menu_item', '', 0),
(75, 1, '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 'Jobs', '', 'publish', 'closed', 'closed', '', 'jobs', '', '', '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 0, 'http://localhost/ullapopken/?p=75', 2, 'nav_menu_item', '', 0),
(76, 1, '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 'Press', '', 'publish', 'closed', 'closed', '', 'press', '', '', '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 0, 'http://localhost/ullapopken/?p=76', 3, 'nav_menu_item', '', 0),
(77, 1, '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 'Sustainability', '', 'publish', 'closed', 'closed', '', 'sustainability', '', '', '2021-08-13 16:17:05', '2021-08-13 16:17:05', '', 0, 'http://localhost/ullapopken/?p=77', 4, 'nav_menu_item', '', 0),
(78, 1, '2021-08-13 16:17:45', '2021-08-13 16:17:45', '', '8813329317918', '', 'inherit', 'open', 'closed', '', '8813329317918', '', '', '2021-08-13 16:17:45', '2021-08-13 16:17:45', '', 0, 'http://localhost/ullapopken/wp-content/uploads/2021/08/8813329317918.png', 0, 'attachment', 'image/png', 0),
(79, 1, '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 'Data Security', '', 'publish', 'closed', 'closed', '', 'data-security', '', '', '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 0, 'http://localhost/ullapopken/?p=79', 1, 'nav_menu_item', '', 0),
(80, 1, '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 'Terms and Conditons', '', 'publish', 'closed', 'closed', '', 'terms-and-conditons', '', '', '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 0, 'http://localhost/ullapopken/?p=80', 2, 'nav_menu_item', '', 0),
(81, 1, '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 'Impressum', '', 'publish', 'closed', 'closed', '', 'impressum', '', '', '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 0, 'http://localhost/ullapopken/?p=81', 3, 'nav_menu_item', '', 0),
(82, 1, '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 'Withdrawal', '', 'publish', 'closed', 'closed', '', 'withdrawal', '', '', '2021-08-13 16:27:29', '2021-08-13 16:27:29', '', 0, 'http://localhost/ullapopken/?p=82', 4, 'nav_menu_item', '', 0),
(83, 1, '2021-08-13 16:30:59', '2021-08-13 16:30:59', '', '9188995989534', '', 'inherit', 'open', 'closed', '', '9188995989534', '', '', '2021-08-13 16:30:59', '2021-08-13 16:30:59', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/9188995989534.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2021-08-13 16:33:02', '2021-08-13 16:33:02', '', 'banner', '', 'inherit', 'open', 'closed', '', 'banner', '', '', '2021-08-13 16:33:02', '2021-08-13 16:33:02', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/banner.png', 0, 'attachment', 'image/png', 0),
(85, 1, '2021-08-13 16:33:26', '2021-08-13 16:33:26', '', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-13 16:33:26', '2021-08-13 16:33:26', '', 2, 'http://localhost/ullapopken/?p=85', 0, 'revision', '', 0),
(86, 1, '2021-08-13 16:34:32', '2021-08-13 16:34:32', '', 'up_dy_campaign_vorschau', '', 'inherit', 'open', 'closed', '', 'up_dy_campaign_vorschau', '', '', '2021-08-13 16:34:32', '2021-08-13 16:34:32', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/up_dy_campaign_vorschau.webp', 0, 'attachment', 'image/webp', 0),
(87, 1, '2021-08-13 16:34:34', '2021-08-13 16:34:34', '', 'up_dy_campaign_socken', '', 'inherit', 'open', 'closed', '', 'up_dy_campaign_socken', '', '', '2021-08-13 16:34:34', '2021-08-13 16:34:34', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/up_dy_campaign_socken.webp', 0, 'attachment', 'image/webp', 0),
(88, 1, '2021-08-13 16:34:35', '2021-08-13 16:34:35', '', 'up_dy_campaign_bohemian', '', 'inherit', 'open', 'closed', '', 'up_dy_campaign_bohemian', '', '', '2021-08-13 16:34:35', '2021-08-13 16:34:35', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/up_dy_campaign_bohemian.webp', 0, 'attachment', 'image/webp', 0),
(89, 1, '2021-08-13 16:34:37', '2021-08-13 16:34:37', '', 'up_dy_campaign_neuheiten', '', 'inherit', 'open', 'closed', '', 'up_dy_campaign_neuheiten', '', '', '2021-08-13 16:34:37', '2021-08-13 16:34:37', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/up_dy_campaign_neuheiten.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 1, '2021-08-13 16:36:13', '2021-08-13 16:36:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-13 16:36:13', '2021-08-13 16:36:13', '', 2, 'http://localhost/ullapopken/?p=90', 0, 'revision', '', 0),
(91, 1, '2021-08-13 16:36:26', '2021-08-13 16:36:26', '', '70ff05712de1__up_kw29_herol_denim', '', 'inherit', 'open', 'closed', '', '70ff05712de1__up_kw29_herol_denim', '', '', '2021-08-13 16:36:26', '2021-08-13 16:36:26', '', 2, 'http://localhost/ullapopken/wp-content/uploads/2021/08/70ff05712de1__up_kw29_herol_denim.jpg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2021-08-13 16:38:31', '2021-08-13 16:38:31', '', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-13 16:38:31', '2021-08-13 16:38:31', '', 2, 'http://localhost/ullapopken/?p=92', 0, 'revision', '', 0),
(93, 1, '2021-08-13 16:39:04', '2021-08-13 16:39:04', 'a:6:{s:4:\"type\";s:12:\"color_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";}', 'Color', 'color', 'publish', 'closed', 'closed', '', 'field_6116a014d1ca5', '', '', '2021-08-13 16:39:04', '2021-08-13 16:39:04', '', 48, 'http://localhost/ullapopken/?post_type=acf-field&p=93', 3, 'acf-field', '', 0),
(94, 1, '2021-08-13 16:40:46', '2021-08-13 16:40:46', '', 'Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-13 16:40:46', '2021-08-13 16:40:46', '', 2, 'http://localhost/ullapopken/?p=94', 0, 'revision', '', 0),
(95, 1, '2021-08-16 02:39:58', '2021-08-16 02:39:58', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";s:0:\"\";s:10:\"allow_null\";i:1;s:8:\"multiple\";i:0;s:13:\"return_format\";s:2:\"id\";s:2:\"ui\";i:1;}', 'Women Home Page', 'women_home', 'publish', 'closed', 'closed', '', 'field_6119cfd45bc69', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=95', 1, 'acf-field', '', 0),
(96, 1, '2021-08-16 02:39:58', '2021-08-16 02:39:58', 'a:11:{s:4:\"type\";s:11:\"post_object\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"post_type\";a:1:{i:0;s:4:\"page\";}s:8:\"taxonomy\";s:0:\"\";s:10:\"allow_null\";i:1;s:8:\"multiple\";i:0;s:13:\"return_format\";s:2:\"id\";s:2:\"ui\";i:1;}', 'Men Home Page', 'men_home', 'publish', 'closed', 'closed', '', 'field_6119cfe55bc6a', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&#038;p=96', 5, 'acf-field', '', 0),
(97, 1, '2021-08-16 02:47:37', '2021-08-16 02:47:37', '', 'Women Home', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2021-08-16 02:47:37', '2021-08-16 02:47:37', '', 2, 'http://localhost/ullapopken/?p=97', 0, 'revision', '', 0),
(98, 1, '2021-08-16 02:47:54', '2021-08-16 02:47:54', '', 'Men Home', '', 'publish', 'closed', 'closed', '', 'men-home', '', '', '2021-08-16 02:47:54', '2021-08-16 02:47:54', '', 0, 'http://localhost/ullapopken/?page_id=98', 0, 'page', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(99, 1, '2021-08-16 02:47:54', '2021-08-16 02:47:54', '', 'Men Home', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2021-08-16 02:47:54', '2021-08-16 02:47:54', '', 98, 'http://localhost/ullapopken/?p=99', 0, 'revision', '', 0),
(101, 1, '2021-08-16 03:25:51', '2021-08-16 03:25:51', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:12:\"options_page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:25:\"acf-options-shop-settings\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Shop Settings', 'shop-settings', 'publish', 'closed', 'closed', '', 'group_6119dab36abac', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 0, 'http://localhost/ullapopken/?post_type=acf-field-group&#038;p=101', 0, 'acf-field-group', '', 0),
(102, 1, '2021-08-16 03:28:18', '2021-08-16 03:28:18', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Women', '_copy', 'publish', 'closed', 'closed', '', 'field_6119db05e3b3e', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&p=102', 0, 'acf-field', '', 0),
(103, 1, '2021-08-16 03:28:18', '2021-08-16 03:28:18', 'a:13:{s:4:\"type\";s:8:\"taxonomy\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:8:\"taxonomy\";s:11:\"product_cat\";s:10:\"field_type\";s:6:\"select\";s:10:\"allow_null\";i:1;s:8:\"add_term\";i:0;s:10:\"save_terms\";i:0;s:10:\"load_terms\";i:0;s:13:\"return_format\";s:6:\"object\";s:8:\"multiple\";i:0;}', 'Women Category', 'women_category', 'publish', 'closed', 'closed', '', 'field_6119db22e3b3f', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&p=103', 3, 'acf-field', '', 0),
(104, 1, '2021-08-16 03:28:18', '2021-08-16 03:28:18', 'a:13:{s:4:\"type\";s:8:\"taxonomy\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:8:\"taxonomy\";s:11:\"product_cat\";s:10:\"field_type\";s:6:\"select\";s:10:\"allow_null\";i:1;s:8:\"add_term\";i:0;s:10:\"save_terms\";i:0;s:10:\"load_terms\";i:0;s:13:\"return_format\";s:6:\"object\";s:8:\"multiple\";i:0;}', 'Men Category', 'men_category', 'publish', 'closed', 'closed', '', 'field_6119db44e3b40', '', '', '2021-08-16 03:28:18', '2021-08-16 03:28:18', '', 101, 'http://localhost/ullapopken/?post_type=acf-field&p=104', 7, 'acf-field', '', 0),
(105, 1, '2021-08-16 15:44:13', '2021-08-16 15:44:13', '<ul>\r\n 	<li>Measures aprox. 19¾</li>\r\n</ul>\r\nSturdy and Versatile Canvas Bag in large lotus leaf look. Useful model with handles and adjustable, removable shoulder strap. Lined interior with zip pocket and handy compartments.', 'Sturdy and Versatile Canvas Bag', '', 'publish', 'open', 'closed', '', 'sturdy-and-versatile-canvas-bag', '', '', '2021-08-16 15:45:53', '2021-08-16 15:45:53', '', 0, 'http://localhost/ullapopken/?post_type=product&#038;p=105', 0, 'product', '', 0),
(106, 1, '2021-08-16 15:43:28', '2021-08-16 15:43:28', '', '798552820_ecom_g_02', '', 'inherit', 'open', 'closed', '', '798552820_ecom_g_02', '', '', '2021-08-16 15:43:28', '2021-08-16 15:43:28', '', 105, 'http://localhost/ullapopken/wp-content/uploads/2021/08/798552820_ecom_g_02.webp', 0, 'attachment', 'image/webp', 0),
(107, 1, '2021-08-16 15:43:30', '2021-08-16 15:43:30', '', '798552820_ecom_g_01', '', 'inherit', 'open', 'closed', '', '798552820_ecom_g_01', '', '', '2021-08-16 15:43:30', '2021-08-16 15:43:30', '', 105, 'http://localhost/ullapopken/wp-content/uploads/2021/08/798552820_ecom_g_01.jpg', 0, 'attachment', 'image/jpeg', 0),
(108, 1, '2021-08-16 15:43:32', '2021-08-16 15:43:32', '', '798552820_ecom_g_03', '', 'inherit', 'open', 'closed', '', '798552820_ecom_g_03', '', '', '2021-08-16 15:43:32', '2021-08-16 15:43:32', '', 105, 'http://localhost/ullapopken/wp-content/uploads/2021/08/798552820_ecom_g_03.webp', 0, 'attachment', 'image/webp', 0),
(109, 1, '2021-08-16 15:45:21', '2021-08-16 15:45:21', '', 'Sturdy and Versatile Canvas Bag - red', 'Color: red', 'publish', 'closed', 'closed', '', 'sturdy-and-versatile-canvas-bag', '', '', '2021-08-16 15:45:51', '2021-08-16 15:45:51', '', 105, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=109', 0, 'product_variation', '', 0),
(110, 1, '2021-08-16 15:49:53', '2021-08-16 15:49:53', '', 'Universal Hood', '', 'publish', 'open', 'closed', '', 'universal-hood', '', '', '2021-08-16 15:49:53', '2021-08-16 15:49:53', '', 0, 'http://localhost/ullapopken/?post_type=product&#038;p=110', 0, 'product', '', 0),
(111, 1, '2021-08-16 15:47:38', '2021-08-16 15:47:38', '', 'Universal Hood - black', 'Color: black', 'publish', 'closed', 'closed', '', 'auto-draft', '', '', '2021-08-16 15:49:52', '2021-08-16 15:49:52', '', 110, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=111', 1, 'product_variation', '', 0),
(112, 1, '2021-08-16 15:47:45', '2021-08-16 15:47:45', '', 'Universal Hood - yellow', 'Color: yellow', 'publish', 'closed', 'closed', '', 'auto-draft-2', '', '', '2021-08-16 15:49:52', '2021-08-16 15:49:52', '', 110, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=112', 2, 'product_variation', '', 0),
(113, 1, '2021-08-16 15:49:00', '2021-08-16 15:49:00', '', '797353100_ecom_g_02', '', 'inherit', 'open', 'closed', '', '797353100_ecom_g_02', '', '', '2021-08-16 15:49:00', '2021-08-16 15:49:00', '', 111, 'http://localhost/ullapopken/wp-content/uploads/2021/08/797353100_ecom_g_02.webp', 0, 'attachment', 'image/webp', 0),
(114, 1, '2021-08-16 15:49:02', '2021-08-16 15:49:02', '', '797353100_ecom_g_01', '', 'inherit', 'open', 'closed', '', '797353100_ecom_g_01', '', '', '2021-08-16 15:49:02', '2021-08-16 15:49:02', '', 111, 'http://localhost/ullapopken/wp-content/uploads/2021/08/797353100_ecom_g_01.webp', 0, 'attachment', 'image/webp', 0),
(115, 1, '2021-08-16 15:49:25', '2021-08-16 15:49:25', '', '797353402_ecom_g_01', '', 'inherit', 'open', 'closed', '', '797353402_ecom_g_01', '', '', '2021-08-16 15:49:25', '2021-08-16 15:49:25', '', 112, 'http://localhost/ullapopken/wp-content/uploads/2021/08/797353402_ecom_g_01.webp', 0, 'attachment', 'image/webp', 0),
(116, 1, '2021-08-16 15:49:27', '2021-08-16 15:49:27', '', '797353402_ecom_g_02', '', 'inherit', 'open', 'closed', '', '797353402_ecom_g_02', '', '', '2021-08-16 15:49:27', '2021-08-16 15:49:27', '', 112, 'http://localhost/ullapopken/wp-content/uploads/2021/08/797353402_ecom_g_02.webp', 0, 'attachment', 'image/webp', 0),
(117, 1, '2021-08-16 15:58:45', '2021-08-16 15:58:45', '', 'Oversized Denim Shirt', '', 'publish', 'open', 'closed', '', 'oversized-denim-shirt', '', '', '2021-08-16 16:00:37', '2021-08-16 16:00:37', '', 0, 'http://localhost/ullapopken/?post_type=product&#038;p=117', 0, 'product', '', 0),
(118, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - blue, 38/40', 'Color: blue, Size: 38/40', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-38-40-blue', '', '', '2021-08-16 16:00:36', '2021-08-16 16:00:36', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&p=118', 1, 'product_variation', '', 0),
(123, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - grey, 38/40', 'Color: grey, Size: 38/40', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-38-40-grey', '', '', '2021-08-16 15:58:44', '2021-08-16 15:58:44', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=123', 2, 'product_variation', '', 0),
(124, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - grey, 42/44', 'Color: grey, Size: 42/44', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-42-44-grey', '', '', '2021-08-16 15:58:44', '2021-08-16 15:58:44', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=124', 3, 'product_variation', '', 0),
(125, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - grey, 46/48', 'Color: grey, Size: 46/48', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-46-48-grey', '', '', '2021-08-16 15:58:44', '2021-08-16 15:58:44', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=125', 4, 'product_variation', '', 0),
(126, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - grey, 50/52', 'Color: grey, Size: 50/52', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-50-52-grey', '', '', '2021-08-16 15:58:44', '2021-08-16 15:58:44', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=126', 5, 'product_variation', '', 0),
(127, 1, '2021-08-16 15:54:39', '2021-08-16 15:54:39', '', 'Oversized Denim Shirt - grey, 54/56', 'Color: grey, Size: 54/56', 'publish', 'closed', 'closed', '', 'oversized-denim-shirt-54-56-grey', '', '', '2021-08-16 15:58:44', '2021-08-16 15:58:44', '', 117, 'http://localhost/ullapopken/?post_type=product_variation&#038;p=127', 6, 'product_variation', '', 0),
(128, 1, '2021-08-16 15:57:05', '2021-08-16 15:57:05', '', '748007904_ecom_g_01', '', 'inherit', 'open', 'closed', '', '748007904_ecom_g_01', '', '', '2021-08-16 15:57:05', '2021-08-16 15:57:05', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007904_ecom_g_01.webp', 0, 'attachment', 'image/webp', 0),
(129, 1, '2021-08-16 15:57:07', '2021-08-16 15:57:07', '', '748007904_model_g_02', '', 'inherit', 'open', 'closed', '', '748007904_model_g_02', '', '', '2021-08-16 15:57:07', '2021-08-16 15:57:07', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007904_model_g_02.webp', 0, 'attachment', 'image/webp', 0),
(130, 1, '2021-08-16 15:57:10', '2021-08-16 15:57:10', '', '748007904_model_g_21', '', 'inherit', 'open', 'closed', '', '748007904_model_g_21', '', '', '2021-08-16 15:57:10', '2021-08-16 15:57:10', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007904_model_g_21.webp', 0, 'attachment', 'image/webp', 0),
(131, 1, '2021-08-16 15:57:13', '2021-08-16 15:57:13', '', '748007904_model_g_01', '', 'inherit', 'open', 'closed', '', '748007904_model_g_01', '', '', '2021-08-16 15:57:13', '2021-08-16 15:57:13', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007904_model_g_01.webp', 0, 'attachment', 'image/webp', 0),
(132, 1, '2021-08-16 15:57:37', '2021-08-16 15:57:37', '', '748007903_model_g_21', '', 'inherit', 'open', 'closed', '', '748007903_model_g_21', '', '', '2021-08-16 15:57:37', '2021-08-16 15:57:37', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007903_model_g_21.webp', 0, 'attachment', 'image/webp', 0),
(133, 1, '2021-08-16 15:57:39', '2021-08-16 15:57:39', '', '748007903_model_g_01', '', 'inherit', 'open', 'closed', '', '748007903_model_g_01', '', '', '2021-08-16 15:57:39', '2021-08-16 15:57:39', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007903_model_g_01.webp', 0, 'attachment', 'image/webp', 0),
(134, 1, '2021-08-16 15:57:41', '2021-08-16 15:57:41', '', '748007903_ecom_g_01', '', 'inherit', 'open', 'closed', '', '748007903_ecom_g_01', '', '', '2021-08-16 15:57:41', '2021-08-16 15:57:41', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007903_ecom_g_01.webp', 0, 'attachment', 'image/webp', 0),
(135, 1, '2021-08-16 15:57:44', '2021-08-16 15:57:44', '', '748007903_model_g_02', '', 'inherit', 'open', 'closed', '', '748007903_model_g_02', '', '', '2021-08-16 15:57:44', '2021-08-16 15:57:44', '', 117, 'http://localhost/ullapopken/wp-content/uploads/2021/08/748007903_model_g_02.webp', 0, 'attachment', 'image/webp', 0),
(136, 1, '2021-08-16 16:02:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-08-16 16:02:05', '0000-00-00 00:00:00', '', 0, 'http://localhost/ullapopken/?post_type=pwf_woofilter&p=136', 0, 'pwf_woofilter', '', 0),
(137, 1, '2021-08-16 16:04:16', '2021-08-16 16:04:16', '', 'Shop Filter', '', 'publish', 'closed', 'closed', '', 'shop-filter', '', '', '2021-08-17 15:03:43', '2021-08-17 15:03:43', '', 0, 'http://localhost/ullapopken/?post_type=pwf_woofilter&#038;p=137', 0, 'pwf_woofilter', '', 0),
(138, 1, '2021-08-16 19:04:29', '2021-08-16 19:04:29', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:8:\"taxonomy\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"pa_color\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Color Attributes Data', 'color-attributes-data', 'publish', 'closed', 'closed', '', 'group_611ab68c867f1', '', '', '2021-08-16 19:04:29', '2021-08-16 19:04:29', '', 0, 'http://localhost/ullapopken/?post_type=acf-field-group&#038;p=138', 0, 'acf-field-group', '', 0),
(139, 1, '2021-08-16 19:04:29', '2021-08-16 19:04:29', 'a:6:{s:4:\"type\";s:12:\"color_picker\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";}', 'Color', 'color', 'publish', 'closed', 'closed', '', 'field_611ab6ab417cf', '', '', '2021-08-16 19:04:29', '2021-08-16 19:04:29', '', 138, 'http://localhost/ullapopken/?post_type=acf-field&p=139', 0, 'acf-field', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_smush_dir_images`
--

CREATE TABLE `wp_smush_dir_images` (
  `id` mediumint(9) NOT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_hash` char(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resize` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lossy` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_size` int(10) UNSIGNED DEFAULT NULL,
  `orig_size` int(10) UNSIGNED DEFAULT NULL,
  `file_time` int(10) UNSIGNED DEFAULT NULL,
  `last_scan` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_termmeta`
--

INSERT INTO `wp_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 17, 'order', '0'),
(2, 17, 'thumbnail_id', '0'),
(3, 17, 'display_type', ''),
(4, 18, 'order', '0'),
(5, 18, 'thumbnail_id', '0'),
(6, 18, 'display_type', ''),
(7, 22, 'order_pa_size', '0'),
(8, 23, 'order_pa_size', '0'),
(9, 24, 'order_pa_size', '0'),
(10, 25, 'order_pa_size', '0'),
(11, 26, 'order_pa_size', '0'),
(12, 27, 'order_pa_size', '0'),
(13, 28, 'order_pa_size', '0'),
(14, 29, 'order_pa_size', '0'),
(15, 30, 'order_pa_size', '0'),
(16, 31, 'order_pa_size', '0'),
(17, 32, 'order_pa_size', '0'),
(18, 33, 'order_pa_size', '0'),
(19, 34, 'order_pa_size', '0'),
(20, 35, 'order_pa_size', '0'),
(21, 36, 'order_pa_size', '0'),
(22, 37, 'order_pa_size', '0'),
(23, 38, 'order_pa_size', '0'),
(24, 39, 'order_pa_size', '0'),
(25, 40, 'order_pa_size', '0'),
(26, 41, 'order_pa_size', '0'),
(27, 42, 'order_pa_size', '0'),
(28, 43, 'order_pa_size', '0'),
(29, 44, 'order_pa_color', '0'),
(30, 45, 'order_pa_color', '0'),
(31, 46, 'order_pa_color', '0'),
(32, 47, 'order_pa_color', '0'),
(33, 48, 'order_pa_color', '0'),
(34, 49, 'order_pa_color', '0'),
(35, 50, 'order_pa_color', '0'),
(36, 51, 'order_pa_color', '0'),
(37, 52, 'order_pa_color', '0'),
(38, 53, 'order_pa_color', '0'),
(39, 54, 'order_pa_color', '0'),
(40, 55, 'order_pa_color', '0'),
(41, 56, 'order_pa_color', '0'),
(42, 57, 'order_pa_material', '0'),
(43, 58, 'order_pa_material', '0'),
(44, 59, 'order_pa_material', '0'),
(45, 60, 'order_pa_material', '0'),
(46, 61, 'order_pa_material', '0'),
(47, 62, 'order_pa_material', '0'),
(48, 63, 'order_pa_material', '0'),
(49, 64, 'order_pa_material', '0'),
(50, 65, 'order_pa_material', '0'),
(51, 66, 'order_pa_material', '0'),
(52, 67, 'order', '0'),
(53, 67, 'thumbnail_id', '0'),
(54, 67, 'display_type', ''),
(55, 68, 'order', '0'),
(56, 68, 'thumbnail_id', '0'),
(57, 68, 'display_type', ''),
(58, 69, 'order', '0'),
(59, 69, 'thumbnail_id', '0'),
(60, 69, 'display_type', ''),
(61, 70, 'order', '0'),
(62, 70, 'thumbnail_id', '0'),
(63, 70, 'display_type', ''),
(64, 71, 'order', '0'),
(65, 71, 'thumbnail_id', '0'),
(66, 71, 'display_type', ''),
(67, 72, 'order', '0'),
(68, 72, 'thumbnail_id', '0'),
(69, 72, 'display_type', ''),
(70, 73, 'order', '0'),
(71, 73, 'thumbnail_id', '0'),
(72, 73, 'display_type', ''),
(73, 74, 'order', '0'),
(74, 74, 'thumbnail_id', '0'),
(75, 74, 'display_type', ''),
(76, 75, 'order', '0'),
(77, 75, 'thumbnail_id', '0'),
(78, 75, 'display_type', ''),
(79, 76, 'order', '0'),
(80, 76, 'thumbnail_id', '0'),
(81, 76, 'display_type', ''),
(82, 77, 'order', '0'),
(83, 77, 'thumbnail_id', '0'),
(84, 77, 'display_type', ''),
(85, 78, 'order', '0'),
(86, 78, 'thumbnail_id', '0'),
(87, 78, 'display_type', ''),
(88, 79, 'order', '0'),
(89, 79, 'thumbnail_id', '0'),
(90, 79, 'display_type', ''),
(91, 80, 'order', '0'),
(92, 80, 'thumbnail_id', '0'),
(93, 80, 'display_type', ''),
(94, 81, 'order', '0'),
(95, 81, 'thumbnail_id', '0'),
(96, 81, 'display_type', ''),
(97, 82, 'order', '0'),
(98, 82, 'thumbnail_id', '0'),
(99, 82, 'display_type', ''),
(100, 83, 'order', '0'),
(101, 83, 'thumbnail_id', '0'),
(102, 83, 'display_type', ''),
(103, 84, 'order', '0'),
(104, 84, 'thumbnail_id', '0'),
(105, 84, 'display_type', ''),
(106, 85, 'order', '0'),
(107, 85, 'thumbnail_id', '0'),
(108, 85, 'display_type', ''),
(109, 86, 'order', '0'),
(110, 86, 'thumbnail_id', '0'),
(111, 86, 'display_type', ''),
(112, 87, 'order', '0'),
(113, 87, 'thumbnail_id', '0'),
(114, 87, 'display_type', ''),
(115, 88, 'order', '0'),
(116, 88, 'thumbnail_id', '0'),
(117, 88, 'display_type', ''),
(118, 89, 'order', '0'),
(119, 89, 'thumbnail_id', '0'),
(120, 89, 'display_type', ''),
(121, 90, 'order', '0'),
(122, 90, 'thumbnail_id', '0'),
(123, 90, 'display_type', ''),
(124, 91, 'order', '0'),
(125, 91, 'thumbnail_id', '0'),
(126, 91, 'display_type', ''),
(127, 17, 'product_count_product_cat', '3'),
(128, 67, 'product_count_product_cat', '2'),
(129, 87, 'product_count_product_cat', '1'),
(130, 90, 'product_count_product_cat', '1'),
(131, 92, 'order', '0'),
(132, 92, 'thumbnail_id', '0'),
(133, 92, 'display_type', ''),
(134, 93, 'order', '0'),
(135, 93, 'thumbnail_id', '0'),
(136, 93, 'display_type', ''),
(137, 94, 'order', '0'),
(138, 94, 'thumbnail_id', '0'),
(139, 94, 'display_type', ''),
(140, 95, 'order', '0'),
(141, 95, 'thumbnail_id', '0'),
(142, 95, 'display_type', ''),
(143, 92, 'product_count_product_cat', '1'),
(144, 70, 'product_count_product_cat', '1'),
(145, 47, 'color', '#000000'),
(146, 47, '_color', 'field_611ab6ab417cf'),
(147, 44, 'color', '#1e73be'),
(148, 44, '_color', 'field_611ab6ab417cf'),
(149, 45, 'color', '#7a7a7a'),
(150, 45, '_color', 'field_611ab6ab417cf'),
(151, 49, 'color', '#dd3333'),
(152, 49, '_color', 'field_611ab6ab417cf'),
(153, 56, 'color', '#eeee22'),
(154, 56, '_color', 'field_611ab6ab417cf');

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Top Menu', 'top-menu', 0),
(17, 'Women', 'women', 0),
(18, 'Men', 'men', 0),
(19, 'Our Service', 'our-service', 0),
(20, 'About us', 'about-us', 0),
(21, 'Quick Links', 'quick-links', 0),
(22, '38/40', '38-40', 0),
(23, '42/44', '42-44', 0),
(24, '44', '44', 0),
(25, '46/48', '46-48', 0),
(26, '50', '50', 0),
(27, '50-56', '50-56', 0),
(28, '54', '54', 0),
(29, '56', '56', 0),
(30, '58/60', '58-60', 0),
(31, '60', '60', 0),
(32, '62/64', '62-64', 0),
(33, '42', '42', 0),
(34, '42-48', '42-48', 0),
(35, '46', '46', 0),
(36, '48', '48', 0),
(37, '50/52', '50-52', 0),
(38, '52', '52', 0),
(39, '54/56', '54-56', 0),
(40, '58', '58', 0),
(41, '58-64', '58-64', 0),
(42, '62', '62', 0),
(43, '66/68', '66-68', 0),
(44, 'blue', 'blue', 0),
(45, 'grey', 'grey', 0),
(46, 'beige', 'beige', 0),
(47, 'black', 'black', 0),
(48, 'white', 'white', 0),
(49, 'red', 'red', 0),
(50, 'pink', 'pink', 0),
(51, 'purple', 'purple', 0),
(52, 'green', 'green', 0),
(53, 'turquoise', 'turquoise', 0),
(54, 'orange', 'orange', 0),
(55, 'brown', 'brown', 0),
(56, 'yellow', 'yellow', 0),
(57, 'artificial silk', 'artificial-silk', 0),
(58, 'linen', 'linen', 0),
(59, 'polyester', 'polyester', 0),
(60, 'spandex', 'spandex', 0),
(61, 'viscose', 'viscose', 0),
(62, 'cotton', 'cotton', 0),
(63, 'metallic fibers', 'metallic-fibers', 0),
(64, 'silk', 'silk', 0),
(65, 'synthetic fibers', 'synthetic-fibers', 0),
(66, 'wool', 'wool', 0),
(67, 'Accessories', 'accessories', 0),
(68, 'Bathrobes', 'bathrobes', 0),
(69, 'Blazers', 'blazers', 0),
(70, 'Blouses', 'blouses', 0),
(71, 'Cardigans', 'cardigans', 0),
(72, 'Coats', 'coats', 0),
(73, 'Dresses', 'dresses', 0),
(74, 'Jackets', 'jackets', 0),
(75, 'Lingerie', 'lingerie', 0),
(76, 'Loungewear', 'loungewear', 0),
(77, 'Pants', 'pants', 0),
(78, 'Shoes', 'shoes', 0),
(79, 'Skirts', 'skirts', 0),
(80, 'Sleepwear', 'sleepwear', 0),
(81, 'Socks', 'socks', 0),
(82, 'Sweaters', 'sweaters', 0),
(83, 'Sweatshirts', 'sweatshirts', 0),
(84, 'Swimwear', 'swimwear', 0),
(85, 'Tops', 'tops', 0),
(86, 'Vests', 'vests', 0),
(87, 'Bags', 'bags', 0),
(88, 'Belts', 'belts', 0),
(89, 'Jewellery', 'jewellery', 0),
(90, 'Others', 'others', 0),
(91, 'Scarves', 'scarves', 0),
(92, 'Denim Shirt', 'denim-shirt', 0),
(93, 'Open Front Blouse', 'open-front-blouse', 0),
(94, 'Tanks', 'tanks', 0),
(95, 'Tunics', 'tunics', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(14, 16, 0),
(15, 16, 0),
(16, 16, 0),
(69, 19, 0),
(70, 19, 0),
(71, 19, 0),
(72, 19, 0),
(73, 19, 0),
(74, 20, 0),
(75, 20, 0),
(76, 20, 0),
(77, 20, 0),
(79, 21, 0),
(80, 21, 0),
(81, 21, 0),
(82, 21, 0),
(105, 4, 0),
(105, 17, 0),
(105, 49, 0),
(105, 67, 0),
(105, 87, 0),
(110, 4, 0),
(110, 17, 0),
(110, 47, 0),
(110, 56, 0),
(110, 67, 0),
(110, 90, 0),
(117, 4, 0),
(117, 17, 0),
(117, 22, 0),
(117, 23, 0),
(117, 25, 0),
(117, 37, 0),
(117, 39, 0),
(117, 44, 0),
(117, 45, 0),
(117, 70, 0),
(117, 92, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'product_type', '', 0, 0),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 3),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 0),
(7, 7, 'product_visibility', '', 0, 0),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'nav_menu', '', 0, 3),
(17, 17, 'product_cat', '', 0, 3),
(18, 18, 'product_cat', '', 0, 0),
(19, 19, 'nav_menu', '', 0, 5),
(20, 20, 'nav_menu', '', 0, 4),
(21, 21, 'nav_menu', '', 0, 4),
(22, 22, 'pa_size', '', 0, 1),
(23, 23, 'pa_size', '', 0, 1),
(24, 24, 'pa_size', '', 0, 0),
(25, 25, 'pa_size', '', 0, 1),
(26, 26, 'pa_size', '', 0, 0),
(27, 27, 'pa_size', '', 0, 0),
(28, 28, 'pa_size', '', 0, 0),
(29, 29, 'pa_size', '', 0, 0),
(30, 30, 'pa_size', '', 0, 0),
(31, 31, 'pa_size', '', 0, 0),
(32, 32, 'pa_size', '', 0, 0),
(33, 33, 'pa_size', '', 0, 0),
(34, 34, 'pa_size', '', 0, 0),
(35, 35, 'pa_size', '', 0, 0),
(36, 36, 'pa_size', '', 0, 0),
(37, 37, 'pa_size', '', 0, 1),
(38, 38, 'pa_size', '', 0, 0),
(39, 39, 'pa_size', '', 0, 1),
(40, 40, 'pa_size', '', 0, 0),
(41, 41, 'pa_size', '', 0, 0),
(42, 42, 'pa_size', '', 0, 0),
(43, 43, 'pa_size', '', 0, 0),
(44, 44, 'pa_color', '', 0, 1),
(45, 45, 'pa_color', '', 0, 1),
(46, 46, 'pa_color', '', 0, 0),
(47, 47, 'pa_color', '', 0, 1),
(48, 48, 'pa_color', '', 0, 0),
(49, 49, 'pa_color', '', 0, 1),
(50, 50, 'pa_color', '', 0, 0),
(51, 51, 'pa_color', '', 0, 0),
(52, 52, 'pa_color', '', 0, 0),
(53, 53, 'pa_color', '', 0, 0),
(54, 54, 'pa_color', '', 0, 0),
(55, 55, 'pa_color', '', 0, 0),
(56, 56, 'pa_color', '', 0, 1),
(57, 57, 'pa_material', '', 0, 0),
(58, 58, 'pa_material', '', 0, 0),
(59, 59, 'pa_material', '', 0, 0),
(60, 60, 'pa_material', '', 0, 0),
(61, 61, 'pa_material', '', 0, 0),
(62, 62, 'pa_material', '', 0, 0),
(63, 63, 'pa_material', '', 0, 0),
(64, 64, 'pa_material', '', 0, 0),
(65, 65, 'pa_material', '', 0, 0),
(66, 66, 'pa_material', '', 0, 0),
(67, 67, 'product_cat', '', 17, 2),
(68, 68, 'product_cat', '', 17, 0),
(69, 69, 'product_cat', '', 17, 0),
(70, 70, 'product_cat', '', 17, 1),
(71, 71, 'product_cat', '', 17, 0),
(72, 72, 'product_cat', '', 17, 0),
(73, 73, 'product_cat', '', 17, 0),
(74, 74, 'product_cat', '', 17, 0),
(75, 75, 'product_cat', '', 17, 0),
(76, 76, 'product_cat', '', 17, 0),
(77, 77, 'product_cat', '', 17, 0),
(78, 78, 'product_cat', '', 17, 0),
(79, 79, 'product_cat', '', 17, 0),
(80, 80, 'product_cat', '', 17, 0),
(81, 81, 'product_cat', '', 17, 0),
(82, 82, 'product_cat', '', 17, 0),
(83, 83, 'product_cat', '', 17, 0),
(84, 84, 'product_cat', '', 17, 0),
(85, 85, 'product_cat', '', 17, 0),
(86, 86, 'product_cat', '', 17, 0),
(87, 87, 'product_cat', '', 67, 1),
(88, 88, 'product_cat', '', 67, 0),
(89, 89, 'product_cat', '', 67, 0),
(90, 90, 'product_cat', '', 67, 1),
(91, 91, 'product_cat', '', 67, 0),
(92, 92, 'product_cat', '', 70, 1),
(93, 93, 'product_cat', '', 70, 0),
(94, 94, 'product_cat', '', 70, 0),
(95, 95, 'product_cat', '', 70, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'ullapopkenwpadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'false'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"693c2c357f91fc7bdd760559a5468fca6badcce1aa044547ad6f13370ef9a7da\";a:4:{s:10:\"expiration\";i:1629901307;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0\";s:5:\"login\";i:1628691707;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}'),
(19, 1, '_woocommerce_tracks_anon_id', 'woo:KIVojT0NqRBrFRfVSBPQo4w0'),
(20, 1, 'last_update', '1628783545'),
(21, 1, 'woocommerce_admin_activity_panel_inbox_last_read', '1628691820016'),
(22, 1, 'wc_last_active', '1629158400'),
(23, 1, 'dismissed_no_secure_connection_notice', '1'),
(24, 1, 'billing_first_name', ''),
(25, 1, 'billing_last_name', ''),
(26, 1, 'billing_company', ''),
(27, 1, 'billing_address_1', ''),
(28, 1, 'billing_address_2', ''),
(29, 1, 'billing_city', ''),
(30, 1, 'billing_postcode', ''),
(31, 1, 'billing_country', ''),
(32, 1, 'billing_state', ''),
(33, 1, 'billing_phone', ''),
(34, 1, 'billing_email', 'hettipower@gmail.com'),
(35, 1, 'shipping_first_name', ''),
(36, 1, 'shipping_last_name', ''),
(37, 1, 'shipping_company', ''),
(38, 1, 'shipping_address_1', ''),
(39, 1, 'shipping_address_2', ''),
(40, 1, 'shipping_city', ''),
(41, 1, 'shipping_postcode', ''),
(42, 1, 'shipping_country', ''),
(43, 1, 'shipping_state', ''),
(44, 1, '_order_count', '0'),
(45, 1, 'wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(46, 1, 'wp_user-settings-time', '1628870912'),
(47, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(48, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}'),
(49, 1, 'nav_menu_recently_edited', '21');

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'ullapopkenwpadmin', '$P$BaNVhuuM6s3rxqKC0ZvloDlAd8YUva/', 'ullapopkenwpadmin', 'hettipower@gmail.com', 'http://localhost/ullapopken', '2021-08-11 14:21:40', '', 0, 'ullapopkenwpadmin');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_admin_notes`
--

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT 0,
  `layout` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `icon` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'info'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_admin_notes`
--

INSERT INTO `wp_wc_admin_notes` (`note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `icon`) VALUES
(1, 'wayflyer_q3_2021', 'marketing', 'en_US', 'Grow your revenue with Wayflyer financing and analytics', 'Flexible financing tailored to your needs by <a href=\"https://woocommerce.com/products/wayflyer/\">Wayflyer</a> – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store\'s performance, Wayflyer can provide the financing you need to grow and the analytical insights to help you spend it.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(2, 'eu_vat_changes_2021', 'marketing', 'en_US', 'Get your business ready for the new EU tax regulations', 'On July 1, 2021, new taxation rules will come into play when the <a href=\"https://ec.europa.eu/taxation_customs/business/vat/modernising-vat-cross-border-ecommerce_en\">European Union (EU) Value-Added Tax (VAT) eCommerce package</a> takes effect.<br /><br />The new regulations will impact virtually every B2C business involved in cross-border eCommerce trade with the EU.<br /><br />We therefore recommend <a href=\"https://woocommerce.com/posts/new-eu-vat-regulations\">familiarizing yourself with the new updates</a>, and consult with a tax professional to ensure your business is following regulations and best practice.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(3, 'paypal_ppcp_gtm_2021', 'marketing', 'en_US', 'Offer more options with the new PayPal', 'Get the latest PayPal extension for a full suite of payment methods with extensive currency and country coverage.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(4, 'facebook_pixel_api_2021', 'marketing', 'en_US', 'Improve the performance of your Facebook ads', 'Enable Facebook Pixel and Conversions API through the latest version of Facebook for WooCommerce for improved measurement and ad targeting capabilities.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(5, 'facebook_ec_2021', 'marketing', 'en_US', 'Sync your product catalog with Facebook to help boost sales', 'A single click adds all products to your Facebook Business Page shop. Product changes are automatically synced, with the flexibility to control which products are listed.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(6, 'ecomm-need-help-setting-up-your-store', 'info', 'en_US', 'Need help setting up your Store?', 'Schedule a free 30-min <a href=\"https://wordpress.com/support/concierge-support/\">quick start session</a> and get help from our specialists. We’re happy to walk through setup steps, show you around the WordPress.com dashboard, troubleshoot any issues you may have, and help you the find the features you need to accomplish your goals for your site.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(7, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store “ready to sell” as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(8, 'ecomm-unique-shopping-experience', 'info', 'en_US', 'For a shopping experience as unique as your customers', 'Product Add-Ons allow your customers to personalize products while they’re shopping on your online store. No more follow-up email requests—customers get what they want, before they’re done checking out. Learn more about this extension that comes included in your plan.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(9, 'wc-admin-getting-started-in-ecommerce', 'info', 'en_US', 'Getting Started in eCommerce - webinar', 'We want to make eCommerce and this process of getting started as easy as possible for you. Watch this webinar to get tips on how to have our store up and running in a breeze.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(10, 'your-first-product', 'info', 'en_US', 'Your first product', 'That\'s huge! You\'re well on your way to building a successful online store — now it’s time to think about how you\'ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href=\"https://href.li/?https://woocommerce.com/shipping\" target=\"_blank\">WooCommerce Shipping</a>.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(11, 'wc-square-apple-pay-boost-sales', 'marketing', 'en_US', 'Boost sales with Apple Pay', 'Now that you accept Apple Pay® with Square you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(12, 'wc-square-apple-pay-grow-your-business', 'marketing', 'en_US', 'Grow your business with Square and Apple Pay ', 'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(13, 'wcpay-apple-pay-is-now-available', 'marketing', 'en_US', 'Apple Pay is now available with WooCommerce Payments!', 'Increase your conversion rate by offering a fast and secure checkout with <a href=\"https://woocommerce.com/apple-pay/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">Apple Pay</a>®. It’s free to get started with <a href=\"https://woocommerce.com/payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_applepay\" target=\"_blank\">WooCommerce Payments</a>.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(14, 'wcpay-apple-pay-boost-sales', 'marketing', 'en_US', 'Boost sales with Apple Pay', 'Now that you accept Apple Pay® with WooCommerce Payments you can increase conversion rates by letting your customers know that Apple Pay® is available. Here’s a marketing guide to help you get started.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(15, 'wcpay-apple-pay-grow-your-business', 'marketing', 'en_US', 'Grow your business with WooCommerce Payments and Apple Pay', 'Now more than ever, shoppers want a fast, simple, and secure online checkout experience. Increase conversion rates by letting your customers know that you now accept Apple Pay®.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(16, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It\'s crucial to get your store\'s checkout as smooth as possible to avoid losing sales. Let\'s take a look at how you can optimize the checkout experience for your shoppers.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(17, 'wc-admin-first-five-things-to-customize', 'info', 'en_US', 'The first 5 things to customize in your store', 'Deciding what to start with first is tricky. To help you properly prioritize, we\'ve put together this short list of the first few things you should customize in WooCommerce.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(18, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(19, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(20, 'wcpay_instant_deposits_gtm_2021', 'marketing', 'en_US', 'Get paid within minutes – Instant Deposits for WooCommerce Payments', 'Stay flexible with immediate access to your funds when you need them – including nights, weekends, and holidays. With <a href=\"https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox&amp;utm_medium=product&amp;utm_campaign=wcpay_instant_deposits\">WooCommerce Payments\'</a> new Instant Deposits feature, you’re able to transfer your earnings to a debit card within minutes.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(21, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(22, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site\'s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href=\"https://woocommerce.com/my-dashboard\">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href=\"https://woocommerce.com/my-account/create-a-ticket/\">open a ticket</a>.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(23, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(24, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(25, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(26, 'wcpay-promo-2021-6-incentive-1', 'marketing', 'en_US', 'Simplify the payments process for you and your customers with WooCommerce Payments', 'With <a href=\"https://woocommerce.com/payments/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay601\">WooCommerce Payments</a>, you can securely accept all major cards, Apple Pay®, and recurring revenue in over 100 currencies. \n				Built into your store’s WooCommerce dashboard, track cash flow and manage all of your transactions in one place – with no setup costs or monthly fees.\n				<br /><br />\n				By clicking \"Get WooCommerce Payments,\" you agree to the <a href=\"https://wordpress.com/tos/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay601\">Terms of Service</a> \n				and acknowledge you have read the <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>.\n				', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(27, 'wcpay-promo-2021-6-incentive-2', 'marketing', 'en_US', 'Simplify the payments process for you and your customers with WooCommerce Payments', 'With <a href=\"https://woocommerce.com/payments/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay601\">WooCommerce Payments</a>, you can securely accept all major cards, Apple Pay®, and recurring revenue in over 100 currencies. \n				Built into your store’s WooCommerce dashboard, track cash flow and manage all of your transactions in one place – with no setup costs or monthly fees.\n				<br /><br />\n				By clicking \"Get WooCommerce Payments,\" you agree to the <a href=\"https://wordpress.com/tos/?utm_medium=notification&amp;utm_source=product&amp;utm_campaign=wcpay601\">Terms of Service</a> \n				and acknowledge you have read the <a href=\"https://automattic.com/privacy/\">Privacy Policy</a>.\n				', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(28, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There\'s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(29, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'We\'ve developed a whole new <a href=\"https://woocommerce.com/products/woocommerce-paypal-payments/\" target=\"_blank\">PayPal extension for WooCommerce</a> that combines the best features of our many PayPal extensions into just one extension.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our latest PayPal today to continue to receive support and updates.', '{}', 'unactioned', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(30, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(31, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:54', NULL, 0, 'plain', '', 0, 'info'),
(32, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:55', NULL, 0, 'plain', '', 0, 'info'),
(33, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '{}', 'pending', 'woocommerce.com', '2021-08-11 14:22:55', NULL, 0, 'plain', '', 0, 'info'),
(34, 'wc-admin-onboarding-email-marketing', 'info', 'en_US', 'Sign up for tips, product updates, and inspiration', 'We\'re here for you - get tips, product updates and inspiration straight to your email box', '{}', 'unactioned', 'woocommerce-admin', '2021-08-11 14:22:55', NULL, 0, 'plain', '', 0, 'info'),
(35, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to WooCommerce.com', 'Connect to get important product notifications and updates.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-11 14:22:55', NULL, 0, 'plain', '', 0, 'info'),
(36, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Choosing a theme?', 'Check out the themes that are compatible with WooCommerce and choose one aligned with your brand and business needs.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-12 15:51:30', NULL, 0, 'plain', '', 0, 'info'),
(37, 'wc-admin-insight-first-product-and-payment', 'survey', 'en_US', 'Insight', 'More than 80% of new merchants add the first product and have at least one payment method set up during the first week.<br><br>Do you find this type of insight useful?', '{}', 'unactioned', 'woocommerce-admin', '2021-08-12 15:51:30', NULL, 0, 'plain', '', 0, 'info'),
(38, 'wc-admin-mobile-app', 'info', 'en_US', 'Install Woo mobile app', 'Install the WooCommerce mobile app to manage orders, receive sales notifications, and view key metrics — wherever you are.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-13 14:38:35', NULL, 0, 'plain', '', 0, 'info'),
(39, 'wc-admin-add-first-product-note', 'email', 'en_US', 'Add your first product', '{greetings}<br /><br />Nice one; you\'ve created a WooCommerce store! Now it\'s time to add your first product and get ready to start selling.<br /><br />There are three ways to add your products: you can <strong>create products manually, import them at once via CSV file</strong>, or <strong>migrate them from another service</strong>.<br /><br /><a href=\"https://docs.woocommerce.com/document/managing-products/?utm_source=help_panel\">Explore our docs</a> for more information, or just get started!', '{\"role\":\"administrator\"}', 'unactioned', 'woocommerce-admin', '2021-08-13 14:38:35', NULL, 0, 'plain', 'http://localhost/ullapopken/wp-content/plugins/woocommerce/packages/woocommerce-admin/images/admin_notes/dashboard-widget-setup.png', 0, 'info'),
(40, 'wc-admin-adding-and-managing-products', 'info', 'en_US', 'Adding and Managing Products', 'Learn more about how to set up products in WooCommerce through our useful documentation about adding and managing products.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-15 13:05:06', NULL, 0, 'plain', '', 0, 'info'),
(41, 'wc-admin-onboarding-payments-reminder', 'info', 'en_US', 'Start accepting payments on your store!', 'Take payments with the provider that’s right for you - choose from 100+ payment gateways for WooCommerce.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-16 15:38:58', NULL, 0, 'plain', '', 0, 'info'),
(42, 'wc-admin-marketing-intro', 'info', 'en_US', 'Connect with your audience', 'Grow your customer base and increase your sales with marketing tools built for WooCommerce.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-16 15:38:58', NULL, 0, 'plain', '', 0, 'info'),
(43, 'wc-admin-learn-more-about-variable-products', 'info', 'en_US', 'Learn more about variable products', 'Variable products are a powerful product type that lets you offer a set of variations on a product, with control over prices, stock, image and more for each variation. They can be used for a product like a shirt, where you can offer a large, medium and small and in different colors.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-16 15:44:13', NULL, 0, 'plain', '', 0, 'info'),
(44, 'wc-admin-filter-by-product-variations-in-reports', 'info', 'en_US', 'New - filter by product variations in orders and products reports', 'One of the most awaited features has just arrived! You can now have insights into each product variation in the orders and products reports.', '{}', 'unactioned', 'woocommerce-admin', '2021-08-17 14:33:04', NULL, 0, 'banner', 'http://localhost/ullapopken/wp-content/plugins/woocommerce/packages/woocommerce-admin/images/admin_notes/filter-by-product-variations-note.svg', 0, 'info');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_admin_note_actions`
--

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `note_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_admin_note_actions`
--

INSERT INTO `wp_wc_admin_note_actions` (`action_id`, `note_id`, `name`, `label`, `query`, `status`, `is_primary`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(37, 34, 'yes-please', 'Yes please!', 'https://woocommerce.us8.list-manage.com/subscribe/post?u=2c1434dc56f9506bf3c3ecd21&amp;id=13860df971&amp;SIGNUPPAGE=plugin', 'actioned', 0, '', NULL, NULL),
(74, 35, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', 0, '', NULL, NULL),
(219, 36, 'visit-the-theme-marketplace', 'Visit the theme marketplace', 'https://woocommerce.com/product-category/themes/?utm_source=inbox', 'actioned', 0, '', NULL, NULL),
(220, 37, 'affirm-insight-first-product-and-payment', 'Yes', '', 'actioned', 0, 'Thanks for your feedback', NULL, NULL),
(221, 37, 'affirm-insight-first-product-and-payment', 'No', '', 'actioned', 0, 'Thanks for your feedback', NULL, NULL),
(402, 38, 'learn-more', 'Learn more', 'https://woocommerce.com/mobile/', 'actioned', 0, '', NULL, NULL),
(403, 39, 'add-first-product', 'Add a product', 'http://localhost/ullapopken/wp-admin/admin.php?page=wc-admin&task=products', 'actioned', 0, '', NULL, NULL),
(512, 40, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/managing-products/?utm_source=inbox', 'actioned', 0, '', NULL, NULL),
(657, 41, 'view-payment-gateways', 'Learn more', 'https://woocommerce.com/product-category/woocommerce-extensions/payment-gateways/', 'actioned', 1, '', NULL, NULL),
(658, 42, 'open-marketing-hub', 'Open marketing hub', 'http://localhost/ullapopken/wp-admin/admin.php?page=wc-admin&path=/marketing', 'actioned', 0, '', NULL, NULL),
(731, 43, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/variable-product/?utm_source=inbox', 'actioned', 0, '', NULL, NULL),
(912, 44, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-analytics/#variations-report', 'actioned', 0, '', NULL, NULL),
(913, 1, 'wayflyer_q3_2021', 'Get funded', 'https://woocommerce.com/products/wayflyer/', 'actioned', 1, '', NULL, NULL),
(914, 2, 'eu_vat_changes_2021', 'Learn more about the EU tax regulations', 'https://woocommerce.com/posts/new-eu-vat-regulations', 'actioned', 1, '', NULL, NULL),
(915, 3, 'open_wc_paypal_payments_product_page', 'Learn more', 'https://woocommerce.com/products/woocommerce-paypal-payments/', 'actioned', 1, '', NULL, NULL),
(916, 4, 'upgrade_now_facebook_pixel_api', 'Upgrade now', 'plugin-install.php?tab=plugin-information&plugin=&section=changelog', 'actioned', 1, '', NULL, NULL),
(917, 5, 'learn_more_facebook_ec', 'Learn more', 'https://woocommerce.com/products/facebook/', 'unactioned', 1, '', NULL, NULL),
(918, 6, 'set-up-concierge', 'Schedule free session', 'https://wordpress.com/me/concierge', 'actioned', 1, '', NULL, NULL),
(919, 7, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', 1, '', NULL, NULL),
(920, 8, 'learn-more-ecomm-unique-shopping-experience', 'Learn more', 'https://docs.woocommerce.com/document/product-add-ons/?utm_source=inbox', 'actioned', 1, '', NULL, NULL),
(921, 9, 'watch-the-webinar', 'Watch the webinar', 'https://youtu.be/V_2XtCOyZ7o', 'actioned', 1, '', NULL, NULL),
(922, 10, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox', 'actioned', 1, '', NULL, NULL),
(923, 11, 'boost-sales-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-boost-sales', 'actioned', 1, '', NULL, NULL),
(924, 12, 'grow-your-business-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=square-grow-your-business', 'actioned', 1, '', NULL, NULL),
(925, 13, 'add-apple-pay', 'Add Apple Pay', '/admin.php?page=wc-settings&tab=checkout&section=woocommerce_payments', 'actioned', 1, '', NULL, NULL),
(926, 13, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/payments/apple-pay/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_applepay', 'actioned', 1, '', NULL, NULL),
(927, 14, 'boost-sales-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-boost-sales', 'actioned', 1, '', NULL, NULL),
(928, 15, 'grow-your-business-marketing-guide', 'See marketing guide', 'https://developer.apple.com/apple-pay/marketing/?utm_source=inbox&utm_campaign=wcpay-grow-your-business', 'actioned', 1, '', NULL, NULL),
(929, 16, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox', 'actioned', 1, '', NULL, NULL),
(930, 17, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/first-things-customize-woocommerce/?utm_source=inbox', 'unactioned', 1, '', NULL, NULL),
(931, 18, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', 1, '', NULL, NULL),
(932, 19, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', 1, '', NULL, NULL),
(933, 20, 'learn-more', 'Learn about Instant Deposits eligibility', 'https://docs.woocommerce.com/document/payments/instant-deposits/?utm_source=inbox&utm_medium=product&utm_campaign=wcpay_instant_deposits', 'actioned', 1, '', NULL, NULL),
(934, 21, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads', 'actioned', 1, '', NULL, NULL),
(935, 22, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost/ullapopken/wp-admin/admin.php?page=wc-admin&page=wc-addons&section=helper', 'actioned', 1, '', NULL, NULL),
(936, 23, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', 1, '', NULL, NULL),
(937, 26, 'get-woo-commerce-payments', 'Get WooCommerce Payments', 'admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', 1, '', NULL, NULL),
(938, 27, 'get-woocommerce-payments', 'Get WooCommerce Payments', 'admin.php?page=wc-admin&action=setup-woocommerce-payments', 'actioned', 1, '', NULL, NULL),
(939, 28, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', 1, '', NULL, NULL),
(940, 29, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', 1, '', NULL, NULL),
(941, 30, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms', 'unactioned', 1, '', NULL, NULL),
(942, 30, 'dismiss', 'Dismiss', '', 'actioned', 0, '', NULL, NULL),
(943, 31, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms', 'unactioned', 1, '', NULL, NULL),
(944, 31, 'dismiss', 'Dismiss', '', 'actioned', 0, '', NULL, NULL),
(945, 32, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms', 'unactioned', 1, '', NULL, NULL),
(946, 32, 'dismiss', 'Dismiss', '', 'actioned', 0, '', NULL, NULL),
(947, 33, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=vulnerability_comms', 'unactioned', 1, '', NULL, NULL),
(948, 33, 'dismiss', 'Dismiss', '', 'actioned', 0, '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_category_lookup`
--

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_category_lookup`
--

INSERT INTO `wp_wc_category_lookup` (`category_tree_id`, `category_id`) VALUES
(15, 15);

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_customer_lookup`
--

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_download_log`
--

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_coupon_lookup`
--

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_product_lookup`
--

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT 0,
  `product_gross_revenue` double NOT NULL DEFAULT 0,
  `coupon_amount` double NOT NULL DEFAULT 0,
  `tax_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double NOT NULL DEFAULT 0,
  `shipping_tax_amount` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_stats`
--

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT 0,
  `total_sales` double NOT NULL DEFAULT 0,
  `tax_total` double NOT NULL DEFAULT 0,
  `shipping_total` double NOT NULL DEFAULT 0,
  `net_total` double NOT NULL DEFAULT 0,
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_order_tax_lookup`
--

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT 0,
  `order_tax` double NOT NULL DEFAULT 0,
  `total_tax` double NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_product_meta_lookup`
--

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT 0,
  `downloadable` tinyint(1) DEFAULT 0,
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT 0,
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT 0,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `total_sales` bigint(20) DEFAULT 0,
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_product_meta_lookup`
--

INSERT INTO `wp_wc_product_meta_lookup` (`product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(105, '', 0, 0, '69.9900', '69.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(109, '', 0, 0, '69.9900', '69.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(110, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(111, '', 0, 0, '29.9900', '29.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(112, '', 0, 0, '0.0000', '0.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(117, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(118, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(123, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(124, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(125, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(126, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(127, '', 0, 0, '49.9900', '49.9900', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_reserved_stock`
--

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT 0,
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_tax_rate_classes`
--

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_wc_tax_rate_classes`
--

INSERT INTO `wp_wc_tax_rate_classes` (`tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate');

-- --------------------------------------------------------

--
-- Table structure for table `wp_wc_webhooks`
--

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT 0,
  `pending_delivery` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_api_keys`
--

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_attribute_taxonomies`
--

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_attribute_taxonomies`
--

INSERT INTO `wp_woocommerce_attribute_taxonomies` (`attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(1, 'size', 'Size', 'select', 'menu_order', 0),
(2, 'color', 'Color', 'select', 'menu_order', 0),
(3, 'material', 'Material', 'select', 'menu_order', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_downloadable_product_permissions`
--

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `order_key` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_log`
--

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_itemmeta`
--

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_order_items`
--

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) UNSIGNED NOT NULL,
  `order_item_name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokenmeta`
--

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `payment_token_id` bigint(20) UNSIGNED NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_payment_tokens`
--

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_sessions`
--

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `session_key` char(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_expiry` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wp_woocommerce_sessions`
--

INSERT INTO `wp_woocommerce_sessions` (`session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(5, '1', 'a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:734:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:25:\"2021-08-12T15:52:25+00:00\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"GB\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"GB\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:20:\"hettipower@gmail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}', 1629383667);

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zones`
--

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zone_order` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_locations`
--

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_shipping_zone_methods`
--

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) UNSIGNED NOT NULL,
  `instance_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_order` bigint(20) UNSIGNED NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rates`
--

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT 0,
  `tax_rate_shipping` int(1) NOT NULL DEFAULT 1,
  `tax_rate_order` bigint(20) UNSIGNED NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_woocommerce_tax_rate_locations`
--

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) UNSIGNED NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) UNSIGNED NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wp_yith_wcwl`
--

CREATE TABLE `wp_yith_wcwl` (
  `ID` bigint(20) NOT NULL,
  `prod_id` bigint(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `wishlist_id` bigint(20) DEFAULT NULL,
  `position` int(11) DEFAULT 0,
  `original_price` decimal(9,3) DEFAULT NULL,
  `original_currency` char(3) DEFAULT NULL,
  `dateadded` timestamp NOT NULL DEFAULT current_timestamp(),
  `on_sale` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `wp_yith_wcwl_lists`
--

CREATE TABLE `wp_yith_wcwl_lists` (
  `ID` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `wishlist_slug` varchar(200) NOT NULL,
  `wishlist_name` text DEFAULT NULL,
  `wishlist_token` varchar(64) NOT NULL,
  `wishlist_privacy` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `dateadded` timestamp NOT NULL DEFAULT current_timestamp(),
  `expiration` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id` (`claim_id`),
  ADD KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`);

--
-- Indexes for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10)),
  ADD KEY `woo_idx_comment_type` (`comment_type`);

--
-- Indexes for table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `wp_smush_dir_images`
--
ALTER TABLE `wp_smush_dir_images`
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `path_hash` (`path_hash`),
  ADD KEY `image_size` (`image_size`);

--
-- Indexes for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `note_id` (`note_id`);

--
-- Indexes for table `wp_wc_category_lookup`
--
ALTER TABLE `wp_wc_category_lookup`
  ADD PRIMARY KEY (`category_tree_id`,`category_id`);

--
-- Indexes for table `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD PRIMARY KEY (`download_log_id`),
  ADD KEY `permission_id` (`permission_id`),
  ADD KEY `timestamp` (`timestamp`);

--
-- Indexes for table `wp_wc_order_coupon_lookup`
--
ALTER TABLE `wp_wc_order_coupon_lookup`
  ADD PRIMARY KEY (`order_id`,`coupon_id`),
  ADD KEY `coupon_id` (`coupon_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_order_product_lookup`
--
ALTER TABLE `wp_wc_order_product_lookup`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_order_stats`
--
ALTER TABLE `wp_wc_order_stats`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `date_created` (`date_created`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `status` (`status`(191));

--
-- Indexes for table `wp_wc_order_tax_lookup`
--
ALTER TABLE `wp_wc_order_tax_lookup`
  ADD PRIMARY KEY (`order_id`,`tax_rate_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `date_created` (`date_created`);

--
-- Indexes for table `wp_wc_product_meta_lookup`
--
ALTER TABLE `wp_wc_product_meta_lookup`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `virtual` (`virtual`),
  ADD KEY `downloadable` (`downloadable`),
  ADD KEY `stock_status` (`stock_status`),
  ADD KEY `stock_quantity` (`stock_quantity`),
  ADD KEY `onsale` (`onsale`),
  ADD KEY `min_max_price` (`min_price`,`max_price`);

--
-- Indexes for table `wp_wc_reserved_stock`
--
ALTER TABLE `wp_wc_reserved_stock`
  ADD PRIMARY KEY (`order_id`,`product_id`);

--
-- Indexes for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  ADD PRIMARY KEY (`tax_rate_class_id`),
  ADD UNIQUE KEY `slug` (`slug`(191));

--
-- Indexes for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  ADD PRIMARY KEY (`webhook_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  ADD PRIMARY KEY (`key_id`),
  ADD KEY `consumer_key` (`consumer_key`),
  ADD KEY `consumer_secret` (`consumer_secret`);

--
-- Indexes for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  ADD PRIMARY KEY (`attribute_id`),
  ADD KEY `attribute_name` (`attribute_name`(20));

--
-- Indexes for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  ADD PRIMARY KEY (`permission_id`),
  ADD KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  ADD KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`);

--
-- Indexes for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `level` (`level`);

--
-- Indexes for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `order_item_id` (`order_item_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `payment_token_id` (`payment_token_id`),
  ADD KEY `meta_key` (`meta_key`(32));

--
-- Indexes for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  ADD PRIMARY KEY (`token_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `session_key` (`session_key`);

--
-- Indexes for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- Indexes for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  ADD PRIMARY KEY (`instance_id`);

--
-- Indexes for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  ADD PRIMARY KEY (`tax_rate_id`),
  ADD KEY `tax_rate_country` (`tax_rate_country`),
  ADD KEY `tax_rate_state` (`tax_rate_state`(2)),
  ADD KEY `tax_rate_class` (`tax_rate_class`(10)),
  ADD KEY `tax_rate_priority` (`tax_rate_priority`);

--
-- Indexes for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `tax_rate_id` (`tax_rate_id`),
  ADD KEY `location_type_code` (`location_type`(10),`location_code`(20));

--
-- Indexes for table `wp_yith_wcwl`
--
ALTER TABLE `wp_yith_wcwl`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `prod_id` (`prod_id`);

--
-- Indexes for table `wp_yith_wcwl_lists`
--
ALTER TABLE `wp_yith_wcwl_lists`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `wishlist_token` (`wishlist_token`),
  ADD KEY `wishlist_slug` (`wishlist_slug`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `wp_actionscheduler_actions`
--
ALTER TABLE `wp_actionscheduler_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_claims`
--
ALTER TABLE `wp_actionscheduler_claims`
  MODIFY `claim_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=560;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_groups`
--
ALTER TABLE `wp_actionscheduler_groups`
  MODIFY `group_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_actionscheduler_logs`
--
ALTER TABLE `wp_actionscheduler_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1541;

--
-- AUTO_INCREMENT for table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;

--
-- AUTO_INCREMENT for table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `wp_smush_dir_images`
--
ALTER TABLE `wp_smush_dir_images`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wp_wc_admin_notes`
--
ALTER TABLE `wp_wc_admin_notes`
  MODIFY `note_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `wp_wc_admin_note_actions`
--
ALTER TABLE `wp_wc_admin_note_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=949;

--
-- AUTO_INCREMENT for table `wp_wc_customer_lookup`
--
ALTER TABLE `wp_wc_customer_lookup`
  MODIFY `customer_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  MODIFY `download_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_wc_tax_rate_classes`
--
ALTER TABLE `wp_wc_tax_rate_classes`
  MODIFY `tax_rate_class_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wp_wc_webhooks`
--
ALTER TABLE `wp_wc_webhooks`
  MODIFY `webhook_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_api_keys`
--
ALTER TABLE `wp_woocommerce_api_keys`
  MODIFY `key_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_attribute_taxonomies`
--
ALTER TABLE `wp_woocommerce_attribute_taxonomies`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wp_woocommerce_downloadable_product_permissions`
--
ALTER TABLE `wp_woocommerce_downloadable_product_permissions`
  MODIFY `permission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_log`
--
ALTER TABLE `wp_woocommerce_log`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_itemmeta`
--
ALTER TABLE `wp_woocommerce_order_itemmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_order_items`
--
ALTER TABLE `wp_woocommerce_order_items`
  MODIFY `order_item_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokenmeta`
--
ALTER TABLE `wp_woocommerce_payment_tokenmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_payment_tokens`
--
ALTER TABLE `wp_woocommerce_payment_tokens`
  MODIFY `token_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_sessions`
--
ALTER TABLE `wp_woocommerce_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zones`
--
ALTER TABLE `wp_woocommerce_shipping_zones`
  MODIFY `zone_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_locations`
--
ALTER TABLE `wp_woocommerce_shipping_zone_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_shipping_zone_methods`
--
ALTER TABLE `wp_woocommerce_shipping_zone_methods`
  MODIFY `instance_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rates`
--
ALTER TABLE `wp_woocommerce_tax_rates`
  MODIFY `tax_rate_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_woocommerce_tax_rate_locations`
--
ALTER TABLE `wp_woocommerce_tax_rate_locations`
  MODIFY `location_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_yith_wcwl`
--
ALTER TABLE `wp_yith_wcwl`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wp_yith_wcwl_lists`
--
ALTER TABLE `wp_yith_wcwl_lists`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `wp_wc_download_log`
--
ALTER TABLE `wp_wc_download_log`
  ADD CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
